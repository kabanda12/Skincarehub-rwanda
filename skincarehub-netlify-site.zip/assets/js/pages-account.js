/* ==========================================================================
   Skincare Hub Rwanda — Commerce page controllers
   cart · wishlist · checkout · account · 404
   ========================================================================== */
window.SHR = window.SHR || {};
(function () {
  "use strict";

  var api = SHR.api;
  var $ = api.$, $$ = api.$$, esc = api.esc, icon = api.icon, money = api.money;
  var CONFIG = SHR.CONFIG;

  var DISTRICTS = [
    { group: "Kigali City", list: ["Gasabo", "Kicukiro", "Nyarugenge"] },
    { group: "Southern Province", list: ["Huye", "Gisagara", "Kamonyi", "Muhanga", "Nyamagabe", "Nyanza", "Nyaruguru", "Ruhango"] },
    { group: "Western Province", list: ["Karongi", "Ngororero", "Nyabihu", "Nyamasheke", "Rubavu", "Rusizi", "Rutsiro"] },
    { group: "Northern Province", list: ["Burera", "Gakenke", "Gicumbi", "Musanze", "Rulindo"] },
    { group: "Eastern Province", list: ["Bugesera", "Gatsibo", "Kayonza", "Kirehe", "Ngoma", "Nyagatare", "Rwamagana"] }
  ];

  function lineRows(showQty) {
    return api.cart.detailed().map(function (l) {
      var p = l.product;
      return (
        '<div class="line-item">' +
        '<a class="line-item__thumb" href="product.html?id=' + encodeURIComponent(p.id) + '" tabindex="-1" aria-hidden="true">' +
        '<span class="visual">' + api.productVisual(p) + "</span></a>" +
        '<div class="line-item__info">' +
        '<span class="line-item__brand">' + esc(p.brand) + "</span>" +
        '<a class="line-item__name" href="product.html?id=' + encodeURIComponent(p.id) + '">' + esc(p.name) + "</a>" +
        '<span class="line-item__meta">' + esc(p.size) + " &middot; " + money(p.price) + " each</span>" +
        (showQty
          ? '<div class="qty mt-1" data-qty="' + esc(p.id) + '">' +
            '<button type="button" data-qty-minus aria-label="Decrease quantity of ' + esc(p.name) + '">&minus;</button>' +
            "<span data-qty-value>" + l.qty + "</span>" +
            '<button type="button" data-qty-plus aria-label="Increase quantity of ' + esc(p.name) + '">+</button></div>'
          : "") +
        (showQty
          ? '<button class="remove-link mt-1" type="button" data-cart-remove="' + esc(p.id) + '">Remove</button>'
          : "") +
        "</div>" +
        '<div class="line-item__price">' + money(l.lineTotal) + "</div></div>"
      );
    }).join("");
  }

  function summaryRows(opts) {
    opts = opts || {};
    var discount = api.cart.discount();
    var shipping = opts.shipping === undefined ? api.cart.shippingDefault() : opts.shipping;
    var total = Math.max(0, api.cart.subtotal() - discount + shipping);
    return (
      '<div class="summary">' +
      '<div class="summary-row"><span>Subtotal (' + api.cart.count() + " item" + (api.cart.count() === 1 ? "" : "s") + ")</span><strong>" + money(api.cart.subtotal()) + "</strong></div>" +
      (discount ? '<div class="summary-row"><span>Discount · ' + esc(api.cart.promoCode()) + "</span><strong>&minus;" + money(discount) + "</strong></div>" : "") +
      '<div class="summary-row"><span>' + esc(opts.shippingLabel || "Delivery in Kigali") + "</span><strong>" + (shipping === 0 ? "Free" : money(shipping)) + "</strong></div>" +
      '<div class="summary-row summary-row--total"><span>Total</span><strong>' + money(total) + "</strong></div>" +
      "</div>"
    );
  }

  /* ─────────────────────────────────────────────────────────── CART */
  function cart() {
    var host = $("[data-cart-page]");
    if (!host) return;
    function render() {
      var lines = api.cart.detailed();
      var prog = api.cart.freeDeliveryProgress();
      if (!lines.length) {
        host.innerHTML =
          '<div class="empty-state">' + icon("cart") +
          "<h1 class='h3'>Your cart is empty</h1>" +
          "<p>Nothing here yet. Best sellers are always a good place to start.</p>" +
          '<div class="cluster cluster--center mt-2">' +
          '<a class="btn btn--gold" href="shop.html?category=best-sellers">Browse Best Sellers</a>' +
          '<a class="btn btn--outline" href="quiz.html">Find Your Routine</a>' +
          '<a class="btn btn--outline" href="shop.html">Continue shopping</a>' +
          '<a class="btn btn--whatsapp" href="' + esc(api.waLink("Hello Skincare Hub Rwanda, I need help choosing products for my cart.")) +
          '" target="_blank" rel="noopener">' + icon("whatsapp") + "WhatsApp help</a></div></div>" +
          '<section class="section--tight"><h2 class="mb-3">Most loved in Rwanda</h2>' +
          '<div class="product-grid product-grid--4">' +
          api.filterProducts({ categories: "best-sellers", sort: "rating" }).slice(0, 4).map(function (p) { return api.productCard(p); }).join("") +
          "</div></section>";
        SHR.ui.refresh();
        return;
      }
      host.innerHTML =
        '<div class="cart-layout">' +
        '<div class="panel">' +
        '<div class="panel__head"><h2>Your cart</h2>' +
        '<a class="link-arrow" href="shop.html">Continue shopping ' + icon("arrowRight") + "</a></div>" +
        '<div class="panel__body panel__body--flush">' +
        '<div class="cart-table-head"><span>Item</span><span></span><span>Quantity</span><span style="text-align:right">Total</span></div>' +
        lineRows(true) + "</div></div>" +
        '<div class="panel">' +
        '<div class="panel__head"><h3>Order summary</h3></div>' +
        '<div class="panel__body">' +
        (api.cart.discount()
          ? summaryRows() + '<p class="mt-2 mb-0"><button class="remove-link" type="button" data-promo-remove>Remove promo code</button></p>'
          : '<p class="form-note mt-0">Have a code? Enter it below.</p>' +
            '<form class="promo-row" data-promo-form>' +
            '<label class="sr-only" for="promoCode">Promo code</label>' +
            '<input class="input" id="promoCode" name="code" placeholder="Promo code" autocomplete="off">' +
            '<button class="btn btn--outline" type="submit" style="min-height:46px">Apply</button></form>' +
            summaryRows()) +
        "</div>" +
        (api.cart.freeDeliveryActive()
          ? '<div class="panel__body" style="border-top:1px solid var(--line)">' +
            '<div class="progress" aria-hidden="true"><div class="progress__bar" style="width:' + prog.percent + '%"></div></div>' +
            '<p class="progress-note mt-1">' + (prog.remaining > 0
              ? "Add <strong>" + money(prog.remaining) + "</strong> more to qualify for free delivery."
              : "<strong>Free delivery unlocked</strong> across all 30 districts.") + "</p>" +
            "</div>"
          : "") +
        '<div class="panel__foot">' +
        '<a class="btn btn--gold btn--block btn--lg" href="checkout.html">' + icon("lock") + "Proceed to checkout</a>" +
        '<div class="cluster cluster--center mt-2">' +
        '<a class="btn btn--outline btn--sm" href="shop.html">' + icon("arrowLeft") + "Continue shopping</a>" +
        '<a class="btn btn--whatsapp btn--sm" href="' + esc(api.waLink("Hello Skincare Hub Rwanda, I need help with my cart or my order.")) +
        '" target="_blank" rel="noopener">' + icon("whatsapp") + "WhatsApp help</a>" +
        "</div>" +
        '<p class="form-note text-center mt-2">' + icon("shield") + " We confirm stock and the total with you before any payment is taken.</p>" +
        "</div></div></div>" +
        '<section class="section--tight"><h2 class="mb-3">You may also like</h2>' +
        '<div class="product-grid product-grid--4">' +
        api.filterProducts({ categories: "best-sellers", sort: "rating" }).slice(0, 4).map(function (p) { return api.productCard(p); }).join("") +
        "</div></section>";

      var promoForm = $("[data-promo-form]", host);
      if (promoForm) {
        promoForm.addEventListener("submit", function (e) {
          e.preventDefault();
          var input = promoForm.querySelector("input");
          var res = api.cart.promo(input ? input.value : "");
          api.toast(res.message, { kind: res.ok ? "gold" : "default", icon: res.ok ? "checkCircle" : "alert" });
          render();
        });
      }
      $$("[data-promo-remove]", host).forEach(function (b) {
        b.addEventListener("click", function () {
          api.cart.promoRemove();
          api.toast("Promo code removed", { icon: "info" });
          render();
        });
      });
      SHR.ui.refresh();
    }
    render();
    api.cart.onChange(function () {
      /* re-render on quantity updates, but not while the drawer itself is editing */
      render();
    });
  }

  /* ────────────────────────────────────────────────────── WISHLIST */
  function wishlist() {
    var host = $("[data-wishlist-page]");
    if (!host) return;
    function render() {
      var list = api.wish.list();
      if (!list.length) {
        host.innerHTML =
          '<div class="empty-state">' + icon("heart") +
          "<h1 class='h3'>Your wishlist is empty</h1>" +
          "<p>Tap the heart on any product to save it for later — it stays on this device.</p>" +
          '<div class="cluster cluster--center mt-2">' +
          '<a class="btn btn--gold" href="shop.html?category=best-sellers">Browse Best Sellers</a>' +
          '<a class="btn btn--outline" href="shop.html">Shop all products</a></div></div>';
        SHR.ui.refresh();
        return;
      }
      var total = list.reduce(function (n, p) { return n + p.price; }, 0);
      host.innerHTML =
        '<div class="row-between mb-3"><p class="mb-0"><strong>' + list.length + "</strong> saved product" + (list.length === 1 ? "" : "s") +
        " &middot; " + money(total) + " in total</p>" +
        '<div class="cluster"><button class="btn btn--gold btn--sm" type="button" data-wish-add-all">' + icon("cart") + "Add all to cart</button>" +
        '<button class="btn btn--outline btn--sm" type="button" data-wish-clear">' + icon("trash") + "Clear wishlist</button></div></div>" +
        '<div class="product-grid product-grid--4">' + list.map(function (p) { return api.productCard(p); }).join("") + "</div>";
      var addAll = $("[data-wish-add-all]", host);
      if (addAll) {
        addAll.addEventListener("click", function () {
          list.forEach(function (p) {
            api.cart.add(p.id, 1, { silent: true });
          });
          api.toast(list.length + " products added to your cart", { kind: "gold", icon: "cart", action: { label: "Checkout", href: "checkout.html" } });
        });
      }
      var clear = $("[data-wish-clear]", host);
      if (clear) {
        clear.addEventListener("click", function () {
          list.slice().forEach(function (p) {
            api.wish.toggle(p.id);
          });
          api.toast("Wishlist cleared", { icon: "info" });
          render();
        });
      }
      SHR.ui.refresh();
    }
    render();
    api.wish.onChange(render);
  }

  /* ────────────────────────────────────────────────────── CHECKOUT */
  function checkout() {
    var host = $("[data-checkout]");
    if (!host) return;
    var form = $('[data-form="checkout"]', host);
    var summaryHost = $("[data-checkout-summary]", host);
    var savedUser = api.user.get();
    var shippingId = "kigali";

    /* build the Rwandan delivery address fields and the payment methods from
       shared data: province, then the districts inside that province, then
       sector, cell and the village or landmark the rider is given */
    var provinceSelect = $("[data-provinces]", host);
    var districtSelect = $("[data-districts]", host);
    function districtOptions(province) {
      var groups = province
        ? DISTRICTS.filter(function (g) { return g.group === province; })
        : DISTRICTS;
      return groups.map(function (g) {
        var options = g.list.map(function (d) {
          return '<option value="' + esc(d) + '">' + esc(d) + "</option>";
        }).join("");
        return province ? options : '<optgroup label="' + esc(g.group) + '">' + options + "</optgroup>";
      }).join("");
    }
    if (provinceSelect) {
      provinceSelect.innerHTML =
        '<option value="">Choose your province</option>' +
        DISTRICTS.map(function (g) {
          return '<option value="' + esc(g.group) + '">' + esc(g.group) + "</option>";
        }).join("");
    }
    if (districtSelect) {
      districtSelect.innerHTML = '<option value="">Choose your district</option>' + districtOptions("");
    }
    if (provinceSelect && districtSelect) {
      provinceSelect.addEventListener("change", function () {
        districtSelect.innerHTML = '<option value="">Choose your district</option>' + districtOptions(provinceSelect.value);
      });
    }
    /* Payment methods come from SHR.pay, which groups them by whether they can
       be paid on this page or are confirmed with the customer first. */
    var payHost = $("[data-payments]", host);
    var payHint = $("[data-pay-hint]", host);

    function paymentTotal() {
      return Math.max(0, api.cart.subtotal() - api.cart.discount() + api.cart.shippingFor(shippingId));
    }
    function selectedPayment() {
      var picked = form ? form.querySelector('input[name="payment"]:checked') : null;
      return picked ? picked.value : "";
    }
    function renderPayHint() {
      if (!payHint) return;
      var phoneField = form ? form.querySelector('[name="phone"]') : null;
      payHint.innerHTML = SHR.pay.hintHTML(selectedPayment(), {
        total: paymentTotal(),
        phone: phoneField ? phoneField.value : ""
      });
    }
    function renderPayCopy() {
      var intro = $("[data-checkout-intro]");
      if (intro) intro.textContent = SHR.pay.intro();
      var trust = $("[data-pay-trust]");
      if (trust) trust.textContent = SHR.pay.note();
      var foot = $("[data-pay-footnote]");
      if (foot) foot.textContent = SHR.pay.footnote();
      var label = form ? $("[data-pay-button-label]", form) : null;
      if (label) label.textContent = SHR.pay.buttonLabel(selectedPayment(), paymentTotal());
    }
    function renderPayments() {
      if (payHost) {
        var first = true;
        payHost.innerHTML = SHR.pay.groups().map(function (g) {
          return (g.title ? '<span class="eyebrow" style="display:block;margin:18px 0 8px">' + esc(g.title) + "</span>" : "") +
            '<div class="option-grid" style="grid-template-columns:1fr">' +
            g.methods.map(function (m) {
              var html =
                '<label class="option"><input type="radio" name="payment" value="' + esc(m.id) + '"' +
                (first ? " checked" : "") + ' data-required data-error="Choose how you would like to pay.">' +
                '<span class="option__dot" aria-hidden="true"></span>' +
                '<span class="option__icon">' + icon(m.icon) + "</span>" +
                '<span class="option__body"><span class="option__title">' + esc(m.label) + "</span>" +
                '<span class="option__meta">' + esc(m.meta) + "</span></span></label>";
              first = false;
              return html;
            }).join("") + "</div>";
        }).join("");
      }
      renderPayHint();
      renderPayCopy();
    }
    renderPayments();
    var shipHost = $("[data-shipping]", host);
    if (shipHost) {
      shipHost.innerHTML = SHR.SHIPPING_OPTIONS.map(function (s, i) {
        var free = api.cart.subtotal() >= CONFIG.delivery.freeFrom;
        var fee = s.fee === 0 || free ? 0 : s.fee;
        return (
          '<label class="option"><input type="radio" name="shippingMethod" value="' + s.id + '"' +
          (i === 0 ? " checked" : "") + ">" +
          '<span class="option__dot" aria-hidden="true"></span>' +
          '<span class="option__body"><span class="option__title">' + esc(s.label) + "</span>" +
          '<span class="option__meta">' + esc(s.meta) + " &middot; " + (fee === 0 ? "Free" : money(fee)) + "</span></span></label>"
        );
      }).join("");
    }
    if (savedUser && form) {
      ["firstName", "lastName", "email", "phone", "district", "address"].forEach(function (k) {
        var field = form.querySelector('[name="' + k + '"]');
        if (field && savedUser[k]) field.value = savedUser[k];
      });
    }

    function shippingFee() {
      return api.cart.shippingFor(shippingId);
    }
    function renderSummary() {
      if (!summaryHost) return;
      var lines = api.cart.detailed();
      if (!lines.length) {
        summaryHost.innerHTML =
          '<div class="empty-state">' + icon("cart") + "<p>Your cart is empty.</p>" +
          '<a class="btn btn--gold btn--sm" href="shop.html?category=best-sellers">Browse Best Sellers</a></div>';
        return;
      }
      var selected = SHR.SHIPPING_OPTIONS.filter(function (s) { return s.id === shippingId; })[0] || SHR.SHIPPING_OPTIONS[0];
      summaryHost.innerHTML =
        lineRows(false) +
        '<div class="mt-3">' + summaryRows({ shipping: shippingFee(), shippingLabel: selected.label }) + "</div>" +
        (api.cart.discount()
          ? '<p class="form-note mt-2 mb-0">Promo <strong>' + esc(api.cart.promoCode()) + "</strong> applied.</p>"
          : '<form class="promo-row mt-3" data-promo-form>' +
            '<label class="sr-only" for="checkoutPromo">Promo code</label>' +
            '<input class="input" id="checkoutPromo" name="code" placeholder="Promo code" autocomplete="off">' +
            '<button class="btn btn--outline" type="submit" style="min-height:46px">Apply</button></form>') +
        '<div class="callout callout--navy mt-3">' + icon("shield") +
        "<p>" + (SHR.pay.isReady()
          ? "<strong>Pay on this page, or once we confirm your order.</strong> Card and mobile money payments are captured by our payment provider, and nothing is dispatched until the payment is confirmed."
          : "<strong>No payment is taken on this page.</strong> We confirm stock and the total with you on WhatsApp or by phone before any money moves. Never send payment to any other number than the one in your confirmation.") +
        "</p></div>";

      var promoForm = $("[data-promo-form]", summaryHost);
      if (promoForm) {
        promoForm.addEventListener("submit", function (e) {
          e.preventDefault();
          var input = promoForm.querySelector("input");
          var res = api.cart.promo(input ? input.value : "");
          api.toast(res.message, { kind: res.ok ? "gold" : "default", icon: res.ok ? "checkCircle" : "alert" });
          renderSummary();
          renderPayHint();
          renderPayCopy();
        });
      }
    }
    renderSummary();

    host.addEventListener("change", function (e) {
      if (e.target.name === "shippingMethod") {
        shippingId = e.target.value;
        renderSummary();
        renderPayHint();
        renderPayCopy();
      }
      if (e.target.name === "payment") {
        renderPayHint();
        renderPayCopy();
      }
    });
    host.addEventListener("input", function (e) {
      if (e.target.name === "phone") renderPayHint();
    });

    if (!form) return;

    /* ── placing the order, then taking the money ──────────────────────── */
    function orderMessage(order, lines, values, shippingLabel) {
      return "Order " + order.ref + "\n" +
        lines.map(function (l) { return l.qty + " x " + l.product.brand + " " + l.product.name + " (" + l.product.size + ") — " + money(l.lineTotal); }).join("\n") +
        "\n\nSubtotal: " + money(order.totals.subtotal) +
        (order.totals.discount ? "\nDiscount: -" + money(order.totals.discount) : "") +
        "\nDelivery (" + shippingLabel + "): " + (order.totals.shipping === 0 ? "Free" : money(order.totals.shipping)) +
        "\nTotal: " + money(order.totals.total) +
        "\n\nName: " + (values.firstName || "") + " " + (values.lastName || "") +
        "\nPhone: " + (values.phone || "") +
        "\nDistrict: " + (values.district || "") +
        "\nAddress: " + (values.address || "") +
        "\nPayment: " + ((SHR.PAYMENTS.filter(function (p) { return p.id === values.payment; })[0] || {}).label || "") +
        "\nStatus: " + SHR.pay.statusLabel(order.paymentStatus);
    }

    function waAction(label, message) {
      return '<a class="btn btn--whatsapp" href="' + esc(api.waLink(message)) + '" target="_blank" rel="noopener">' +
        icon("whatsapp") + esc(label) + "</a>";
    }
    function accountAction() {
      return '<a class="btn btn--outline" href="account.html">View my orders</a>';
    }
    function copyAction() {
      return '<button class="btn btn--link" type="button" data-copy-order>Copy order details</button>';
    }

    function orderPanel(order, opts) {
      opts = opts || {};
      var status = opts.payStatus || order.paymentStatus || "unpaid";
      return '<div class="panel"><div class="panel__body">' +
        '<span class="eyebrow">' + icon(opts.icon || "checkCircle") + esc(opts.eyebrow || "Order request placed") + "</span>" +
        "<h2>" + esc(opts.title || "Thank you") + "</h2>" +
        (opts.body || "") +
        '<div class="order-ref mt-3"><span>Your reference</span><strong>' + esc(order.ref) + "</strong>" +
        '<span class="badge badge--gold">' + money(order.totals.total) + "</span></div>" +
        '<p class="mt-2 mb-0">Payment: <span class="badge ' + SHR.pay.statusClass(status) + '">' + esc(SHR.pay.statusLabel(status)) + "</span></p>" +
        '<div class="cluster mt-3">' + (opts.actions || "") + "</div>" +
        '<p class="form-note mt-3">' + esc(opts.note || "Your order summary stays in this browser.") + "</p>" +
        "</div></div>";
    }

    function wireOrderPanel(panel, orderText, onRetry, onCopyToast) {
      var copyBtn = $("[data-copy-order]", panel);
      if (copyBtn) {
        copyBtn.addEventListener("click", function () {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(orderText).then(function () {
              api.toast(onCopyToast || "Order details copied", { icon: "checkCircle" });
            }).catch(function () {
              api.toast("Select and copy the details from WhatsApp instead", { icon: "info" });
            });
          } else {
            api.toast("Use the WhatsApp button to send your order", { icon: "info" });
          }
        });
      }
      var retry = $("[data-retry-pay]", panel);
      if (retry && onRetry) retry.addEventListener("click", onRetry);
    }

    /* One place that paints the result of an order, whether it still needs
       paying, has been paid, or the payment was stopped. */
    function finishOrder(order, orderText, panel, opts) {
      opts = opts || {};
      var status = opts.payStatus || order.paymentStatus || "unpaid";
      var actions = opts.mode === "manual"
        ? waAction("Send the order on WhatsApp now", orderText) + accountAction() + copyAction()
        : (opts.actions || "") + accountAction() + copyAction();
      panel.innerHTML = orderPanel(order, {
        eyebrow: opts.eyebrow,
        icon: opts.icon,
        title: opts.title || "Thank you, " + (order.customer.firstName || "there"),
        body: opts.body,
        payStatus: status,
        actions: actions,
        note: opts.note
      });
      wireOrderPanel(panel, orderText, opts.onRetry, opts.copyToast);
      if (opts.clearCart !== false) api.cart.clear();
      SHR.ui.renderCounts();
      SHR.ui.refresh();
    }

    function startPayment(order, orderText, panel) {
      panel.innerHTML = '<div class="panel"><div class="panel__body text-center">' +
        '<span class="eyebrow">' + icon("lock") + "Secure payment</span>" +
        "<h2>Opening the secure payment page…</h2>" +
        "<p>Keep this page open and complete the payment in the window that opens. If nothing appears, check your connection — your order is already saved.</p>" +
        '<p class="form-note mt-2">Order <strong>' + esc(order.ref) + "</strong> &middot; " + money(order.totals.total) + "</p>" +
        "</div></div>";
      SHR.pay.pay(order).then(function (res) {
        return SHR.pay.complete(order, res).then(function (check) {
          return { res: res, check: check };
        });
      }).then(function (out) {
        var res = out.res;
        var check = out.check;
        if (res.status === "success") {
          var paid = check.status === "paid";
          api.orders.update(order.ref, {
            paymentStatus: check.status,
            transactionRef: res.transactionRef,
            paidAt: paid ? new Date().toISOString() : ""
          });
          finishOrder(order, orderText, panel, {
            eyebrow: paid ? "Payment confirmed" : "Payment submitted",
            icon: paid ? "checkCircle" : "clock",
            title: "Thank you, " + (order.customer.firstName || "there") + (paid ? " — your payment is through." : "."),
            payStatus: check.status,
            body: "<p>" + esc(check.message || "") + "</p>" +
              (res.transactionRef ? '<p class="form-note mb-0">Payment reference <strong>' + esc(String(res.transactionRef)) + "</strong> — keep it for your records.</p>" : "") +
              "<p>We prepare your parcel and message you the moment it is on the way.</p>",
            note: paid
              ? "Your receipt is emailed by our payment provider. Your card details were never shared with us or stored on this site."
              : "We check every payment against our payment provider before dispatch, so the status can read \"payment being checked\" for a short while. Nothing else is needed from you.",
            actions: waAction("Send the payment reference on WhatsApp", "Hello Skincare Hub Rwanda, I have paid for order " + order.ref + " (payment reference " + (res.transactionRef || "") + ").")
          });
          return;
        }
        /* cancelled, failed or the provider was unreachable — the order and the
           cart are both kept so the customer can simply try again */
        api.orders.update(order.ref, { paymentStatus: "unpaid", transactionRef: res.transactionRef || "" });
        finishOrder(order, orderText, panel, {
          eyebrow: "Order saved, payment not completed",
          icon: "alert",
          title: "Your order is safe",
          payStatus: "unpaid",
          clearCart: false,
          body: "<p>" + esc(res.message || "The payment was not completed.") + "</p>" +
            "<p><strong>Nothing has been charged.</strong> Try the payment again, or we can take it by MTN MoMo, Airtel Money or cash on delivery — your cart and your order details are still here.</p>",
          note: "Payment attempt recorded against order " + order.ref + ". If your wallet shows a deduction without us confirming the order, message us and we will trace it with the provider.",
          copyToast: "Order details copied",
          actions: (SHR.pay.payable(order)
            ? '<button class="btn btn--gold" type="button" data-retry-pay>' + icon("lock") + "Try the payment again</button>"
            : "") + waAction("Send the order on WhatsApp instead", orderText),
          onRetry: function () {
            startPayment(order, orderText, panel);
          }
        });
      });
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var lines = api.cart.detailed();
      if (!lines.length) {
        api.toast("Your cart is empty", { icon: "alert" });
        return;
      }
      var result = api.submitForm(form, {
        name: "checkout",
        intro: "New order from skincarehub.rw (payment to be confirmed before dispatch)",
        labels: {
          firstName: "First name", lastName: "Last name", phone: "Phone", email: "Email",
          province: "Province", district: "District", sector: "Sector", cell: "Cell",
          address: "Village, street or landmark", shippingMethod: "Delivery method",
          payment: "Payment method", notes: "Delivery instructions", consent: "Agreed to terms"
        },
        successTitle: "Order request received — we will confirm it with you shortly.",
        successNote: "A confirmation goes out on WhatsApp within working hours. Nothing is charged until you confirm."
      });
      if (!result.ok) return;
      var shippingLabel = (SHR.SHIPPING_OPTIONS.filter(function (s) { return s.id === result.values.shippingMethod; })[0] || {}).label || "";
      var method = SHR.pay.methodById(result.values.payment) || { id: result.values.payment, label: result.values.payment, live: false };
      var order = api.orders.place({
        customer: result.values,
        payment: result.values.payment,
        shipping: shippingLabel,
        totals: {
          subtotal: api.cart.subtotal(),
          discount: api.cart.discount(),
          shipping: api.cart.shippingFor(result.values.shippingMethod),
          total: Math.max(0, api.cart.subtotal() - api.cart.discount() + api.cart.shippingFor(result.values.shippingMethod))
        },
        paymentStatus: method.live ? "awaiting-payment" : "unpaid"
      });
      var orderText = orderMessage(order, lines, result.values, shippingLabel);

      var panel = document.createElement("div");
      panel.className = "mt-4";
      var wrap = $("[data-checkout-result]") || host;
      wrap.innerHTML = "";
      wrap.appendChild(panel);
      form.classList.add("hide");
      var summaryPanel = summaryHost ? summaryHost.closest(".panel") : null;
      if (summaryPanel) summaryPanel.classList.add("hide");
      var steps = $(".checkout-steps");
      if (steps) steps.classList.add("hide");

      if (method.live) {
        startPayment(order, orderText, panel);
      } else {
        finishOrder(order, orderText, panel, {
          mode: "manual",
          eyebrow: "Order received",
          title: "Thank you for your order!",
          payStatus: "unpaid",
          body: "<p>We have received your order" + (order.customer.firstName ? ", " + esc(order.customer.firstName) : "") +
            ", and we will contact you to confirm delivery.</p>" +
            "<p>An advisor confirms stock and the final total with you before anything is charged — usually within a couple of hours during working hours.</p>" +
            (SHR.pay.hintHTML(order.payment, { total: order.totals.total, phone: order.customer.phone }) || ""),
          note: "We keep your order summary in this browser. Nothing else is sent to a server from this site."
        });
      }
    });
  }

  /* ─────────────────────────────────────────────────────── ACCOUNT */
  function account() {
    var host = $("[data-account]");
    if (!host) return;
    var signInHost = $("[data-signin]", host);
    var dashHost = $("[data-dash]", host);

    function signedIn() {
      return !!api.user.get();
    }
    function renderSignIn() {
      if (!signInHost) return;
      signInHost.innerHTML =
        '<div class="auth-card">' +
        '<span class="eyebrow">Your account</span>' +
        "<h1 class='h3'>Sign in</h1>" +
        "<p>Track your order requests, keep your delivery details and see your saved routine in one place.</p>" +
        '<form class="form mt-3" data-signin-form>' +
        '<div class="field"><label for="accName">Full name <span class="req">*</span></label>' +
        '<input class="input" id="accName" name="name" autocomplete="name" data-required data-error="Please tell us your name."><span class="error-text"></span></div>' +
        '<div class="field"><label for="accEmail">Email <span class="req">*</span></label>' +
        '<input class="input" id="accEmail" name="email" type="email" autocomplete="email" data-required data-type="email" data-error="Please enter a valid email address."><span class="error-text"></span></div>' +
        '<div class="field"><label for="accPhone">Phone (WhatsApp)</label>' +
        '<input class="input" id="accPhone" name="phone" type="tel" data-type="phone" data-error="Use a Rwandan mobile number, e.g. 0787851681." placeholder="0787 851 681"><span class="error-text"></span></div>' +
        '<div class="field"><label for="accDistrict">District</label>' +
        '<select class="select" id="accDistrict" name="district"><option value="">Choose your district</option>' +
        DISTRICTS.map(function (g) {
          return '<optgroup label="' + esc(g.group) + '">' + g.list.map(function (d) { return "<option>" + esc(d) + "</option>"; }).join("") + "</optgroup>";
        }).join("") + "</select></div>" +
        '<button class="btn btn--gold btn--block" type="submit">' + icon("user") + "Sign in</button>" +
        '<div class="form-status"></div>' +
        '<p class="form-note">No password needed. This demo keeps your account in this browser only — connect a backend for real customer accounts before taking live orders.</p>' +
        "</form></div>";
      var form = $("[data-signin-form]", signInHost);
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var res = api.submitForm(form, {
          name: "signin",
          successTitle: "You are signed in.",
          successNote: "Your details are stored in this browser."
        });
        if (!res.ok) return;
        api.user.set({
          name: res.values.name,
          firstName: String(res.values.name || "").split(" ")[0],
          lastName: String(res.values.name || "").split(" ").slice(1).join(" "),
          email: res.values.email,
          phone: res.values.phone,
          district: res.values.district
        });
        render();
      });
    }
    function renderDash() {
      if (!dashHost) return;
      var user = api.user.get() || {};
      var orders = api.orders.all();
      var wish = api.wish.list();
      var result = api.store.get("quizResult", null);
      dashHost.innerHTML =
        '<div class="row-between mb-3"><div><span class="eyebrow">Your account</span>' +
        "<h1 class='h3 mb-0'>Hello, " + esc(String(user.name || "there").split(" ")[0]) + "</h1>" +
        '<p class="text-muted mb-0">' + esc(user.email || "") + (user.district ? " &middot; " + esc(user.district) : "") + "</p></div>" +
        '<button class="btn btn--outline btn--sm" type="button" data-signout>' + icon("user") + "Sign out</button></div>" +
        '<div class="tabs" role="tablist">' +
        '<button class="tab" role="tab" aria-selected="true" data-tab="orders">Orders (' + orders.length + ")</button>" +
        '<button class="tab" role="tab" aria-selected="false" data-tab="routine">My routine</button>' +
        '<button class="tab" role="tab" aria-selected="false" data-tab="wishlist">Wishlist (' + wish.length + ")</button>" +
        '<button class="tab" role="tab" aria-selected="false" data-tab="profile">Profile</button></div>' +
        '<div class="panel mt-3"><div class="panel__body" data-tab-panel="orders">' +
        (orders.length
          ? orders.map(function (o) {
              var statusClass = o.status === "delivered" ? "status--delivered" : o.status === "confirmed" ? "status--confirmed" : "status--pending";
              return '<div class="order-line"><div class="order-line__top">' +
                "<strong>" + esc(o.ref) + "</strong>" +
                '<span class="status ' + statusClass + '">' + esc(api.titleCase(o.status)) + "</span>" +
                "<span>" + money(o.totals.total) + "</span></div>" +
                '<span class="order-line__items">' + esc(o.items.map(function (i) { return i.qty + " × " + i.brand + " " + i.name; }).join(" · ")) + "</span>" +
                '<div class="cluster"><span class="text-muted">' + esc(new Date(o.date).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })) + "</span>" +
                '<span class="badge ' + SHR.pay.statusClass(o.paymentStatus) + '">' + esc(SHR.pay.statusLabel(o.paymentStatus)) + "</span>" +
                (SHR.pay.payable(o)
                  ? '<button class="btn btn--gold btn--sm" type="button" data-pay-order="' + esc(o.ref) + '">' + icon("lock") + "Pay now</button>"
                  : "") +
                '<a class="link-arrow" href="' + esc(api.waLink("Hello, I would like to follow up on order " + o.ref + ".")) + '" target="_blank" rel="noopener">Follow up on WhatsApp</a></div></div>';
            }).join("")
          : '<div class="empty-state">' + icon("bag") + "<p>No orders yet. When you place one it appears here.</p>" +
            '<a class="btn btn--gold btn--sm" href="shop.html?category=best-sellers">Browse Best Sellers</a></div>') +
        "</div>" +
        '<div class="panel__body hide" data-tab-panel="routine">' +
        (result
          ? "<h3>Your routine from the skin quiz</h3><p class='text-muted'>Saved on " + esc(new Date(result.at).toLocaleDateString("en-GB")) + " &middot; " + money(result.total) + "</p>" +
            '<div class="product-grid product-grid--4 mt-3">' +
            api.getProducts(result.products).map(function (p) { return api.productCard(p); }).join("") + "</div>"
          : '<div class="empty-state">' + icon("sparkle") + "<p>You have not taken the skin quiz yet.</p>" +
            '<a class="btn btn--gold btn--sm" href="quiz.html">Find Your Routine</a></div>') +
        "</div>" +
        '<div class="panel__body hide" data-tab-panel="wishlist">' +
        (wish.length
          ? '<div class="product-grid product-grid--4">' + wish.map(function (p) { return api.productCard(p); }).join("") + "</div>"
          : '<div class="empty-state">' + icon("heart") + "<p>Nothing saved yet.</p>" +
            '<a class="btn btn--outline btn--sm" href="shop.html">Shop all products</a></div>') +
        "</div>" +
        '<div class="panel__body hide" data-tab-panel="profile">' +
        '<form class="form" data-profile-form><div class="form-grid form-grid--2">' +
        '<div class="field"><label for="pName">Full name</label><input class="input" id="pName" name="name" value="' + esc(user.name || "") + '"></div>' +
        '<div class="field"><label for="pEmail">Email</label><input class="input" id="pEmail" name="email" type="email" value="' + esc(user.email || "") + '"></div>' +
        '<div class="field"><label for="pPhone">Phone</label><input class="input" id="pPhone" name="phone" type="tel" value="' + esc(user.phone || "") + '"></div>' +
        '<div class="field"><label for="pDistrict">District</label><select class="select" id="pDistrict" name="district">' +
        DISTRICTS.map(function (g) {
          return '<optgroup label="' + esc(g.group) + '">' + g.list.map(function (d) {
            return "<option" + (user.district === d ? " selected" : "") + ">" + esc(d) + "</option>";
          }).join("") + "</optgroup>";
        }).join("") + "</select></div>" +
        '<div class="field field--full"><label for="pAddress">Delivery address</label><textarea class="textarea" id="pAddress" name="address" rows="3">' + esc(user.address || "") + "</textarea></div>" +
        "</div><button class='btn btn--gold' type='submit'>Save my details</button>" +
        '<div class="form-status"></div></form>' +
        '<hr><h3>Data and privacy</h3><p class="form-note mb-2">Your account, orders, wishlist and quiz result are stored only in this browser. Clearing your browser data removes all of it. <a href="policies.html#privacy">Read the privacy policy</a>.</p>' +
        '<button class="btn btn--outline btn--sm" type="button" data-wipe>Delete everything stored on this device</button>' +
        "</div></div></div>";

      var tabs = $$("[data-tab]", dashHost);
      tabs.forEach(function (tab) {
        tab.addEventListener("click", function () {
          tabs.forEach(function (t) {
            t.setAttribute("aria-selected", t === tab ? "true" : "false");
          });
          $$("[data-tab-panel]", dashHost).forEach(function (panel) {
            panel.classList.toggle("hide", panel.getAttribute("data-tab-panel") !== tab.getAttribute("data-tab"));
          });
        });
      });
      /* an unpaid order can be paid later, straight from this list */
      $$("[data-pay-order]", dashHost).forEach(function (btn) {
        btn.addEventListener("click", function () {
          var ref = btn.getAttribute("data-pay-order");
          var order = api.orders.all().filter(function (o) { return o.ref === ref; })[0];
          if (!order) return;
          btn.disabled = true;
          api.toast("Opening the secure payment page…", { icon: "lock" });
          SHR.pay.pay(order).then(function (res) {
            return SHR.pay.complete(order, res).then(function (check) {
              return { res: res, check: check };
            });
          }).then(function (out) {
            if (out.res.status === "success") {
              api.orders.update(order.ref, {
                paymentStatus: out.check.status,
                transactionRef: out.res.transactionRef,
                paidAt: out.check.status === "paid" ? new Date().toISOString() : ""
              });
              api.toast(SHR.pay.statusLabel(out.check.status) + " — " + (out.check.message || ""), { kind: "gold", icon: "checkCircle" });
            } else {
              api.toast(out.res.message || "The payment was not completed.", { icon: "alert" });
            }
            render();
          });
        });
      });
      var signout = $("[data-signout]", dashHost);
      signout.addEventListener("click", function () {
        api.user.set(null);
        api.toast("Signed out", { icon: "info" });
        render();
      });
      var profileForm = $("[data-profile-form]", dashHost);
      profileForm.addEventListener("submit", function (e) {
        e.preventDefault();
        var values = {};
        $$("[name]", profileForm).forEach(function (f) {
          values[f.name] = f.value;
        });
        api.user.set(Object.assign({}, api.user.get() || {}, values, {
          firstName: String(values.name || "").split(" ")[0]
        }));
        api.showStatus(profileForm, "ok", "Your details are saved on this device.");
        render();
      });
      var wipe = $("[data-wipe]", dashHost);
      wipe.addEventListener("click", function () {
        ["cart", "wishlist", "orders", "user", "recent", "quizProgress", "quizResult"].forEach(function (k) {
          api.store.del(k);
        });
        api.toast("Everything stored on this device has been deleted", { icon: "checkCircle" });
        window.location.reload();
      });
    }
    function render() {
      var on = signedIn();
      if (signInHost) signInHost.classList.toggle("hide", on);
      if (dashHost) dashHost.classList.toggle("hide", !on);
      if (on) renderDash();
      else renderSignIn();
      SHR.ui.refresh();
    }
    render();
  }

  /* ─────────────────────────────────────────────────────────── 404 */
  function notFound() {
    var host = $("[data-suggest]");
    if (!host) return;
    host.innerHTML = api.filterProducts({ categories: "best-sellers", sort: "rating" }).slice(0, 4).map(function (p) {
      return api.productCard(p);
    }).join("");
    SHR.ui.refresh();
  }

  function init() {
    var page = (document.body && document.body.getAttribute("data-page")) || "";
    if (page === "cart") cart();
    else if (page === "wishlist") wishlist();
    else if (page === "checkout") checkout();
    else if (page === "account") account();
    else if (page === "404") notFound();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
