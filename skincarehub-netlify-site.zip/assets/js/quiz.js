/* ==========================================================================
   Skincare Hub Rwanda — Skin Quiz
   Six questions — how the skin feels, the main concern, sensitivity, sunscreen,
   budget and the size of routine wanted — then a routine built from the
   catalogue: one product per routine step, chosen for that skin, with the
   honest reason it was picked and what the whole thing costs.
   ========================================================================== */
window.SHR = window.SHR || {};
(function () {
  "use strict";

  var api = SHR.api;
  var $ = api.$, $$ = api.$$, esc = api.esc, icon = api.icon, money = api.money;
  var QUIZ = SHR.QUIZ;

  /* A blank set of answers, so a restart never leaves an answer behind */
  var BLANK = { skinType: "", concern: "", concerns: [], sensitivity: "", spf: "", budget: "", routine: "" };
  var state = { step: 0, answers: Object.assign({}, BLANK) };
  var saved = api.store.get("quizProgress", null);
  if (saved && saved.answers) {
    state = saved;
    state.answers = Object.assign({}, BLANK, saved.answers);
  }
  if (!state.answers.concerns || !state.answers.concerns.length) {
    state.answers.concerns = state.answers.concern ? [state.answers.concern] : [];
  }

  function persist() {
    api.store.set("quizProgress", state);
  }
  function host() {
    return $("[data-quiz]");
  }
  function progress() {
    var total = QUIZ.steps.length;
    var pctDone = Math.round((state.step / total) * 100);
    var bar = $("[data-quiz-bar]");
    if (bar) bar.style.width = pctDone + "%";
    var label = $("[data-quiz-step]");
    if (label) label.textContent = "Question " + Math.min(state.step + 1, total) + " of " + total;
    var pct = $("[data-quiz-percent]");
    if (pct) pct.textContent = pctDone + "% complete";
  }

  function optionMarkup(step, opt, isMulti) {
    var checked = isMulti
      ? state.answers[step.id].indexOf(opt.value) >= 0
      : state.answers[step.id] === opt.value;
    return (
      '<label class="option">' +
      '<input type="' + (isMulti ? "checkbox" : "radio") + '" name="' + step.id + '" value="' + esc(opt.value) + '"' +
      (checked ? " checked" : "") + ">" +
      '<span class="option__dot" aria-hidden="true"></span>' +
      '<span class="option__body"><span class="option__title">' + esc(opt.label) + "</span>" +
      (opt.meta ? '<span class="option__meta">' + esc(opt.meta) + "</span>" : "") +
      "</span></label>"
    );
  }

  function renderStep() {
    var root = host();
    if (!root) return;
    var step = QUIZ.steps[state.step];
    var isMulti = step.type === "multi";
    root.innerHTML =
      '<div class="quiz__card">' +
      '<span class="quiz__stepnum">' + icon("sparkle") + "Question " + (state.step + 1) + " of " + QUIZ.steps.length + "</span>" +
      '<h1 class="quiz__question">' + esc(step.title) + "</h1>" +
      '<p class="quiz__hint">' + esc(step.hint || "") + (isMulti ? " You can choose up to " + (step.max || 3) + "." : "") + "</p>" +
      '<div class="quiz__options' + (step.options.length % 2 === 0 ? " quiz__options--2" : "") + '" data-quiz-options>' +
      step.options.map(function (o) { return optionMarkup(step, o, isMulti); }).join("") +
      "</div>" +
      '<div class="quiz__nav">' +
      '<button class="btn btn--outline btn--sm" type="button" data-quiz-back' + (state.step === 0 ? " disabled" : "") + ">" + icon("arrowLeft") + " Back</button>" +
      '<span class="text-muted" data-quiz-count></span>' +
      '<button class="btn btn--gold" type="button" data-quiz-next>' +
      (state.step === QUIZ.steps.length - 1 ? "See my routine " : "Next ") + icon("arrowRight") + "</button>" +
      "</div></div>";
    progress();
    updateCount();
    var progressBox = $("[data-quiz-progress]");
    if (progressBox) progressBox.classList.remove("hide");
  }

  function updateCount() {
    var step = QUIZ.steps[state.step];
    if (!step || step.type !== "multi") return;
    var node = $("[data-quiz-count]");
    if (node) node.textContent = state.answers.concerns.length + " of " + (step.max || 3) + " chosen";
  }

  function canAdvance() {
    var step = QUIZ.steps[state.step];
    var value = state.answers[step.id];
    return step.type === "multi" ? value.length > 0 : !!value;
  }

  function next() {
    var step = QUIZ.steps[state.step];
    if (!canAdvance()) {
      api.toast(step.type === "multi" ? "Choose at least one concern to continue" : "Please choose an answer to continue", { icon: "alert" });
      return;
    }
    persist();
    if (state.step === QUIZ.steps.length - 1) return showResult();
    state.step += 1;
    renderStep();
    window.scrollTo({ top: host().getBoundingClientRect().top + window.scrollY - 120, behavior: "smooth" });
  }
  function back() {
    if (state.step === 0) return;
    state.step -= 1;
    renderStep();
  }

  /* ────────────────────────────────── recommendation engine ─
     Which steps the routine should contain, from the kind of routine the
     customer asked for. The essentials come first, and a tighter budget never
     removes the sunscreen - protecting the skin is what makes the rest work. */
  function slotsFor(answers) {
    var plan = {
      basic: ["cleanser", "moisturizer", "spf"],
      complete: ["cleanser", "serum", "moisturizer", "spf"],
      advanced: ["cleanser", "serum", "treatment", "moisturizer", "spf"]
    }[answers.routine] || ["cleanser", "serum", "moisturizer", "spf"];
    return QUIZ.routineSlots.filter(function (s) {
      if (plan.indexOf(s.id) < 0) return false;
      /* a strong treatment is never the first thing suggested to reactive skin */
      if (s.id === "treatment" && answers.sensitivity === "high" && answers.concern !== "acne") return false;
      /* on the smallest budget the treatment waits its turn */
      if (s.id === "treatment" && answers.budget === "low") return false;
      return true;
    });
  }

  function scoreProduct(p, answers, cap) {
    var score = p.rating * 0.8;
    if ((p.skinTypes || []).indexOf(answers.skinType) >= 0) score += 3;
    answers.concerns.forEach(function (c, i) {
      if ((p.concerns || []).indexOf(c) >= 0) score += i === 0 ? 5 : 2.5;
    });
    if (answers.sensitivity === "high") {
      if ((p.concerns || []).indexOf("sensitivity") >= 0) score += 2.5;
      if (p.stock === "out") score -= 4;
      if (p.id === "ordinary-aha-30-bha-2-peeling-solution") score -= 6;
      if (p.category === "acne-care") score -= 1;
    }
    if (answers.sensitivity === "medical") {
      if ((p.concerns || []).indexOf("sensitivity") >= 0) score += 2;
    }
    if ((p.collections || []).indexOf("best-sellers") >= 0) score += 0.9;
    if (p.stock === "out") score -= 8;
    if (cap) score += p.price <= cap ? 1.4 : -3;
    return score;
  }

  /* Why this product, for this person, in one honest sentence built from the
     answer they gave and what the catalogue actually says about the product. */
  function whyFor(p, answers) {
    var bits = [];
    if (answers.skinType && (p.skinTypes || []).indexOf(answers.skinType) >= 0) {
      bits.push("it suits " + api.skinTypeLabel(answers.skinType).toLowerCase() + " skin");
    }
    if (answers.concern && (p.concerns || []).indexOf(answers.concern) >= 0) {
      bits.push("it works on " + api.concernLabel(answers.concern).toLowerCase());
    }
    if (answers.sensitivity === "high" && (p.concerns || []).indexOf("sensitivity") >= 0) {
      bits.push("it is gentle on reactive skin");
    }
    var cap = (QUIZ.budgetCaps[answers.budget] || QUIZ.budgetCaps.mid).perItem;
    if (p.price <= cap) bits.push("it fits the budget you set");
    if ((p.collections || []).indexOf("best-sellers") >= 0) bits.push("it is one of our best sellers");
    if (!bits.length) bits.push("it is the closest match to your answers in the catalogue");
    var sentence = bits.slice(0, 3).join(", ");
    return sentence.charAt(0).toUpperCase() + sentence.slice(1) + ".";
  }

  function buildRoutine(answers) {
    var budget = QUIZ.budgetCaps[answers.budget] || QUIZ.budgetCaps.mid;
    var chosen = [];
    var usedIds = {};
    slotsFor(answers).forEach(function (slot) {
      var pool = SHR.PRODUCTS.filter(function (p) {
        return api.inCategory(p, slot.category) && !usedIds[p.id];
      });
      if (!pool.length) return;
      var best = pool
        .map(function (p) { return { p: p, s: scoreProduct(p, answers, budget.perItem) }; })
        .sort(function (a, b) { return b.s - a.s; })
        .filter(function (x) { return x.s > 0; })[0];
      if (!best) return;
      usedIds[best.p.id] = true;
      chosen.push({ slot: slot, product: best.p, why: whyFor(best.p, answers) });
    });
    /* if the budget cap pushed every option out, fall back to the cheapest fit */
    if (!chosen.length) {
      chosen = slotsFor(answers).map(function (slot) {
        var p = SHR.PRODUCTS.filter(function (x) {
          return api.inCategory(x, slot.category) && x.stock !== "out";
        }).sort(function (a, b) { return a.price - b.price; })[0];
        return p ? { slot: slot, product: p, why: whyFor(p, answers) } : null;
      }).filter(Boolean);
    }
    var total = chosen.reduce(function (n, c) { return n + c.product.price; }, 0);
    return { slots: chosen, total: total, budget: budget };
  }

  function showResult() {
    persist();
    var answers = state.answers;
    var profile = QUIZ.profiles[answers.skinType] || QUIZ.profiles.normal;
    var routine = buildRoutine(answers);
    var root = host();
    var concernLabel = answers.concern ? api.concernLabel(answers.concern) : "";
    var within = routine.total <= routine.budget.total;
    var profileLine = api.skinTypeLabel(answers.skinType) + (concernLabel ? " + " + concernLabel : "");
    var bySlot = {};
    routine.slots.forEach(function (c) { bySlot[c.slot.id] = c; });

    /* Sunscreen is the step people skip, so the answer to that question decides
       what we say about it — without pretending it is optional here. */
    var spfNote = answers.spf === "daily"
      ? "You already wear sunscreen daily. Keep that up: it is what lets the rest of this routine work."
      : "You told us sunscreen is not a daily habit yet. In Rwanda that is the step that decides whether dark spots fade or keep coming back, so start there.";

    function routineList(title, ids, note) {
      var shown = ids.filter(function (id) { return bySlot[id]; });
      if (!shown.length) return "";
      return (
        '<div class="side-card"><h3>' + esc(title) + '</h3><ol class="routine-steps routine-steps--numbered">' +
        shown.map(function (id, i) {
          var c = bySlot[id];
          return '<li><span class="routine-step__num">' + (i + 1) + "</span><div><strong>" + esc(c.slot.label) +
            "</strong><span>" + esc(c.product.brand + " " + c.product.name) + " &middot; " + money(c.product.price) + "</span></div></li>";
        }).join("") +
        "</ol>" + (note ? '<p class="form-note mb-0">' + esc(note) + "</p>" : "") + "</div>"
      );
    }

    var cards = routine.slots.map(function (c) {
      var p = c.product;
      var stock = api.stockLabel(p);
      var url = "product.html?id=" + encodeURIComponent(p.id);
      return (
        '<article class="rec-card">' +
        '<a class="rec-card__media" href="' + url + '" tabindex="-1" aria-hidden="true"><span class="visual">' + api.productVisual(p) + "</span></a>" +
        '<div class="rec-card__body">' +
        '<span class="rec-card__step">' + esc(c.slot.step || c.slot.label) + "</span>" +
        '<span class="pcard__brand">' + esc(p.brand) + "</span>" +
        '<h3 class="pcard__name"><a href="' + url + '">' + esc(p.name) + "</a></h3>" +
        '<span class="pcard__size">' + esc(p.size) + " &middot; " + money(p.price) + "</span>" +
        '<span class="pcard__stock ' + stock.cls + '">' + esc(stock.text) + "</span>" +
        '<p class="rec-card__why"><strong>Why it was selected:</strong> ' + esc(c.why) + " " + esc(c.slot.note) + ".</p>" +
        '<div class="cluster">' +
        '<button class="btn btn--gold btn--sm" type="button" data-add="' + esc(p.id) + '">' + icon("cart") + "Add to cart</button>" +
        '<a class="btn btn--outline btn--sm" href="' + url + '">View product</a>' +
        '<a class="btn btn--whatsapp btn--sm" href="' + esc(api.waProduct(p)) + '" target="_blank" rel="noopener">' + icon("whatsapp") + "Chat with us</a>" +
        "</div></div></article>"
      );
    }).join("");

    root.innerHTML =
      '<div class="quiz__result">' +
      '<div class="result-panel">' +
      '<span class="eyebrow">Your skin profile</span>' +
      '<h2 class="result-panel__title">' + esc(profileLine) + "</h2>" +
      '<p class="lead">' + esc(profile.summary) + "</p>" +
      '<div class="pill-list mt-2">' +
      "<span>Skin type: " + esc(api.skinTypeLabel(answers.skinType)) + "</span>" +
      (concernLabel ? "<span>Main concern: " + esc(concernLabel) + "</span>" : "") +
      "<span>Sensitivity: " + esc({ low: "Not usually sensitive", mild: "Sometimes sensitive", high: "Very sensitive" }[answers.sensitivity] || "—") + "</span>" +
      "<span>Sunscreen: " + esc({ daily: "Every day", sometimes: "Sometimes", no: "Not yet" }[answers.spf] || "—") + "</span>" +
      "<span>Routine: " + esc({ basic: "Basic", complete: "Complete", advanced: "Advanced" }[answers.routine] || "—") + "</span>" +
      "</div></div>" +

      '<section class="mt-4"><h2>Your routine, in order</h2>' +
      '<p class="lead">' + esc(within
        ? "This routine comes to " + money(routine.total) + " — inside the " + routine.budget.label + " you chose."
        : "This routine comes to " + money(routine.total) + ", which is more than the " + routine.budget.label +
          " you chose. Buy it in this order and start with the first two steps; the rest can wait a month.") + "</p>" +
      '<div class="grid grid--2 mt-3">' +
      routineList("Your morning routine", ["cleanser", "serum", "moisturizer", "spf"], spfNote) +
      routineList("Your evening routine", ["cleanser", "treatment", "moisturizer"], "Introduce anything new one product at a time, and give it a few weeks before you judge it.") +
      "</div>" +
      '<div class="callout mt-3">' + icon("alert") + "<p><strong>What to avoid with your skin:</strong> " + esc(profile.avoid) + "</p></div>" +
      '<p class="form-note">General skincare guidance, not medical advice. If your skin is under treatment, keep the plan your dermatologist gave you and ask us what fits around it.</p></section>' +

      '<section class="mt-4"><div class="row-between mb-2"><h2 class="mb-0">Your products, and why</h2>' +
      '<span class="badge badge--gold">' + routine.slots.length + " products &middot; " + money(routine.total) + "</span></div>" +
      '<div class="rec-grid">' + cards + "</div>" +
      '<div class="cluster mt-3">' +
      '<button class="btn btn--gold btn--lg" type="button" data-add-routine>' + icon("cart") + "Add the whole routine — " + money(routine.total) + "</button>" +
      '<a class="btn btn--whatsapp btn--lg" href="' + esc(api.waLink("Hello Skincare Hub Rwanda, I took the skin quiz.\n\nMy skin type: " + api.skinTypeLabel(answers.skinType) + "\nMain concern: " + concernLabel + "\nSensitivity: " + answers.sensitivity + "\nSunscreen: " + answers.spf + "\nRoutine: " + answers.routine + "\n\nCan you check this routine for me?")) +
      '" target="_blank" rel="noopener">' + icon("whatsapp") + "Chat with us about this</a>" +
      '<button class="btn btn--outline" type="button" data-quiz-restart>Retake the quiz</button>' +
      "</div></section>" +

      '<section class="cta-band mt-4">' +
      '<h2 class="mb-1">Want a person to check this?</h2>' +
      "<p>Send us photos and your current routine through the consultation form and an advisor will confirm the routine, adjust it and follow up in two weeks — free of charge.</p>" +
      '<div class="cta-band__actions"><a class="btn btn--gold" href="consultation.html">Get Personalized Recommendations</a>' +
      '<a class="btn btn--outline-light" href="shop.html">Shop all products</a></div></section>' +
      "</div>";

    api.store.set("quizResult", {
      answers: answers,
      products: routine.slots.map(function (c) { return c.product.id; }),
      total: routine.total,
      at: new Date().toISOString()
    });
    api.analytics.event("quiz_complete", { skin_type: answers.skinType, concern: answers.concern, spf: answers.spf, budget: answers.budget });

    var addBtn = $("[data-add-routine]", root);
    if (addBtn) {
      addBtn.addEventListener("click", function () {
        routine.slots.forEach(function (c) {
          api.cart.add(c.product.id, 1, { silent: true });
        });
        api.toast("All " + routine.slots.length + " products added to your cart", {
          kind: "gold",
          icon: "cart",
          action: { label: "Checkout", href: "checkout.html" }
        });
      });
    }
    var restart = $("[data-quiz-restart]", root);
    if (restart) {
      restart.addEventListener("click", function () {
        state = { step: 0, answers: Object.assign({}, BLANK) };
        persist();
        renderStep();
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }
    progress();
    var progressBox = $("[data-quiz-progress]");
    if (progressBox) progressBox.classList.add("hide");
    SHR.ui.refresh();
  }

  function init() {
    var root = host();
    if (!root) return;
    if (state.step >= QUIZ.steps.length) state.step = QUIZ.steps.length - 1;
    var previous = api.store.get("quizResult", null);
    renderStep();
    /* a returning visitor keeps their answers and can jump straight back in */
    if (previous && previous.answers && !api.params().restart) {
      var resume = document.createElement("div");
      resume.className = "callout";
      resume.innerHTML =
        icon("sparkle") +
        "<p><strong>Welcome back.</strong> Your last answers are still here. " +
        "<a href=\"#\" data-show-last-result>See the routine we suggested</a> or carry on below and change anything that has changed.</p>";
      root.parentNode.insertBefore(resume, root);
      resume.addEventListener("click", function (e) {
        if (!e.target.closest("[data-show-last-result]")) return;
        e.preventDefault();
        state.answers = previous.answers;
        showResult();
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }
    root.addEventListener("change", function (e) {
      var step = QUIZ.steps[state.step];
      if (!e.target.name || e.target.name !== step.id) return;
      if (step.type === "multi") {
        var chosen = state.answers.concerns;
        if (e.target.checked) {
          if (chosen.length >= (step.max || 3)) {
            e.target.checked = false;
            api.toast("Only " + (step.max || 3) + " concerns, so we can focus the routine. Remove one to change your mind.", { icon: "info" });
            return;
          }
          chosen.push(e.target.value);
        } else {
          state.answers.concerns = chosen.filter(function (v) { return v !== e.target.value; });
        }
      } else {
        state.answers[step.id] = e.target.value;
        /* the routine is built around the main concern, which the engine reads
           as the first entry of the concerns list */
        if (step.id === "concern") {
          state.answers.concerns = e.target.value ? [e.target.value] : [];
        }
      }
      persist();
      updateCount();
    });
    root.addEventListener("click", function (e) {
      if (e.target.closest("[data-quiz-next]")) next();
      else if (e.target.closest("[data-quiz-back]")) back();
    });
  }

  /* Exposed so the recommendation engine can be tested directly (see tools/tests.html) */
  SHR.quiz = {
    init: init,
    state: state,
    engine: {
      slotsFor: slotsFor,
      scoreProduct: scoreProduct,
      buildRoutine: buildRoutine
    }
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
