/* ==========================================================================
   Skincare Hub Rwanda — Content page controllers
   blog · article · contact · consultation
   ========================================================================== */
window.SHR = window.SHR || {};
(function () {
  "use strict";

  var api = SHR.api;
  var $ = api.$, $$ = api.$$, esc = api.esc, icon = api.icon, money = api.money;
  var CONFIG = SHR.CONFIG;
  var ARTICLES = SHR.ARTICLES;

  function postCard(a, feature) {
    return (
      '<article class="post-card' + (feature ? " post-card--feature" : "") + ' reveal">' +
      '<a class="post-card__cover" href="article.html?slug=' + a.slug + '" aria-label="' + esc(a.title) + '">' +
      /* The photograph is laid over the generated cover art, which stays
         underneath as the fallback. It comes first in the anchor because the
         category badge is positioned too and so paints on top of it. */
      (a.photo
        ? '<img class="post-card__photo" src="' + esc(a.photo) + '" alt="" loading="lazy" decoding="async" data-guide-photo>'
        : "") +
      '<span class="post-card__cat">' + esc(a.category) + "</span>" +
      api.coverArt(a.cover) +
      "</a>" +
      '<div class="post-card__body">' +
      "<h3><a href=\"article.html?slug=" + a.slug + '">' + esc(a.title) + "</a></h3>" +
      '<p class="post-card__excerpt">' + esc(a.excerpt) + "</p>" +
      '<div class="post-card__meta"><span>' + esc(a.date) + "</span><span>" + a.readMins + " min read</span>" +
      '<span>' + esc(a.category) + "</span></div></div></article>"
    );
  }

  /* ─────────────────────────────────────────────────────────── BLOG */
  function blog() {
    var host = $("[data-blog-grid]");
    if (!host) return;
    var chipHost = $("[data-blog-cats]");
    var cats = ["All"].concat(
      ARTICLES.map(function (a) { return a.category; }).filter(function (c, i, all) { return all.indexOf(c) === i; })
    );
    var state = { category: "All", q: "" };
    var featured = $("[data-blog-featured]");
    if (featured) featured.innerHTML = postCard(ARTICLES[0], true);
    function renderChips() {
      if (!chipHost) return;
      chipHost.innerHTML = cats.map(function (c) {
        return '<button class="chip" type="button" data-blog-cat="' + esc(c) + '"' + (state.category === c ? ' aria-pressed="true"' : "") + ">" + esc(c) + "</button>";
      }).join("");
    }
    function render() {
      var list = ARTICLES.filter(function (a) {
        var okCat = state.category === "All" || a.category === state.category;
        var okQ = !state.q || (a.title + " " + a.excerpt + " " + (a.keywords || []).join(" ")).toLowerCase().indexOf(state.q.toLowerCase()) >= 0;
        return okCat && okQ;
      });
      host.innerHTML = list.length
        ? list.map(function (a) { return postCard(a); }).join("")
        : '<div class="empty-state">' + icon("search") + "<p>No articles matched. Try “acne”, “sunscreen” or “routine”.</p></div>";
      var count = $("[data-blog-count]");
      if (count) count.textContent = list.length + " article" + (list.length === 1 ? "" : "s");
      SHR.ui.refresh();
    }
    renderChips();
    render();
    if (chipHost) {
      chipHost.addEventListener("click", function (e) {
        var b = e.target.closest("[data-blog-cat]");
        if (!b) return;
        state.category = b.getAttribute("data-blog-cat");
        renderChips();
        render();
      });
    }
    var search = $("[data-blog-search]");
    if (search) {
      search.addEventListener("input", api.debounce(function () {
        state.q = search.value;
        render();
      }, 200));
    }
  }

  /* ──────────────────────────────────────────────────────── ARTICLE */
  function article() {
    var host = $("[data-article]");
    if (!host) return;
    var slug = api.params().slug || "";
    var item = ARTICLES.filter(function (a) { return a.slug === slug; })[0];
    if (!item) {
      host.innerHTML =
        '<div class="empty-state">' + icon("search") + "<h1>That article does not exist</h1>" +
        '<p>It may have been renamed. Have a look at the blog index instead.</p>' +
        '<a class="btn btn--gold" href="blog.html">Back to the blog</a></div>';
      return;
    }
    document.title = item.metaTitle || item.title;
    var meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", item.metaDescription || item.excerpt);
    var canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) canonical.setAttribute("href", "article.html?slug=" + item.slug);

    var index = ARTICLES.indexOf(item);
    var prev = ARTICLES[index - 1] || null;
    var next = ARTICLES[index + 1] || null;
    var relatedProducts = api.getProducts(item.related || []);
    var relatedArticles = ARTICLES.filter(function (a) {
      return a.slug !== item.slug && (a.category === item.category || (a.keywords || []).some(function (k) { return (item.keywords || []).indexOf(k) >= 0; }));
    }).slice(0, 3);

    host.innerHTML =
      '<header class="page-hero" style="padding-block:0;border:0;background:none">' +
      '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="index.html">Home</a><span aria-hidden="true">/</span>' +
      '<a href="blog.html">Blog</a><span aria-hidden="true">/</span><span aria-current="page">' + esc(item.category) + "</span></nav>" +
      '<span class="eyebrow">' + esc(item.category) + "</span>" +
      "<h1>" + esc(item.title) + "</h1>" +
      '<p class="lead">' + esc(item.excerpt) + "</p>" +
      '<div class="article-meta mt-3"><span>' + esc(item.author) + "</span><span>Published " + esc(fmtDate(item.date)) + "</span>" +
      "<span>" + item.readMins + " min read</span>" +
      '<a class="link-arrow" href="' + esc(api.waLink("Hello, I have a question about your article: " + item.title)) + '" target="_blank" rel="noopener">' + icon("whatsapp") + "Ask us about this</a></div>" +
      "</header>" +
      '<div class="article-layout mt-3">' +
      "<article>" +
      '<div class="visual visual--tile" style="border-radius:var(--r-lg);overflow:hidden;margin-bottom:2rem">' + api.coverArt(item.cover) + "</div>" +
      '<div class="prose"><p class="lead">' + esc(asPlain(item.intro)) + "</p>" +
      item.sections.map(function (s) {
        return '<h2 id="' + s.id + '">' + esc(s.heading) + "</h2>" + s.html;
      }).join("") +
      '<h2 id="takeaways">Key takeaways</h2><ul class="check-list">' +
      (item.takeaways || []).map(function (t) { return "<li>" + icon("check") + "<span>" + esc(t) + "</span></li>"; }).join("") +
      "</ul>" +
      ((item.faqs || []).length
        ? '<h2 id="article-faq">Frequently asked questions</h2><div class="accordion">' +
          item.faqs.map(function (f) { return acc(esc(f.q), "<p>" + esc(f.a) + "</p>"); }).join("") + "</div>"
        : "") +
      "</div>" +
      '<div class="cta-band mt-4"><h3 class="mb-1">Not sure which products fit your skin?</h3>' +
      "<p>Take the two-minute quiz for a routine built around your skin, or send us your details and an advisor will answer on WhatsApp within a working day.</p>" +
      '<div class="cta-band__actions"><a class="btn btn--gold" href="quiz.html">' + icon("sparkle") + "Find Your Routine</a>" +
      '<a class="btn btn--outline-light" href="consultation.html">Get Personalized Recommendations</a></div></div>' +
      ((relatedProducts.length)
        ? '<section class="mt-4"><h2>Products mentioned</h2><div class="product-grid product-grid--4">' +
          relatedProducts.map(function (p) { return api.productCard(p); }).join("") + "</div></section>"
        : "") +
      '<nav class="row-between mt-4" aria-label="More articles">' +
      (prev ? '<a class="link-arrow" href="article.html?slug=' + prev.slug + '">' + icon("arrowLeft") + " " + esc(shorten(prev.title, 40)) + "</a>" : "<span></span>") +
      (next ? '<a class="link-arrow" href="article.html?slug=' + next.slug + '">' + esc(shorten(next.title, 40)) + " " + icon("arrowRight") + "</a>" : "<span></span>") +
      "</nav></article>" +
      '<aside class="article-side">' +
      '<div class="side-card"><h3>On this page</h3><nav class="toc">' +
      item.sections.map(function (s) { return '<a href="#' + s.id + '">' + esc(s.heading) + "</a>"; }).join("") +
      '<a href="#takeaways">Key takeaways</a></nav></div>' +
      '<div class="side-card"><h3>Get a routine for your skin</h3>' +
      "<p class=\"mb-2\">Answer six questions and we will build a routine from the products we actually stock.</p>" +
      '<a class="btn btn--gold btn--sm btn--block" href="quiz.html">Start the skin quiz</a>' +
      '<a class="btn btn--whatsapp btn--sm btn--block mt-1" href="' + esc(api.waLink("Hello Skincare Hub Rwanda, I read your article and need advice.")) + '" target="_blank" rel="noopener">' + icon("whatsapp") + "Chat on WhatsApp</a></div>" +
      (relatedProducts.length
        ? '<div class="side-card"><h3>Recommended products</h3><div class="stack">' +
          relatedProducts.slice(0, 3).map(function (p) {
            return '<a class="search-result" href="product.html?id=' + p.id + '" style="padding:8px 0">' +
              '<span class="search-result__thumb"><span class="visual">' + api.productVisual(p) + "</span></span>" +
              '<span class="search-result__meta"><span class="search-result__name">' + esc(p.name) + "</span>" +
              '<span class="search-result__sub">' + esc(p.brand) + "</span></span>" +
              '<span class="search-result__price">' + money(p.price) + "</span></a>";
          }).join("") + "</div></div>"
        : "") +
      "</aside></div>" +
      ((relatedArticles.length)
        ? '<section class="section--tight mt-4"><h2>Keep reading</h2><div class="post-grid">' +
          relatedArticles.map(function (a) { return postCard(a); }).join("") + "</div></section>"
        : "") +
      '<script type="application/ld+json">' + JSON.stringify(articleSchema(item)) + "</script>";

    SHR.ui.refresh();
  }
  function shorten(s, n) {
    return s.length > n ? s.slice(0, n - 1) + "…" : s;
  }
  function asPlain(html) {
    return String(html || "").replace(/<[^>]+>/g, "");
  }
  function fmtDate(iso) {
    var d = new Date(iso + "T00:00:00");
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
  }
  function articleSchema(item) {
    return {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "BlogPosting",
          headline: item.title,
          description: item.metaDescription || item.excerpt,
          datePublished: item.date,
          dateModified: item.date,
          keywords: (item.keywords || []).join(", "),
          articleSection: item.category,
          author: { "@type": "Organization", name: CONFIG.name },
          publisher: { "@type": "Organization", name: CONFIG.name, url: "index.html" },
          mainEntityOfPage: "article.html?slug=" + item.slug
        }
      ].concat(
        (item.faqs || []).length
          ? [{
              "@type": "FAQPage",
              mainEntity: item.faqs.map(function (f) {
                return { "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } };
              })
            }]
          : []
      )
    };
  }
  function acc(title, body) {
    return "<details class='acc'><summary>" + title + "</summary><div class='acc__body'>" + body + "</div></details>";
  }

  /* ────────────────────────────────────────────────────────── ABOUT */
  /* The brand list and the numbers on About come from the catalogue, so the
     page can never claim a brand or a count the shop does not have. */
  function about() {
    var brands = $("[data-about-brands]");
    if (brands && SHR.brandCards) brands.innerHTML = SHR.brandCards();
    var count = $("[data-about-count]");
    if (count) count.textContent = SHR.PRODUCTS.length;
    var brandCount = $("[data-about-brandcount]");
    if (brandCount) brandCount.textContent = SHR.BRANDS.length;
    SHR.ui.refresh();
  }

  /* ───────────────────────────────────────────────────────── CONTACT */
  function hoursOpenNow() {
    var now = new Date();
    var day = now.getDay();
    var hour = now.getHours() + now.getMinutes() / 60;
    var open = false;
    (CONFIG.hours || []).forEach(function (row) {
      if (!row.from || !row.to) return;
      var fd = row.from[0], fh = row.from[1], td = row.to[0], th = row.to[1];
      /* A row names a run of days that all keep the same hours, so both halves
         have to agree: the day has to be inside the run, and the clock inside
         that day's opening window. An open run of days does not mean the shop
         is open at midnight in the middle of it. */
      var inDays = fd <= td ? (day >= fd && day <= td) : (day >= fd || day <= td);
      if (inDays && hour >= fh && hour < th) open = true;
    });
    return open;
  }
  function contact() {
    var badge = $("[data-open-now]");
    if (badge) {
      var open = hoursOpenNow();
      badge.className = "now-badge " + (open ? "now-badge--open" : "now-badge--closed");
      badge.textContent = open ? "Open now — message us" : "Closed right now — leave a message and we reply first thing";
    }
    $$("[data-hours]").forEach(function (list) {
      list.innerHTML = (CONFIG.hours || []).map(function (h) {
        return "<li><span>" + esc(h.day) + "</span><strong>" + esc(h.time) + "</strong></li>";
      }).join("");
    });
    var map = $("[data-map]");
    if (map) {
      map.setAttribute(
        "src",
        "https://www.google.com/maps?q=" + encodeURIComponent(CONFIG.address.mapQuery) + "&output=embed"
      );
    }
    var form = $('[data-form="contact"]');
    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        api.submitForm(form, {
          name: "contact",
          intro: "New website enquiry for Skincare Hub Rwanda",
          labels: { name: "Name", phone: "Phone", email: "Email", subject: "Subject", message: "Message", orderRef: "Order reference (if any)" },
          successTitle: "Message received.",
          successNote: "We reply within one working day. For anything urgent, WhatsApp is faster — it is open 9:00 to 21:00 Monday to Saturday and 11:00 to 18:00 on Sunday."
        });
      });
    }
    SHR.ui.refresh();
  }

  /* ─────────────────────────────────────────────────── CONSULTATION */
  function initMultiSelects(root) {
    $$("[data-multi]", root || document).forEach(function (wrap) {
      var hidden = wrap.querySelector('input[type="hidden"]');
      var feedback = wrap.parentNode.querySelector("[data-multi-count]");
      function sync() {
        var values = $$('input[type="checkbox"]:checked', wrap).map(function (c) {
          return c.value;
        });
        if (hidden) hidden.value = values.join(", ");
        if (feedback) feedback.textContent = values.length + " selected";
      }
      wrap.addEventListener("change", function (e) {
        var max = Number(wrap.getAttribute("data-max")) || 0;
        if (max && e.target.checked) {
          var checked = $$('input[type="checkbox"]:checked', wrap);
          if (checked.length > max) {
            e.target.checked = false;
            api.toast("Please choose up to " + max + " so we can focus your routine.", { icon: "info" });
          }
        }
        sync();
      });
      sync();
    });
  }
  function consultation() {
    var form = $('[data-form="consultation"]');
    if (!form) return;
    initMultiSelects(form);
    /* build the skin type and concern option tiles from the shared data */
    var skinHost = $("[data-consult-skintype]", form);
    if (skinHost) {
      skinHost.innerHTML = SHR.SKIN_TYPES.map(function (s) {
        return (
          '<label class="option"><input type="radio" name="skinType" value="' + s.id + '" data-required data-error="Choose the closest skin type.">' +
          '<span class="option__dot" aria-hidden="true"></span>' +
          '<span class="option__body"><span class="option__title">' + esc(s.label) + "</span>" +
          '<span class="option__meta">' + esc(s.meta) + "</span></span></label>"
        );
      }).join("");
    }
    var concernHost = $("[data-consult-concerns]", form);
    if (concernHost) {
      concernHost.innerHTML = SHR.CONCERNS.map(function (c) {
        return (
          '<label class="option"><input type="checkbox" value="' + esc(c.label) + '">' +
          '<span class="option__dot" aria-hidden="true"></span>' +
          '<span class="option__body"><span class="option__title">' + esc(c.label) + "</span></span></label>"
        );
      }).join("");
    }
    /* prefill from the quiz if the visitor has taken it */
    var result = api.store.get("quizResult", null);
    if (result && result.answers) {
      var radio = form.querySelector('[name="skinType"][value="' + result.answers.skinType + '"]');
      if (radio) radio.checked = true;
      (result.answers.concerns || []).forEach(function (c) {
        var box = $$("[data-consult-concerns] input[type=checkbox]", form).filter(function (b) {
          return b.value.toLowerCase() === api.concernLabel(c).toLowerCase();
        })[0];
        if (box) box.checked = true;
      });
      var routine = form.querySelector('[name="routine"]');
      if (routine && result.answers.routine) routine.value = result.answers.routine;
      var sensitivity = form.querySelector('[name="sensitivity"]');
      if (sensitivity && result.answers.sensitivity) sensitivity.value = result.answers.sensitivity;
      var note = $("[data-quiz-note]", form);
      if (note) {
        note.classList.remove("hide");
        note.innerHTML = icon("sparkle") + "<p>We filled in what we already know from your skin quiz" +
          (result.products && result.products.length ? " and added the routine we suggested (" + result.products.length + " products)" : "") +
          ". Change anything that is not right.</p>";
      }
      var hidden = form.querySelector('[name="concerns"]');
      if (hidden) {
        hidden.value = $$("[data-consult-concerns] input[type=checkbox]:checked", form).map(function (b) { return b.value; }).join(", ");
        var feedback = form.querySelector("[data-multi-count]");
        if (feedback) feedback.textContent = (hidden.value ? hidden.value.split(", ").length : 0) + " selected";
      }
    }
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var photos = form.querySelector("input[type=file]");
      var photoCount = photos && photos.files ? photos.files.length : 0;
      api.submitForm(form, {
        name: "consultation",
        intro: "New skincare consultation request from the website" + (photoCount ? " (" + photoCount + " photo file name(s) chosen — ask the client to send them on WhatsApp)" : ""),
        labels: {
          name: "Name", phone: "Phone", email: "Email", skinType: "Skin type", concerns: "Concerns",
          routine: "Current routine", sensitivity: "Sensitivity", budget: "Budget", products: "Products already using",
          notes: "Notes", earlier: "Previously seen a dermatologist"
        },
        successTitle: "Your request is with our advisors.",
        successNote: "You will get a written routine on WhatsApp within one working day — free of charge. Send your photos in the same WhatsApp chat so we can see your skin."
      });
    });
    SHR.ui.refresh();
  }

  function init() {
    var page = (document.body && document.body.getAttribute("data-page")) || "";
    if (page === "blog") blog();
    else if (page === "article") article();
    else if (page === "about") about();
    else if (page === "contact") contact();
    else if (page === "consultation") consultation();
    else initMultiSelects(document);
  }
  SHR.contentPages = { init: init, postCard: postCard, initMultiSelects: initMultiSelects };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
