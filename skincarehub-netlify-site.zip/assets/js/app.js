/* ==========================================================================
   Skincare Hub Rwanda — Core library (SHR.api)
   Everything that does not touch the DOM chrome: data queries, money,
   safe storage, the SVG illustration system, cart, wishlist, orders,
   WhatsApp links, form handling and analytics hooks.
   Plain classic script — no ES modules — so the site works from file://
   ========================================================================== */
window.SHR = window.SHR || {};
(function () {
  "use strict";

  var CONFIG = SHR.CONFIG;
  var PRODUCTS = SHR.PRODUCTS || [];

  /* ─────────────────────────────────────────────── DOM + value helpers */
  function $(sel, root) {
    return (root || document).querySelector(sel);
  }
  function $$(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function slug(s) {
    return String(s || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
  }
  function titleCase(s) {
    return String(s || "").replace(/(^|[\s-])([a-z])/g, function (m, a, b) {
      return a + b.toUpperCase();
    });
  }
  function money(n) {
    var v = Math.round(Number(n) || 0);
    return String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ",") + " " + CONFIG.currency;
  }
  function pct(a, b) {
    return b > 0 ? Math.round(((b - a) / b) * 100) : 0;
  }
  function debounce(fn, wait) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () {
        fn.apply(self, args);
      }, wait || 180);
    };
  }
  function query(params) {
    var out = [];
    Object.keys(params || {}).forEach(function (k) {
      var v = params[k];
      if (v === undefined || v === null || v === "" || v === false) return;
      if (Array.isArray(v)) {
        v.forEach(function (item) {
          out.push(encodeURIComponent(k) + "=" + encodeURIComponent(item));
        });
      } else {
        out.push(encodeURIComponent(k) + "=" + encodeURIComponent(v));
      }
    });
    return out.length ? "?" + out.join("&") : "";
  }
  /* Read the current query string without needing a server */
  function params() {
    var out = {};
    var search = String(window.location.search || "").replace(/^\?/, "");
    if (!search) return out;
    search.split("&").forEach(function (pair) {
      if (!pair) return;
      var kv = pair.split("=");
      var k = decodeURIComponent(kv[0] || "");
      var v = decodeURIComponent((kv[1] || "").replace(/\+/g, " "));
      if (!k) return;
      if (out[k] === undefined) out[k] = v;
      else if (Array.isArray(out[k])) out[k].push(v);
      else out[k] = [out[k], v];
    });
    return out;
  }
  function arr(v) {
    if (v === undefined || v === null || v === "") return [];
    return Array.isArray(v) ? v : [v];
  }

  /* ──────────────────────────── Storage: survives file:// restrictions */
  var memory = {};
  var store = {
    get: function (key, fallback) {
      try {
        var raw = window.localStorage.getItem("shr." + key);
        return raw === null ? (memory[key] !== undefined ? memory[key] : fallback) : JSON.parse(raw);
      } catch (e) {
        return memory[key] !== undefined ? memory[key] : fallback;
      }
    },
    set: function (key, val) {
      memory[key] = val;
      try {
        window.localStorage.setItem("shr." + key, JSON.stringify(val));
      } catch (e) {
        /* private mode or file:// without storage — memory cache still works */
      }
      return val;
    },
    del: function (key) {
      delete memory[key];
      try {
        window.localStorage.removeItem("shr." + key);
      } catch (e) {}
    }
  };

  /* ──────────────────────────────────────────────────── Icon sprite */
  var ICONS = {
    cart: '<path d="M3 4h2.2l2.4 11.2A2 2 0 0 0 9.56 17h8.9a2 2 0 0 0 1.96-1.6L22 8H6"/><circle cx="10" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/>',
    home: '<path d="M3.5 10.6L12 4l8.5 6.6V20h-5.6v-5.4H9.1V20H3.5z"/>',
    bag: '<path d="M6 8h12l1 12H5z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
    heart: '<path d="M12 20s-7.5-4.4-7.5-9.4A4.1 4.1 0 0 1 12 7.6a4.1 4.1 0 0 1 7.5 3C19.5 15.6 12 20 12 20z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.6-3.6"/>',
    user: '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    arrowLeft: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
    arrowUp: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    chevronDown: '<path d="M6 9l6 6 6-6"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    checkCircle: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.6 2.6L16 9.6"/>',
    shield: '<path d="M12 3l7 3v6c0 4.2-2.9 7.8-7 9-4.1-1.2-7-4.8-7-9V6z"/><path d="M9.2 12.4l2 2 3.6-3.8"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M18.5 16.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.7 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.7-3.8-9S9.5 5.6 12 3z"/>',
    truck: '<path d="M3 7h10v9H3z"/><path d="M13 10h4.5l3.5 3.2V16H13z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>',
    chat: '<path d="M20 12a7.5 7.5 0 0 1-11 6.6L5 20l1.2-3.6A7.5 7.5 0 1 1 20 12z"/><path d="M9.5 11h5M9.5 14h3"/>',
    lock: '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10"/>',
    return: '<path d="M9 14l-4-4 4-4"/><path d="M5 10h9a5 5 0 0 1 0 10h-3"/>',
    phone: '<path d="M5 4h3l1.6 4-2 1.4a12 12 0 0 0 5.8 5.8L15 13l4 1.6V18a2 2 0 0 1-2.2 2A15 15 0 0 1 4 6.2 2 2 0 0 1 5 4z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    pin: '<path d="M12 21s6.5-6.1 6.5-11a6.5 6.5 0 0 0-13 0C5.5 14.9 12 21 12 21z"/><circle cx="12" cy="10" r="2.4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 2"/>',
    whatsapp:
      '<path d="M20.3 11.7a8.3 8.3 0 0 1-12.2 7.3L4 20.2l1.3-4A8.3 8.3 0 1 1 20.3 11.7z"/><path d="M9 9.2c0 3 2.4 5.4 5.4 5.4.6 0 1-.5 1-1l-1.5-.7-.9.8a4 4 0 0 1-2.2-2.2l.8-.9-.7-1.5c-.5 0-1 .4-1 1z"/>',
    instagram: '<rect x="4" y="4" width="16" height="16" rx="4.6"/><circle cx="12" cy="12" r="3.6"/><path d="M17 7.2h.01"/>',
    facebook: '<path d="M14.5 8.5h2.2V5.6h-2.2c-2 0-3.4 1.5-3.4 3.5v1.5H9.4v2.9h1.7V21h3v-7.5h2.3l.4-2.9h-2.7V9.4c0-.5.3-.9.4-.9z"/>',
    tiktok: '<path d="M15 4v8.2a2.8 2.8 0 1 1-2.8-2.8"/><path d="M15 6.2A3.8 3.8 0 0 0 18.8 10"/>',
    filter: '<path d="M4 6h16M7 12h10M10 18h4"/>',
    sort: '<path d="M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3"/>',
    upload: '<path d="M12 16V5M8 9l4-4 4 4"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    alert: '<path d="M12 4l8.5 15H3.5z"/><path d="M12 9.5v4M12 16.5h.01"/>',
    trash: '<path d="M5 7h14M9 7V5h6v2M7 7l1 13h8l1-13"/>',
    droplet: '<path d="M12 3.5s5.5 6 5.5 10a5.5 5.5 0 0 1-11 0c0-4 5.5-10 5.5-10z"/>',
    leaf: '<path d="M5 19c0-8 5-13 14-13 0 8-5 12-11 12H5z"/><path d="M5 19c3-4 6-6 10-7"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.6v2M12 19.4v2M2.6 12h2M19.4 12h2M5.4 5.4l1.4 1.4M17.2 17.2l1.4 1.4M18.6 5.4l-1.4 1.4M6.8 17.2l-1.4 1.4"/>',
    camera: '<path d="M4 8h3l1.4-2h7.2L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.4"/>',
    card: '<rect x="3" y="5.5" width="18" height="13" rx="2.4"/><path d="M3 10h18"/>',
    cash: '<rect x="3" y="6.5" width="18" height="11" rx="2"/><circle cx="12" cy="12" r="2.6"/>',
    box: '<path d="M4 8l8-4 8 4v8l-8 4-8-4z"/><path d="M4 8l8 4 8-4M12 12v8"/>',
    send: '<path d="M4.5 12l15-7-6.8 15-2-6z"/>',
    star: '<path d="M12 3.6l2.5 5.2 5.7.8-4.1 4 1 5.7L12 16.6l-5.1 2.7 1-5.7-4.1-4 5.7-.8z"/>',
    wind: '<path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 12h15a3 3 0 1 1-3 3"/><path d="M3 16h7"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14-4.5L4 9"/><path d="M4 5v4h4"/><path d="M4 13a8 8 0 0 0 14 4.5L20 15"/><path d="M20 19v-4h-4"/>'
  };
  function icon(name, cls, extra) {
    return (
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" ' +
      'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' +
      (cls ? ' class="' + cls + '"' : "") +
      (extra || "") +
      ">" +
      (ICONS[name] || "") +
      "</svg>"
    );
  }
  function starIcon(fill, large) {
    return (
      '<svg viewBox="0 0 24 24" aria-hidden="true" fill="' + (fill ? "currentColor" : "none") +
      '" stroke="currentColor" stroke-width="1.3"' + (large ? ' width="17" height="17"' : "") + ">" +
      ICONS.star +
      "</svg>"
    );
  }
  /* Renders 0–5 stars, honouring half stars */
  function starsHTML(rating, large) {
    var out = '<span class="stars' + (large ? " stars--lg" : "") + '" role="img" aria-label="' +
      (Math.round(rating * 10) / 10) + ' out of 5 stars">';
    for (var i = 1; i <= 5; i++) out += starIcon(rating >= i - 0.25, large);
    return out + "</span>";
  }

  /* ───────────────────────────────── Reviews and star ratings
     A rating is a claim about real customers, so it is only ever displayed
     when there are real customers behind it. While
     SHR.CONFIG.claims.reviewsVerified is false this site shows no star rating,
     no review count and no customer quote anywhere — product cards, product
     pages, the reviews page and the structured data all follow the one switch,
     and the customer is told plainly why. Turn the switch on in site-data.js
     once the reviews are genuine and consented to.
     ------------------------------------------------------------------ */
  var REVIEWS_COMING_SOON = "Customer reviews coming soon.";
  function reviewsVerified() {
    return !!(CONFIG.claims && CONFIG.claims.reviewsVerified);
  }
  /* The honest block shown wherever a rating would have been */
  function reviewsGate(extra) {
    return (
      '<div class="review-gate" data-reviews-gate>' + icon("chat") +
      "<div><p><strong>" + REVIEWS_COMING_SOON + "</strong> " +
      esc(extra || "We are collecting written reviews from customers who have bought from us. Until they are in, we would rather show you nothing than invent a rating.") +
      "</p>" +
      '<a class="btn btn--whatsapp btn--sm" href="' + esc(waLink("Hello Skincare Hub Rwanda, I would like advice before I buy.")) +
      '" target="_blank" rel="noopener">' + icon("whatsapp") + "Ask us directly</a></div></div>"
    );
  }

  /* ────────────────────────────────────────── SVG illustration system
     The site ships without photography: every product, category and blog
     cover is drawn as an SVG so it stays sharp, lightweight and offline.
     ------------------------------------------------------------------ */
  var uidSeq = 0;
  function uid(prefix) {
    uidSeq += 1;
    return (prefix || "g") + uidSeq;
  }
  function shade(hex, amt) {
    var h = String(hex || "#c6a664").replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var num = parseInt(h, 16);
    if (isNaN(num)) return hex;
    var r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
    function mix(c) {
      var v = amt < 0 ? c * (1 + amt) : c + (255 - c) * amt;
      return Math.max(0, Math.min(255, Math.round(v)));
    }
    return "rgb(" + mix(r) + "," + mix(g) + "," + mix(b) + ")";
  }
  function labelText(p) {
    return esc(String(p.brand || "").toUpperCase());
  }

  /* The container shape for each product form */
  function containerShape(form, tint, id) {
    var body = "url(#" + id + "-glass)";
    switch (form) {
      case "pump":
        return (
          '<path d="M112 158h96v18c0 8-6 14-14 14h-68c-8 0-14-6-14-14z" fill="' + body + '"/>' +
          '<rect x="114" y="160" width="92" height="182" rx="16" fill="' + body + '"/>' +
          '<rect x="146" y="132" width="28" height="30" fill="' + shade(tint, 0.55) + '"/>' +
          '<rect x="138" y="112" width="44" height="20" rx="5" fill="' + tint + '"/>' +
          '<rect x="178" y="116" width="22" height="9" rx="4" fill="' + shade(tint, -0.18) + '"/>'
        );
      case "tube":
        return (
          '<path d="M120 150h80l-8 178c-1 8-11 12-32 12s-31-4-32-12z" fill="' + body + '"/>' +
          '<rect x="116" y="138" width="88" height="14" rx="4" fill="' + shade(tint, 0.4) + '"/>' +
          '<rect x="134" y="108" width="52" height="32" rx="6" fill="' + tint + '"/>'
        );
      case "jar":
        return (
          '<rect x="110" y="196" width="100" height="28" rx="9" fill="' + tint + '"/>' +
          '<rect x="114" y="218" width="92" height="124" rx="18" fill="' + body + '"/>' +
          '<rect x="130" y="188" width="60" height="12" rx="5" fill="' + shade(tint, 0.35) + '"/>'
        );
      case "tub":
        return (
          '<rect x="92" y="198" width="136" height="32" rx="11" fill="' + tint + '"/>' +
          '<rect x="96" y="222" width="128" height="118" rx="20" fill="' + body + '"/>' +
          '<rect x="112" y="190" width="96" height="12" rx="5" fill="' + shade(tint, 0.35) + '"/>'
        );
      case "dropper":
        return (
          '<rect x="130" y="176" width="60" height="166" rx="12" fill="' + body + '"/>' +
          '<rect x="146" y="148" width="28" height="30" fill="' + shade(tint, 0.5) + '"/>' +
          '<rect x="140" y="112" width="40" height="38" rx="7" fill="' + tint + '"/>' +
          '<rect x="156" y="150" width="8" height="30" rx="4" fill="' + shade(tint, -0.1) + '" opacity=".7"/>'
        );
      case "spray":
        return (
          '<rect x="118" y="172" width="84" height="170" rx="14" fill="' + body + '"/>' +
          '<rect x="148" y="148" width="24" height="26" fill="' + shade(tint, 0.5) + '"/>' +
          '<rect x="140" y="124" width="40" height="26" rx="5" fill="' + tint + '"/>' +
          '<rect x="176" y="130" width="18" height="8" rx="4" fill="' + shade(tint, -0.18) + '"/>'
        );
      default:
        return (
          '<rect x="120" y="150" width="80" height="192" rx="14" fill="' + body + '"/>' +
          '<rect x="144" y="126" width="32" height="28" fill="' + shade(tint, 0.5) + '"/>' +
          '<rect x="138" y="100" width="44" height="30" rx="6" fill="' + tint + '"/>'
        );
    }
  }

  /* -- Photography ------------------------------------------------------
     A product may carry photos: ["assets/img/name.jpg"]. When it does, the
     real photograph is shown in place of the drawing, everywhere the drawing
     would have appeared. Products with no photos keep the SVG illustration,
     so the shop still works with no image files at all.
     ------------------------------------------------------------------- */
  function productPhotos(p) {
    return p && p.photos && p.photos.length ? p.photos : [];
  }
  function photoVisual(p, src) {
    var alt = p.brand + " " + p.name + (p.size ? ", " + p.size : "");
    return '<img class="visual__photo" src="' + esc(src) + '" alt="' + esc(alt) + '" loading="lazy" decoding="async">';
  }

  /* variant: front | texture | box | photo-<n> */
  function productVisual(p, variant, opts) {
    opts = opts || {};
    variant = variant || "front";
    var photos = productPhotos(p);
    if (photos.length && opts.illustration !== true) {
      var pm = /^photo-(\d+)$/.exec(variant);
      if (pm) {
        var pi = parseInt(pm[1], 10);
        if (pi >= 0 && pi < photos.length) return photoVisual(p, photos[pi]);
      } else if (variant === "front") {
        return photoVisual(p, photos[0]);
      }
    }
    var tint = p.tint || "#c6a664";
    var id = uid("v");
    var w = 320, h = 400;
    var bg =
      '<defs>' +
      '<linearGradient id="' + id + '-bg" x1="0" y1="0" x2="0.6" y2="1">' +
      '<stop offset="0%" stop-color="' + shade(tint, 0.86) + '"/>' +
      '<stop offset="60%" stop-color="#fbfaf8"/>' +
      '<stop offset="100%" stop-color="#ffffff"/>' +
      "</linearGradient>" +
      '<linearGradient id="' + id + '-glass" x1="0" y1="0" x2="1" y2="0">' +
      '<stop offset="0%" stop-color="#ffffff"/>' +
      '<stop offset="38%" stop-color="' + shade(tint, 0.9) + '"/>' +
      '<stop offset="72%" stop-color="#ffffff"/>' +
      '<stop offset="100%" stop-color="' + shade(tint, 0.78) + '"/>' +
      "</linearGradient>" +
      '<radialGradient id="' + id + '-shadow" cx="0.5" cy="0.5" r="0.5">' +
      '<stop offset="0%" stop-color="' + shade(tint, -0.35) + '" stop-opacity=".26"/>' +
      '<stop offset="100%" stop-color="' + shade(tint, -0.35) + '" stop-opacity="0"/>' +
      "</radialGradient>" +
      '<linearGradient id="' + id + '-tex" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="' + shade(tint, 0.65) + '"/>' +
      '<stop offset="100%" stop-color="' + shade(tint, 0.2) + '"/>' +
      "</linearGradient>" +
      "</defs>";

    var open = '<svg viewBox="0 0 ' + w + " " + h + '" role="img" aria-label="' +
      esc(p.brand + " " + p.name) + '" preserveAspectRatio="xMidYMid meet">';
    var deco =
      '<rect width="' + w + '" height="' + h + '" fill="url(#' + id + '-bg)"/>' +
      '<circle cx="72" cy="86" r="46" fill="none" stroke="' + shade(tint, 0.55) + '" stroke-width="1"/>' +
      '<path d="M40 300c26-30 54-30 80 0" fill="none" stroke="' + shade(tint, 0.5) + '" stroke-width="1"/>';
    var shadow = '<ellipse cx="160" cy="348" rx="104" ry="18" fill="url(#' + id + '-shadow)"/>';

    if (variant === "texture") {
      open += bg + deco;
      open +=
        '<circle cx="160" cy="212" r="104" fill="#fff"/>' +
        '<circle cx="160" cy="212" r="104" fill="none" stroke="' + shade(tint, 0.5) + '" stroke-width="1"/>' +
        '<path d="M96 226c14-34 34-52 60-52 28 0 44 18 46 44 2 24-22 42-56 42-32 0-58-14-50-34z" fill="url(#' + id + '-tex)"/>' +
        '<circle cx="126" cy="196" r="17" fill="#ffffff" opacity=".55"/>' +
        '<circle cx="196" cy="238" r="11" fill="#ffffff" opacity=".45"/>' +
        '<circle cx="152" cy="252" r="7" fill="#ffffff" opacity=".5"/>' +
        '<text x="160" y="352" text-anchor="middle" font-family="Inter, Segoe UI, sans-serif" font-size="12" letter-spacing="3" fill="' + shade(tint, -0.25) + '">TEXTURE</text>';
      return open + "</svg>";
    }

    if (variant === "box") {
      open += bg + deco;
      open +=
        '<path d="M78 168l82-38 82 38v128l-82 38-82-38z" fill="#ffffff" stroke="' + shade(tint, 0.42) + '" stroke-width="1.4"/>' +
        '<path d="M78 168l82 38 82-38" fill="none" stroke="' + shade(tint, 0.42) + '" stroke-width="1.4"/>' +
        '<path d="M160 206v128" fill="none" stroke="' + shade(tint, 0.42) + '" stroke-width="1.4"/>' +
        '<rect x="96" y="212" width="46" height="7" rx="3.5" fill="' + shade(tint, 0.55) + '"/>' +
        '<rect x="96" y="228" width="30" height="5" rx="2.5" fill="' + shade(tint, 0.72) + '"/>' +
        '<rect x="104" y="284" width="112" height="86" rx="10" fill="' + tint + '"/>' +
        '<rect x="132" y="266" width="52" height="20" rx="5" fill="' + shade(tint, -0.16) + '"/>' +
        '<text x="160" y="334" text-anchor="middle" font-family="Inter, Segoe UI, sans-serif" font-size="11" letter-spacing="2.4" fill="#ffffff">' +
        labelText(p) +
        "</text>" +
        (p.size
          ? '<text x="160" y="352" text-anchor="middle" font-family="Inter, Segoe UI, sans-serif" font-size="9" fill="#ffffff" opacity=".85">' + esc(p.size) + "</text>"
          : "");
      return open + "</svg>";
    }

    /* front */
    open += bg + deco + shadow + containerShape(p.form, tint, id);
    /* label */
    var labelY = p.form === "jar" || p.form === "tub" ? 258 : 236;
    var labelH = p.form === "jar" || p.form === "tub" ? 54 : 68;
    open +=
      '<rect x="126" y="' + labelY + '" width="68" height="' + labelH + '" rx="5" fill="#ffffff" opacity=".94"/>' +
      '<rect x="126" y="' + labelY + '" width="68" height="4" fill="' + tint + '" opacity=".85"/>' +
      '<text x="160" y="' + (labelY + 24) + '" text-anchor="middle" font-family="Inter, Segoe UI, sans-serif" ' +
      'font-size="9.5" font-weight="600" letter-spacing="1.6" fill="' + shade(tint, -0.3) + '">' +
      labelText(p) +
      "</text>" +
      '<rect x="138" y="' + (labelY + 32) + '" width="44" height="3" rx="1.5" fill="' + shade(tint, 0.5) + '"/>' +
      '<rect x="146" y="' + (labelY + 41) + '" width="28" height="3" rx="1.5" fill="' + shade(tint, 0.68) + '"/>' +
      (p.size
        ? '<text x="160" y="' + (labelY + labelH - 8) + '" text-anchor="middle" font-family="Inter, Segoe UI, sans-serif" font-size="7.5" letter-spacing="0.6" fill="#7a889c">' +
          esc(p.size) +
          "</text>"
        : "");
    /* glass highlight */
    open +=
      '<path d="M136 ' + (p.form === "jar" || p.form === "tub" ? 226 : 166) + 'v118" stroke="#ffffff" stroke-width="7" opacity=".55" stroke-linecap="round"/>' +
      '<text x="160" y="382" text-anchor="middle" font-family="Inter, Segoe UI, sans-serif" font-size="10" letter-spacing="3.4" fill="' +
      shade(tint, -0.2) + '">AUTHENTIC</text>';
    return open + "</svg>";
  }

  /* Abstract cover art for blog posts and category tiles */
  function coverArt(opts) {
    opts = opts || {};
    var tint = opts.tint || "#c6a664";
    var pattern = opts.pattern || "arcs";
    var label = opts.label || "";
    var id = uid("c");
    var w = 640, h = 400;
    var svg =
      '<svg viewBox="0 0 ' + w + " " + h + '" role="img" aria-label="' + esc(label || "Skincare Hub Rwanda") +
      '" preserveAspectRatio="xMidYMid slice"><defs>' +
      '<linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="' + shade(tint, 0.78) + '"/>' +
      '<stop offset="55%" stop-color="' + shade(tint, 0.92) + '"/>' +
      '<stop offset="100%" stop-color="#ffffff"/>' +
      "</linearGradient>" +
      "</defs>" +
      '<rect width="' + w + '" height="' + h + '" fill="url(#' + id + ')"/>';
    var stroke = shade(tint, -0.05);
    var soft = shade(tint, 0.5);

    if (pattern === "waves") {
      svg +=
        '<path d="M-20 250c90-60 170 40 260-10s170 40 260-10 130 20 180 0" fill="none" stroke="' + stroke + '" stroke-width="2"/>' +
        '<path d="M-20 296c90-60 170 40 260-10s170 40 260-10 130 20 180 0" fill="none" stroke="' + soft + '" stroke-width="1.4"/>' +
        '<path d="M-20 204c90-60 170 40 260-10s170 40 260-10 130 20 180 0" fill="none" stroke="' + soft + '" stroke-width="1.1"/>' +
        '<circle cx="500" cy="96" r="54" fill="' + shade(tint, 0.62) + '" opacity=".55"/>';
    } else if (pattern === "dots") {
      for (var r = 0; r < 6; r++) {
        for (var c = 0; c < 9; c++) {
          svg +=
            '<circle cx="' + (56 + c * 66) + '" cy="' + (66 + r * 58) + '" r="' + (3 + ((r + c) % 3)) +
            '" fill="' + stroke + '" opacity="' + (0.22 + ((r * c) % 4) * 0.14) + '"/>';
        }
      }
      svg += '<circle cx="120" cy="300" r="78" fill="' + shade(tint, 0.55) + '" opacity=".5"/>';
    } else if (pattern === "rings") {
      svg +=
        '<circle cx="320" cy="212" r="150" fill="none" stroke="' + soft + '" stroke-width="1.4"/>' +
        '<circle cx="320" cy="212" r="108" fill="none" stroke="' + stroke + '" stroke-width="1.8"/>' +
        '<circle cx="320" cy="212" r="66" fill="' + shade(tint, 0.66) + '" opacity=".6"/>' +
        '<circle cx="470" cy="120" r="16" fill="' + stroke + '" opacity=".4"/>';
    } else if (pattern === "grid") {
      for (var gx = 0; gx < 13; gx++) {
        svg += '<path d="M' + (gx * 56) + ' 0V' + h + '" stroke="' + soft + '" stroke-width="1" opacity=".5"/>';
      }
      for (var gy = 0; gy < 8; gy++) {
        svg += '<path d="M0 ' + (gy * 56) + 'H' + w + '" stroke="' + soft + '" stroke-width="1" opacity=".5"/>';
      }
      svg +=
        '<rect x="184" y="128" width="272" height="144" rx="14" fill="#ffffff" opacity=".72"/>' +
        '<rect x="216" y="164" width="140" height="9" rx="4.5" fill="' + stroke + '" opacity=".5"/>' +
        '<rect x="216" y="188" width="92" height="7" rx="3.5" fill="' + soft + '"/>';
    } else if (pattern === "stripes") {
      for (var s = 0; s < 14; s++) {
        svg +=
          '<path d="M' + (20 + s * 48) + ' -40V440" stroke="' + (s % 2 ? soft : stroke) + '" stroke-width="' +
          (s % 2 ? 8 : 2) + '" opacity="' + (s % 2 ? 0.35 : 0.55) + '"/>';
      }
      svg += '<rect x="60" y="150" width="180" height="180" rx="90" fill="' + shade(tint, 0.6) + '" opacity=".45"/>';
    } else if (pattern === "blob") {
      svg +=
        '<path d="M170 92c58-30 128 0 152 56 24 58-12 118-64 138-52 20-118 6-146-38-28-44-4-126 58-156z" fill="' + shade(tint, 0.6) + '" opacity=".55"/>' +
        '<path d="M226 150c34-18 74 0 88 32 14 34-8 70-38 82-30 12-68 4-84-22-16-26-2-74 34-92z" fill="' + shade(tint, 0.44) + '" opacity=".5"/>';
    } else {
      svg +=
        '<path d="M-10 340c70-140 150-210 240-210s150 70 200 210" fill="none" stroke="' + stroke + '" stroke-width="2"/>' +
        '<path d="M-10 380c80-140 160-210 250-210s140 70 190 210" fill="none" stroke="' + soft + '" stroke-width="1.3"/>' +
        '<circle cx="250" cy="140" r="42" fill="' + shade(tint, 0.62) + '" opacity=".6"/>';
    }
    return svg + "</svg>";
  }

  /* ─────────────────────────────────────────────── Catalog queries */
  function getProduct(id) {
    for (var i = 0; i < PRODUCTS.length; i++) {
      if (PRODUCTS[i].id === id) return PRODUCTS[i];
    }
    return null;
  }
  function getProducts(ids) {
    return arr(ids)
      .map(getProduct)
      .filter(Boolean);
  }
  function inCategory(p, catId) {
    if (!catId || catId === "all") return true;
    return (
      p.category === catId ||
      (p.also || []).indexOf(catId) >= 0 ||
      (p.collections || []).indexOf(catId) >= 0
    );
  }
  function brandById(id) {
    for (var i = 0; i < SHR.BRANDS.length; i++) {
      if (SHR.BRANDS[i].id === id) return SHR.BRANDS[i];
    }
    return { id: id, name: titleCase(String(id).replace(/-/g, " ")) };
  }
  function categoryById(id) {
    for (var i = 0; i < SHR.CATEGORIES.length; i++) {
      if (SHR.CATEGORIES[i].id === id) return SHR.CATEGORIES[i];
    }
    return { id: id, name: titleCase(String(id).replace(/-/g, " ")), blurb: "" };
  }
  var CONCERN_INDEX = (function () {
    var map = {};
    (SHR.CONCERNS || []).forEach(function (c) {
      map[c.id] = c;
    });
    return map;
  })();
  function concernLabel(id) {
    return (CONCERN_INDEX[id] || { label: titleCase(String(id).replace(/-/g, " ")) }).label;
  }
  function skinTypeLabel(id) {
    var found = null;
    (SHR.SKIN_TYPES || []).forEach(function (s) {
      if (s.id === id) found = s;
    });
    return found ? found.label : titleCase(String(id).replace(/-/g, " "));
  }
  function countInCategory(catId) {
    return PRODUCTS.filter(function (p) {
      return inCategory(p, catId);
    }).length;
  }
  /* ── Concern facets ────────────────────────────────────────────────────
     The eight customer-facing groups used by the home page cards, the menu
     and the shop's concern filter. A facet can cover several concerns ("Skin
     barrier" is the dry and the sensitive products) or a whole category
     ("Sunscreen"). Nothing here invents a concern the catalogue does not
     already tag, so a facet can never open an empty shelf.
     ------------------------------------------------------------------ */
  var CONCERN_FACET_INDEX = (function () {
    var map = {};
    (SHR.CONCERN_FACETS || []).forEach(function (f) {
      map[f.id] = f;
    });
    return map;
  })();
  function concernFacet(id) {
    return CONCERN_FACET_INDEX[id] || null;
  }
  function concernHref(facet) {
    if (!facet) return "shop.html";
    if (facet.category) return "shop.html?category=" + facet.category;
    var values = facet.values || [];
    if (!values.length) return "shop.html";
    return "shop.html?concern=" + values.join("&concern=");
  }
  /* Whatever the shop's concern filter holds — facet ids, real concern ids, or
     both — becomes the concern ids the catalogue is tagged with. */
  function expandConcerns(list) {
    var out = [];
    arr(list).forEach(function (v) {
      var facet = concernFacet(v);
      var values = facet && facet.values && facet.values.length ? facet.values : [v];
      values.forEach(function (x) {
        if (out.indexOf(x) < 0) out.push(x);
      });
    });
    return out;
  }
  function facetProducts(facet) {
    if (!facet) return [];
    if (facet.category) return filterProducts({ categories: facet.category });
    if (facet.categories) return filterProducts({ categories: facet.categories });
    return filterProducts({ concerns: facet.values });
  }

  /* ── Category facets: the shop's category checkboxes ─────────────────── */
  var CATEGORY_FACET_INDEX = (function () {
    var map = {};
    (SHR.CATEGORY_FACETS || []).forEach(function (f) {
      map[f.id] = f;
    });
    return map;
  })();
  function categoryFacet(id) {
    return CATEGORY_FACET_INDEX[id] || null;
  }
  /* A facet id ("treatments") becomes the catalogue categories it covers; a
     real category id passes straight through, so every existing link keeps
     working. */
  function expandCategories(list) {
    var out = [];
    arr(list).forEach(function (v) {
      var facet = categoryFacet(v);
      var values = facet ? facet.categories : [v];
      (values || []).forEach(function (x) {
        if (out.indexOf(x) < 0) out.push(x);
      });
    });
    return out;
  }
  function countCategories(values) {
    var cats = arr(values);
    return PRODUCTS.filter(function (p) {
      return cats.some(function (c) {
        return inCategory(p, c);
      });
    }).length;
  }
  function productHaystack(p) {
    return [
      p.name,
      p.brand,
      categoryById(p.category).name,
      (p.also || []).map(function (c) {
        return categoryById(c).name;
      }).join(" "),
      (p.concerns || []).map(concernLabel).join(" "),
      (p.skinTypes || []).map(skinTypeLabel).join(" "),
      p.short,
      p.size,
      p.texture
    ]
      .join(" ")
      .toLowerCase();
  }
  function searchProducts(q, limit) {
    var term = String(q || "").trim().toLowerCase();
    if (!term) return [];
    var words = term.split(/\s+/);
    var hits = PRODUCTS.map(function (p) {
      var hay = productHaystack(p);
      var name = (p.name + " " + p.brand).toLowerCase();
      var score = 0;
      words.forEach(function (wd) {
        if (name.indexOf(wd) === 0) score += 6;
        else if (name.indexOf(wd) >= 0) score += 4;
        if (hay.indexOf(wd) >= 0) score += 2;
        else score -= 5;
      });
      return { p: p, score: score };
    })
      .filter(function (x) {
        return x.score > 0;
      })
      .sort(function (a, b) {
        return b.score - a.score || b.p.rating - a.p.rating;
      })
      .map(function (x) {
        return x.p;
      });
    return limit ? hits.slice(0, limit) : hits;
  }
  function sortProducts(list, sort) {
    var out = list.slice();
    switch (sort) {
      case "price-asc":
        return out.sort(function (a, b) {
          return a.price - b.price;
        });
      case "price-desc":
        return out.sort(function (a, b) {
          return b.price - a.price;
        });
      case "rating":
        return out.sort(function (a, b) {
          return b.rating - a.rating || b.reviewCount - a.reviewCount;
        });
      case "name":
        return out.sort(function (a, b) {
          return (a.brand + a.name).localeCompare(b.brand + b.name);
        });
      case "newest": {
        /* The catalogue carries no added-date, so "newest" follows the shop's
           own order: the new-arrivals collection first, then the products
           added most recently, which sit at the end of catalog.js. */
        return out.sort(function (a, b) {
          var an = (a.collections || []).indexOf("new-arrivals") >= 0 ? 1 : 0;
          var bn = (b.collections || []).indexOf("new-arrivals") >= 0 ? 1 : 0;
          if (an !== bn) return bn - an;
          return PRODUCTS.indexOf(b) - PRODUCTS.indexOf(a);
        });
      }
      case "featured":
      default:
        return out.sort(function (a, b) {
          var ab = (a.collections || []).indexOf("best-sellers") >= 0 ? 1 : 0;
          var bb = (b.collections || []).indexOf("best-sellers") >= 0 ? 1 : 0;
          if (ab !== bb) return bb - ab;
          var as = a.was > 0 ? 1 : 0;
          var bs = b.was > 0 ? 1 : 0;
          if (as !== bs) return bs - as;
          return b.rating - a.rating;
        });
    }
  }
  function filterProducts(o) {
    o = o || {};
    var list = PRODUCTS.slice();
    var cats = arr(o.categories !== undefined ? o.categories : o.category);
    var brands = arr(o.brands !== undefined ? o.brands : o.brand);
    var skinTypes = arr(o.skinTypes);
    var concerns = arr(o.concerns);
    if (cats.length) list = list.filter(function (p) { return cats.some(function (c) { return inCategory(p, c); }); });
    if (brands.length) list = list.filter(function (p) { return brands.indexOf(p.brandId) >= 0; });
    if (skinTypes.length) list = list.filter(function (p) { return skinTypes.some(function (s) { return (p.skinTypes || []).indexOf(s) >= 0; }); });
    if (concerns.length) list = list.filter(function (p) { return concerns.some(function (c) { return (p.concerns || []).indexOf(c) >= 0; }); });
    if (o.min) list = list.filter(function (p) { return p.price >= Number(o.min); });
    if (o.max) list = list.filter(function (p) { return p.price <= Number(o.max); });
    if (o.only === "sale") list = list.filter(function (p) { return p.was > p.price; });
    if (o.only === "new") list = list.filter(function (p) { return (p.collections || []).indexOf("new-arrivals") >= 0; });
    if (o.only === "instock") list = list.filter(function (p) { return p.stock !== "out"; });
    /* stock status, as its own facet in the shop */
    if (o.stock === "instock") list = list.filter(function (p) { return p.stock !== "out"; });
    if (o.stock === "low") list = list.filter(function (p) { return p.stock === "low"; });
    if (o.stock === "out") list = list.filter(function (p) { return p.stock === "out"; });
    if (o.q) {
      var hits = searchProducts(o.q);
      var ids = {};
      hits.forEach(function (p) { ids[p.id] = true; });
      list = list.filter(function (p) { return ids[p.id]; });
      return sortProducts(list, o.sort === "featured" || !o.sort ? "featured" : o.sort).sort(function (a, b) {
        return hits.indexOf(a) - hits.indexOf(b);
      });
    }
    return sortProducts(list, o.sort);
  }
  /* Related products: same category first, then shared concerns and skin types */
  /* How well b fits what a is: same shelf, shared concerns and skin types,
     same brand, similar price. One scorer, used by both the "you may also
     need" list and the routine builder on the product page. */
  function relatedToScore(a, b) {
    var s = 0;
    if (b.category === a.category) s += 4;
    if ((b.also || []).indexOf(a.category) >= 0) s += 2;
    if (a.category && inCategory(b, a.category)) s += 1;
    (b.concerns || []).forEach(function (c) {
      if ((a.concerns || []).indexOf(c) >= 0) s += 2;
    });
    (b.skinTypes || []).forEach(function (t) {
      if ((a.skinTypes || []).indexOf(t) >= 0) s += 1;
    });
    if (b.brandId === a.brandId) s += 3;
    var gap = Math.abs(b.price - a.price) / Math.max(a.price, 1);
    if (gap < 0.35) s += 1.5;
    if (b.stock === "low") s -= 0.5;
    return s;
  }
  /* Why a product was chosen for a routine, in one honest sentence built from
     the catalogue rather than from a marketing script. */
  function fitReason(base, p) {
    var shared = (p.concerns || []).filter(function (c) {
      return (base.concerns || []).indexOf(c) >= 0;
    });
    var bits = [];
    var skin = (base.skinTypes || [])[0];
    if (skin && (p.skinTypes || []).indexOf(skin) >= 0) {
      bits.push("it suits " + skinTypeLabel(skin).toLowerCase() + " skin, the same as this one");
    }
    if (shared.length) {
      bits.push("it also works on " + shared.slice(0, 2).map(concernLabel).join(" and ").toLowerCase());
    }
    if (!bits.length) bits.push("it is the closest match on this shelf at a similar price");
    return "Chosen because " + bits.join(", and ") + ".";
  }
  function relatedTo(product, n) {
    var limit = n || 4;
    return PRODUCTS.filter(function (p) {
      return p.id !== product.id;
    })
      .map(function (p) {
        return { p: p, s: relatedToScore(product, p) + p.rating / 10 };
      })
      .sort(function (a, b) { return b.s - a.s; })
      .slice(0, limit)
      .map(function (x) { return x.p; });
  }
  function ratingBreakdown(p) {
    var total = p.reviewCount || 0;
    var dist = [5, 4, 3, 2, 1].map(function (star) {
      /* distribution derived from the product's average rating */
      var weight = Math.max(0, 1 - Math.abs(p.rating - star) * 0.62);
      return { star: star, weight: weight };
    });
    var sum = dist.reduce(function (a, d) { return a + d.weight; }, 0) || 1;
    return dist.map(function (d) {
      var count = Math.round((d.weight / sum) * total);
      return { star: d.star, count: count, percent: Math.round((count / (total || 1)) * 100) };
    });
  }
  function priceBand(p) {
    if (p.price < 30000) return "budget";
    if (p.price < 55000) return "mid";
    return "premium";
  }

  /* ──────────────────────────────────────────────────────── Toast */
  function toastHost() {
    var host = $(".toasts");
    if (!host) {
      host = document.createElement("div");
      host.className = "toasts";
      host.setAttribute("role", "status");
      host.setAttribute("aria-live", "polite");
      document.body.appendChild(host);
    }
    return host;
  }
  function toast(msg, opts) {
    opts = opts || {};
    var host = toastHost();
    var node = document.createElement("div");
    node.className = "toast" + (opts.kind === "gold" ? " toast--gold" : "");
    node.innerHTML =
      icon(opts.icon || "checkCircle") +
      "<span>" + esc(msg) + "</span>" +
      (opts.action
        ? '<a class="toast__action" href="' + esc(opts.action.href) + '">' + esc(opts.action.label) + "</a>"
        : "");
    host.appendChild(node);
    var life = opts.timeout || 4200;
    setTimeout(function () {
      node.classList.add("is-leaving");
      setTimeout(function () {
        if (node.parentNode) node.parentNode.removeChild(node);
      }, 320);
    }, life);
    return node;
  }

  /* ───────────────────────────────────────────────────────── Cart */
  var CART_KEY = "cart";
  var cart = store.get(CART_KEY, { items: [], promo: null }) || { items: [], promo: null };
  if (!Array.isArray(cart.items)) cart.items = [];
  var cartListeners = [];

  function cartSave() {
    store.set(CART_KEY, cart);
    cartListeners.forEach(function (fn) {
      try { fn(cart); } catch (e) {}
    });
  }
  function onCart(fn) {
    cartListeners.push(fn);
  }
  function cartItem(id) {
    for (var i = 0; i < cart.items.length; i++) {
      if (cart.items[i].id === id) return cart.items[i];
    }
    return null;
  }
  function cartAdd(id, qty, opts) {
    opts = opts || {};
    var p = getProduct(id);
    if (!p) return null;
    if (p.stock === "out") {
      toast("That product is out of stock", { icon: "alert" });
      return null;
    }
    var line = cartItem(id);
    var amount = Math.max(1, Number(qty) || 1);
    if (line) line.qty = Math.min(12, line.qty + amount);
    else cart.items.push({ id: id, qty: amount });
    cartSave();
    if (!opts.silent) {
      toast(p.name + " added to your cart", {
        kind: "gold",
        icon: "cart",
        action: { label: "View cart", href: "cart.html" }
      });
    }
    if (SHR.api.analytics) SHR.api.analytics.event("add_to_cart", { item_id: id, value: p.price * amount, currency: CONFIG.currency });
    return line || cart.items[cart.items.length - 1];
  }
  function cartSetQty(id, qty) {
    var line = cartItem(id);
    if (!line) return;
    var n = Number(qty) || 0;
    if (n <= 0) return cartRemove(id);
    line.qty = Math.min(12, n);
    cartSave();
  }
  function cartRemove(id) {
    cart.items = cart.items.filter(function (l) {
      return l.id !== id;
    });
    cartSave();
  }
  function cartClear() {
    cart.items = [];
    cart.promo = null;
    cartSave();
  }
  function cartCount() {
    return cart.items.reduce(function (n, l) {
      return n + l.qty;
    }, 0);
  }
  function cartDetailed() {
    return cart.items
      .map(function (l) {
        var p = getProduct(l.id);
        if (!p) return null;
        return {
          product: p,
          qty: l.qty,
          lineTotal: p.price * l.qty,
          lineWas: (p.was || p.price) * l.qty
        };
      })
      .filter(Boolean);
  }
  function cartSubtotal() {
    return cartDetailed().reduce(function (n, l) {
      return n + l.lineTotal;
    }, 0);
  }
  function promoApply(code) {
    var key = String(code || "").trim().toUpperCase();
    var promo = CONFIG.promos[key];
    if (!promo) return { ok: false, message: "That code is not valid. Check it and try again." };
    cart.promo = key;
    cartSave();
    return { ok: true, message: promo.label + " applied.", promo: promo };
  }
  function promoRemove() {
    cart.promo = null;
    cartSave();
  }
  function discountAmount() {
    if (!cart.promo) return 0;
    var promo = CONFIG.promos[cart.promo];
    if (!promo) return 0;
    if (promo.type === "fixed") return Math.min(promo.value, cartSubtotal());
    if (promo.type === "percent" && cart.promo === "KOREAN15") {
      var korean = cartDetailed().filter(function (l) {
        return (l.product.also || []).indexOf("korean-skincare") >= 0 || l.product.category === "korean-skincare";
      });
      var base = korean.reduce(function (n, l) { return n + l.lineTotal; }, 0);
      return Math.round((base * promo.value) / 100);
    }
    return Math.round((cartSubtotal() * promo.value) / 100);
  }
  function shippingFor(optionId) {
    var opt = (SHR.SHIPPING_OPTIONS || []).filter(function (o) { return o.id === optionId; })[0];
    if (!opt) return 0;
    if (opt.fee > 0 && cartSubtotal() >= CONFIG.delivery.freeFrom) return 0;
    return opt.fee;
  }
  function shippingDefault() {
    return shippingFor("kigali");
  }
  function cartTotal() {
    return Math.max(0, cartSubtotal() - discountAmount() + shippingDefault());
  }
  function freeDeliveryProgress() {
    var sub = cartSubtotal();
    var goal = CONFIG.delivery.freeFrom;
    return { now: sub, goal: goal, remaining: Math.max(0, goal - sub), percent: Math.min(100, Math.round((sub / goal) * 100)) };
  }
  /* Is the free-delivery policy the site advertises actually switched on? The
     announce bar, the cart bar and the product page all ask this, so the claim
     disappears everywhere the moment it stops being true. */
  function freeDeliveryActive() {
    return !!(
      CONFIG.claims &&
      CONFIG.claims.freeDeliveryActive !== false &&
      CONFIG.delivery &&
      CONFIG.delivery.freeFrom > 0
    );
  }

  /* ────────────────────────────────────────────────────── Wishlist */
  var WISH_KEY = "wishlist";
  var wishlist = store.get(WISH_KEY, []);
  if (!Array.isArray(wishlist)) wishlist = [];
  var wishListeners = [];
  function wishSave() {
    store.set(WISH_KEY, wishlist);
    wishListeners.forEach(function (fn) {
      try { fn(wishlist); } catch (e) {}
    });
  }
  function onWishlist(fn) {
    wishListeners.push(fn);
  }
  function wishHas(id) {
    return wishlist.indexOf(id) >= 0;
  }
  function wishToggle(id) {
    var p = getProduct(id);
    if (wishHas(id)) {
      wishlist = wishlist.filter(function (x) {
        return x !== id;
      });
      wishSave();
      toast((p ? p.name : "Product") + " removed from your wishlist", { icon: "heart" });
      return false;
    }
    wishlist.push(id);
    wishSave();
    toast((p ? p.name : "Product") + " saved to your wishlist", {
      kind: "gold",
      icon: "heart",
      action: { label: "View list", href: "wishlist.html" }
    });
    return true;
  }
  function wishList() {
    return getProducts(wishlist);
  }
  function wishCount() {
    return wishlist.length;
  }

  /* ────────────────────────────────────── Recently viewed + orders */
  function trackViewed(id) {
    var list = store.get("recent", []);
    if (!Array.isArray(list)) list = [];
    list = list.filter(function (x) {
      return x !== id;
    });
    list.unshift(id);
    store.set("recent", list.slice(0, 8));
  }
  function recentlyViewed(n) {
    var list = store.get("recent", []);
    return getProducts(Array.isArray(list) ? list.slice(0, n || 4) : []);
  }
  function orderRef() {
    var d = new Date();
    var stamp = String(d.getFullYear()).slice(2) + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0");
    return "SHR-" + stamp + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
  }
  function placeOrder(order) {
    var orders = store.get("orders", []);
    if (!Array.isArray(orders)) orders = [];
    var record = {
      ref: order.ref || orderRef(),
      date: new Date().toISOString(),
      status: "pending",
      items: order.items || cartDetailed().map(function (l) {
        return { id: l.product.id, name: l.product.name, brand: l.product.brand, qty: l.qty, price: l.product.price };
      }),
      totals: order.totals || {
        subtotal: cartSubtotal(),
        discount: discountAmount(),
        shipping: shippingDefault(),
        total: cartTotal()
      },
      customer: order.customer || {},
      payment: order.payment || "",
      shipping: order.shipping || "",
      paymentStatus: order.paymentStatus || "unpaid",
      transactionRef: order.transactionRef || "",
      paidAt: order.paidAt || ""
    };
    orders.unshift(record);
    store.set("orders", orders.slice(0, 20));
    if (SHR.api.analytics) SHR.api.analytics.event("purchase", { transaction_id: record.ref, value: record.totals.total, currency: CONFIG.currency });
    return record;
  }
  function getOrders() {
    var orders = store.get("orders", []);
    return Array.isArray(orders) ? orders : [];
  }
  /* Patch one stored order — used when a payment succeeds, is cancelled or is
     still being checked, so the status on the order matches reality. */
  function updateOrder(ref, patch) {
    var found = null;
    var next = getOrders().map(function (o) {
      if (o.ref !== ref) return o;
      found = Object.assign({}, o, patch || {}, { updated: new Date().toISOString() });
      return found;
    });
    if (found) store.set("orders", next);
    return found;
  }
  function getUser() {
    return store.get("user", null);
  }
  function setUser(user) {
    return store.set("user", user);
  }

  /* ────────────────────────────────────────────────── WhatsApp */
  function waLink(message) {
    var digits = String(CONFIG.whatsapp).replace(/[^0-9]/g, "");
    var text = message || "Hello Skincare Hub Rwanda, I would like some help with my skincare.";
    return "https://wa.me/" + digits + "?text=" + encodeURIComponent(text);
  }
  function waProduct(p) {
    return waLink(
      "Hello Skincare Hub Rwanda, I am interested in " + p.brand + " " + p.name +
      " (" + p.size + ", " + money(p.price) + "). Is it in stock and how fast can you deliver?"
    );
  }

  /* ─────────────────────────────────────────── Forms: validate + send
     No backend is required. If CONFIG.analytics.formsEndpoint is set the
     submission is POSTed there; otherwise it is handed to WhatsApp so the
     enquiry is never lost. Either way the visitor sees a written summary.
     ------------------------------------------------------------------ */
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;
  var PHONE_RE = /^(\+?25)?0?7[2389]\d{7}$/;
  function normalisePhone(v) {
    return String(v || "").replace(/[\s\-()]/g, "");
  }
  function validateForm(form) {
    var errors = {};
    var values = {};
    $$("[name]", form).forEach(function (field) {
      var name = field.name;
      if (field.type === "checkbox") {
        values[name] = field.checked;
        return;
      }
      if (field.type === "radio") {
        if (field.checked) values[name] = field.value;
        else if (values[name] === undefined) values[name] = "";
        return;
      }
      if (field.type === "file") {
        values[name] = $$("input[type=file]", form).length ? form.querySelector("input[type=file]").files.length : 0;
        return;
      }
      values[name] = String(field.value || "").trim();
    });
    $$("[data-required]", form).forEach(function (field) {
      var name = field.name;
      var val = values[name];
      var bad = val === undefined || val === null || val === "" || val === false;
      if (field.type === "checkbox" && !field.checked) bad = true;
      if (!bad && field.getAttribute("data-type") === "phone" && !PHONE_RE.test(normalisePhone(val))) bad = true;
      if (!bad && field.getAttribute("data-type") === "email" && !EMAIL_RE.test(val)) bad = true;
      if (bad) errors[name] = field.getAttribute("data-error") || "Please complete this field.";
    });
    return { ok: Object.keys(errors).length === 0, values: values, errors: errors };
  }
  function clearFieldErrors(form) {
    $$(".field", form).forEach(function (f) {
      f.classList.remove("has-error");
    });
    $$(".error-text", form).forEach(function (e) {
      e.textContent = "";
    });
    var status = $(".form-status", form);
    if (status) status.classList.remove("is-shown");
  }
  function showFieldErrors(form, errors) {
    Object.keys(errors).forEach(function (name) {
      var field = form.querySelector('[name="' + name + '"]');
      if (!field) return;
      var wrap = field.closest(".field") || field.parentNode;
      if (!wrap) return;
      wrap.classList.add("has-error");
      var msg = $(".error-text", wrap);
      if (msg) msg.textContent = errors[name];
    });
    var first = form.querySelector(".field.has-error input, .field.has-error select, .field.has-error textarea");
    if (first && first.focus) first.focus();
  }
  function statusNode(form) {
    var node = $(".form-status", form);
    if (node) return node;
    node = document.createElement("div");
    node.className = "form-status";
    form.appendChild(node);
    return node;
  }
  function showStatus(form, kind, html) {
    var node = statusNode(form);
    node.className = "form-status form-status--" + (kind === "ok" ? "ok" : "err") + " is-shown";
    node.innerHTML = icon(kind === "ok" ? "checkCircle" : "alert") + "<div>" + html + "</div>";
  }
  /* Compose a readable message out of the submitted values */
  function messageFrom(values, labels) {
    labels = labels || {};
    var lines = [];
    Object.keys(values).forEach(function (k) {
      var v = values[k];
      if (v === "" || v === undefined || v === null || v === false) return;
      if (typeof v === "boolean") v = "Yes";
      var label = labels[k] || titleCase(k.replace(/[-_]/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2"));
      lines.push(label + ": " + v);
    });
    return lines.join("\n");
  }
  function submitForm(form, opts) {
    opts = opts || {};
    clearFieldErrors(form);
    var result = validateForm(form);
    if (!result.ok) {
      showFieldErrors(form, result.errors);
      showStatus(form, "err", "Please check the highlighted fields and try again.");
      return { ok: false, values: result.values };
    }
    form.querySelectorAll(".field.has-error").forEach(function (f) {
      f.classList.remove("has-error");
    });
    var message = opts.intro ? opts.intro + "\n\n" + messageFrom(result.values, opts.labels) : messageFrom(result.values, opts.labels);
    var endpoint = CONFIG.analytics.formsEndpoint;
    var submitBtn = form.querySelector('[type="submit"]');
    if (submitBtn) submitBtn.setAttribute("aria-disabled", "true");

    function done(channel) {
      if (submitBtn) submitBtn.removeAttribute("aria-disabled");
      var wa = waLink(message);
      showStatus(
        form,
        "ok",
        "<div><strong>" + esc(opts.successTitle || "Thank you — your message is on its way.") + "</strong>" +
          "<p class='mt-1'>" + esc(opts.successNote || "A skincare advisor replies within one working day.") + "</p>" +
          "<p class='mt-2'><a class='btn btn--whatsapp btn--sm' href='" + esc(wa) + "' target='_blank' rel='noopener'>" +
          icon("whatsapp") + " Send it on WhatsApp now</a></p></div>"
      );
      form.reset();
      if (opts.onSuccess) opts.onSuccess(result.values, message);
      if (SHR.api.analytics) SHR.api.analytics.event("generate_lead", { form: opts.name || form.id || "form", channel: channel });
    }

    if (endpoint) {
      var payload = { form: opts.name || form.id || "form", values: result.values };
      try {
        fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify(payload)
        })
          .then(function (res) {
            done(res && res.ok ? "endpoint" : "whatsapp");
          })
          .catch(function () {
            done("whatsapp");
          });
      } catch (e) {
        done("whatsapp");
      }
    } else {
      done("whatsapp");
    }
    return { ok: true, values: result.values, message: message };
  }

  /* ────────────────────────────────────────────────── Analytics */
  var analytics = {
    ready: false,
    init: function () {
      var id = CONFIG.analytics && CONFIG.analytics.gaMeasurementId;
      window.dataLayer = window.dataLayer || [];
      if (!id || this.ready) return;
      var s = document.createElement("script");
      s.async = true;
      s.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(id);
      document.head.appendChild(s);
      window.gtag = window.gtag || function () {
        window.dataLayer.push(arguments);
      };
      window.gtag("js", new Date());
      window.gtag("config", id, { anonymize_ip: true });
      this.ready = true;
    },
    page: function (name, params) {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push(Object.assign({ event: "page_view", page_name: name }, params || {}));
      if (typeof window.gtag === "function") window.gtag("event", "page_view", Object.assign({ page_name: name }, params || {}));
    },
    event: function (name, params) {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push(Object.assign({ event: name }, params || {}));
      if (typeof window.gtag === "function") window.gtag("event", name, params || {});
    }
  };

  /* ──────────────────────────────────────────── Product card markup */
  function stockBadge(p) {
    if (p.stock === "out") return '<span class="badge badge--out">Out of stock</span>';
    if (p.stock === "low") return '<span class="badge badge--low">Low stock</span>';
    return "";
  }
  function productBadges(p) {
    var out = "";
    /* The badge states the shop's rule rather than a recomputed percentage:
       one discount, everywhere. See SHR.PRICING in site-data.js. */
    if (p.was > p.price) out += '<span class="badge badge--sale">' + esc(SHR.PRICING.label) + "</span>";
    if ((p.collections || []).indexOf("new-arrivals") >= 0) out += '<span class="badge badge--new">New</span>';
    else if ((p.collections || []).indexOf("best-sellers") >= 0) out += '<span class="badge badge--gold">Best seller</span>';
    out += stockBadge(p);
    return out;
  }
  /* Availability in words, as the product card shows it. The wording lives in
     SHR.STOCK (site-data.js) so the shop and the owner's stock screen say the
     same thing about the same shelf. */
  function stockLabel(p) {
    return SHR.STOCK.label(p);
  }
  /* Every product card: photograph or illustration, brand, name, size, price,
     availability, add to cart and quick view. A rating appears only when there
     are real reviews behind it, and an unavailable product cannot be added. */
  function productCard(p, opts) {
    opts = opts || {};
    var url = "product.html?id=" + encodeURIComponent(p.id);
    var wish = wishHas(p.id);
    var out = p.stock === "out";
    var stock = stockLabel(p);
    return (
      '<article class="pcard' + (out ? " pcard--out" : "") + '">' +
      '<a class="pcard__media" href="' + url + '" aria-label="' + esc(p.brand + " " + p.name) + '">' +
      '<span class="pcard__badges">' + productBadges(p) + "</span>" +
      '<span class="visual">' + productVisual(p) + "</span>" +
      "</a>" +
      '<button class="pcard__wish' + (wish ? " is-on" : "") + '" type="button" data-wish-toggle="' + esc(p.id) + '" ' +
      'aria-pressed="' + (wish ? "true" : "false") + '" aria-label="' + (wish ? "Remove from" : "Add to") + ' wishlist: ' + esc(p.name) + '">' +
      icon("heart") + "</button>" +
      '<div class="pcard__body">' +
      '<span class="pcard__brand">' + esc(p.brand) + "</span>" +
      '<h3 class="pcard__name"><a href="' + url + '">' + esc(p.name) + "</a></h3>" +
      '<span class="pcard__size">' + esc(p.size) + "</span>" +
      (reviewsVerified()
        ? '<div class="rating">' + starsHTML(p.rating) + "<span>" + p.rating.toFixed(1) + " (" + p.reviewCount + ")</span></div>"
        : "") +
      '<span class="pcard__stock ' + stock.cls + '">' + esc(stock.text) + "</span>" +
      '<div class="pcard__foot">' +
      '<span class="price"><span class="price__now">' + money(p.price) + "</span>" +
      (p.was > p.price ? '<del class="price__was">' + money(p.was) + "</del>" : "") +
      "</span>" +
      "</div>" +
      '<div class="pcard__actions">' +
      (out
        ? '<button class="btn btn--outline pcard__add" type="button" disabled>Out of stock</button>'
        : '<button class="btn btn--gold pcard__add" type="button" data-add="' + esc(p.id) + '">' + icon("cart") + "Add to cart</button>") +
      '<button class="btn btn--outline pcard__quick" type="button" data-quick-view="' + esc(p.id) + '">Quick view</button>' +
      "</div></div></article>"
    );
  }
  /* The quick-view dialog: enough to decide, with the full page one tap away */
  function quickViewHTML(p) {
    var url = "product.html?id=" + encodeURIComponent(p.id);
    var out = p.stock === "out";
    var stock = stockLabel(p);
    return (
      '<div class="quickview__grid">' +
      '<div class="quickview__media"><span class="visual">' + productVisual(p) + "</span></div>" +
      '<div class="quickview__body">' +
      '<span class="pcard__brand">' + esc(p.brand) + "</span>" +
      '<h2 id="quickViewTitle" class="h3">' + esc(p.name) + "</h2>" +
      '<p class="pcard__size">' + esc(p.size) + (p.texture ? " &middot; " + esc(p.texture) : "") + "</p>" +
      '<p class="price price--lg"><span class="price__now">' + money(p.price) + "</span>" +
      (p.was > p.price ? '<del class="price__was">' + money(p.was) + "</del>" : "") + "</p>" +
      '<span class="pcard__stock ' + stock.cls + '">' + esc(stock.text) + "</span>" +
      '<p class="mt-2">' + esc(p.short) + "</p>" +
      (reviewsVerified() ? "" : reviewsGate("This product has no published reviews yet.")) +
      '<div class="cluster mt-3">' +
      (out
        ? '<button class="btn btn--outline" type="button" disabled>Out of stock</button>'
        : '<button class="btn btn--gold" type="button" data-add="' + esc(p.id) + '">' + icon("cart") + "Add to cart</button>") +
      '<a class="btn btn--outline" href="' + url + '">View full details</a>' +
      '<a class="btn btn--whatsapp" href="' + esc(waProduct(p)) + '" target="_blank" rel="noopener">' + icon("whatsapp") + "Ask about this</a>" +
      "</div></div></div>"
    );
  }
  function productRow(p, opts) {
    opts = opts || {};
    var url = "product.html?id=" + encodeURIComponent(p.id);
    return (
      '<div class="line-item">' +
      '<a class="line-item__thumb" href="' + url + '" tabindex="-1" aria-hidden="true"><span class="visual">' +
      productVisual(p) + "</span></a>" +
      '<div class="line-item__info">' +
      '<span class="line-item__brand">' + esc(p.brand) + "</span>" +
      '<a class="line-item__name" href="' + url + '">' + esc(p.name) + "</a>" +
      '<span class="line-item__meta">' + esc(p.size) + (opts.qty ? " &middot; Qty " + opts.qty : "") + "</span>" +
      (opts.showQty
        ? '<div class="qty mt-1" data-qty="' + esc(p.id) + '">' +
          '<button type="button" data-qty-minus aria-label="Decrease quantity">&minus;</button>' +
          "<span data-qty-value>" + (opts.qty || 1) + "</span>" +
          '<button type="button" data-qty-plus aria-label="Increase quantity">+</button></div>'
        : "") +
      (opts.showRemove
        ? '<button class="remove-link mt-1" type="button" data-cart-remove="' + esc(p.id) + '">Remove</button>'
        : "") +
      "</div>" +
      '<div class="line-item__price">' + money(p.price * (opts.qty || 1)) + "</div>" +
      "</div>"
    );
  }

  /* ───────────────────────────────────────────────── Export surface */
  SHR.api = {
    $: $, $$: $$, esc: esc, slug: slug, titleCase: titleCase,
    money: money, pct: pct, debounce: debounce, query: query, params: params, arr: arr,
    store: store,
    icon: icon, starsHTML: starsHTML, productVisual: productVisual, coverArt: coverArt,
    productCard: productCard, productRow: productRow, quickViewHTML: quickViewHTML,
    stockLabel: stockLabel,
    reviewsVerified: reviewsVerified, reviewsGate: reviewsGate, reviewsComingSoon: REVIEWS_COMING_SOON,
    getProduct: getProduct, getProducts: getProducts, inCategory: inCategory,
    brandById: brandById, categoryById: categoryById, concernLabel: concernLabel,
    skinTypeLabel: skinTypeLabel, countInCategory: countInCategory,
    concernFacet: concernFacet, concernHref: concernHref, expandConcerns: expandConcerns, facetProducts: facetProducts,
    categoryFacet: categoryFacet, expandCategories: expandCategories, countCategories: countCategories,
    searchProducts: searchProducts, filterProducts: filterProducts, sortProducts: sortProducts,
    relatedTo: relatedTo, relatedToScore: relatedToScore, fitReason: fitReason,
    ratingBreakdown: ratingBreakdown, priceBand: priceBand,
    toast: toast,
    cart: {
      add: cartAdd, setQty: cartSetQty, remove: cartRemove, clear: cartClear,
      count: cartCount, detailed: cartDetailed, subtotal: cartSubtotal,
      discount: discountAmount, shippingDefault: shippingDefault, shippingFor: shippingFor,
      total: cartTotal, promo: promoApply, promoRemove: promoRemove,
      promoCode: function () { return cart.promo; },
      freeDeliveryProgress: freeDeliveryProgress,
      freeDeliveryActive: freeDeliveryActive,
      onChange: onCart
    },
    wish: { has: wishHas, toggle: wishToggle, list: wishList, count: wishCount, onChange: onWishlist },
    trackViewed: trackViewed, recentlyViewed: recentlyViewed,
    orders: { place: placeOrder, all: getOrders, nextRef: orderRef, update: updateOrder },
    user: { get: getUser, set: setUser },
    waLink: waLink, waProduct: waProduct,
    validateForm: validateForm, submitForm: submitForm, messageFrom: messageFrom,
    showStatus: showStatus, clearFieldErrors: clearFieldErrors,
    analytics: analytics
  };
})();
