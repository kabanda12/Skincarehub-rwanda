/* ==========================================================================
   Skincare Hub Rwanda — Blog articles
   Written for the keywords the business targets: skincare Rwanda,
   korean skincare Rwanda, sunscreen Rwanda, skincare routine Rwanda, …
   ========================================================================== */
window.SHR = window.SHR || {};

SHR.ARTICLES = [
  {
    slug: "best-skincare-routine-for-oily-skin",
    photo: "assets/img/guides/best-skincare-routine-for-oily-skin.jpg",
    title: "The Best Skincare Routine for Oily Skin in Rwanda",
    metaTitle: "Best Skincare Routine for Oily Skin in Rwanda | Skincare Hub Rwanda",
    metaDescription:
      "A dermatologist-informed routine for oily skin in Rwanda: what to use morning and night, which products work, and what makes oiliness worse. Free routine advice on WhatsApp.",
    excerpt:
      "Oily skin is not a cleansing problem — it is a hydration and barrier problem. Here is the five-step routine we build for oily skin in Kigali, with products at three price points.",
    category: "Skin concerns",
    author: "Skincare Hub Rwanda advisor team",
    date: "2025-05-12",
    readMins: 8,
    keywords: ["skincare for oily skin Rwanda", "skincare routine Rwanda", "oily skin Kigali", "moisturizer Rwanda"],
    cover: { tint: "#2e6fa8", pattern: "waves" },
    intro:
      "If your face is shiny by eleven in the morning, the instinct is to wash more and moisturise less. That is exactly what makes oily skin oilier. This is the routine we recommend most often in Kigali, and the reasoning behind every step.",
    sections: [
      {
        id: "why-oilier",
        heading: "Why oily skin gets oilier when you wash it more",
        html:
          "<p>Sebum is not dirt. It is a protective film your skin produces to hold water in. When you strip it with soap, hot water or an alcohol-heavy toner, the skin reads that as damage and produces more oil to compensate. Repeat that twice a day and you have a cycle: tight after washing, greasy two hours later, and convinced your skin is unmanageable.</p><p>The goal is not to remove every trace of oil. It is to clean gently, keep the barrier intact, and control sebum with ingredients rather than force.</p>"
      },
      {
        id: "morning",
        heading: "The morning routine",
        html:
          "<ol><li><strong>Gentle foaming cleanser.</strong> A gel cleanser with a mild surfactant removes overnight oil without stripping. The CeraVe Foaming Facial Cleanser and the COSRX Low pH Good Morning Gel Cleanser are the two we sell most for this.</li><li><strong>Hydrating toner.</strong> Counter-intuitive but essential. Anua's Heartleaf 77% Soothing Toner adds water, which oily skin still needs.</li><li><strong>Niacinamide serum.</strong> 10% niacinamide visibly reduces shine and refines the look of pores within two to three weeks.</li><li><strong>Oil-free moisturizer.</strong> A gel or light cream. Skipping moisturizer entirely makes oil worse by midday.</li><li><strong>Sunscreen, always.</strong> A light fluid, SPF 50. Sun damage thickens the skin and makes oil and marks harder to manage.</li></ol>"
      },
      {
        id: "evening",
        heading: "The evening routine",
        html:
          "<ol><li><strong>Double cleanse on heavy sunscreen days.</strong> Micellar water first (Bioderma Sensibio H2O), then your gel cleanser.</li><li><strong>Exfoliating toner two or three nights a week.</strong> Salicylic acid or a low-strength AHA and BHA keeps pores clear. The Ordinary Glycolic Acid 7% or the COSRX AHA/BHA Clarifying Toner.</li><li><strong>Treatment for breakouts or marks.</strong> One only — niacinamide, azelaic acid, or a product like La Roche-Posay Effaclar Duo+ M. Do not stack three.</li><li><strong>Light moisturizer.</strong> Same product as the morning is fine.</li></ol><div class=\"callout\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"><circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 8h.01M11 12h1v4h1\"/></svg><p>Blotting paper during the day is fine. Washing your face at lunchtime is not — it restarts the oil rebound.</p></div>"
      },
      {
        id: "ingredients",
        heading: "The ingredients that actually control oil",
        html:
          "<ul><li><strong>Niacinamide</strong> — reduces sebum production, calms redness, refines pores. The most reliably useful active for oily skin.</li><li><strong>Salicylic acid (BHA)</strong> — oil-soluble, so it gets inside the pore where congestion starts.</li><li><strong>Zinc PCA</strong> — a gentle sebum regulator found in many French pharmacy formulas.</li><li><strong>Azelaic acid</strong> — treats breakouts and marks while being tolerated by sensitive skin.</li></ul><p>What does not help: alcohol-based toners, scrubs used daily, and coconut oil. All three damage the barrier and increase oil production.</p>"
      },
      {
        id: "products",
        heading: "Our picks at three price points",
        html:
          "<p><strong>Under 60,000 RWF for the full routine:</strong> CeraVe Foaming Facial Cleanser, The Ordinary Niacinamide 10% + Zinc 1%, Cetaphil Moisturising Lotion, Beauty of Joseon Relief Sun. Four products, everything oily skin needs.</p><p><strong>The K-beauty route:</strong> COSRX Low pH Good Morning Gel Cleanser, Anua Heartleaf 77% Soothing Toner, Anua Niacinamide 10% + TXA 4% Serum, Beauty of Joseon Relief Sun.</p><p><strong>If acne is active:</strong> add La Roche-Posay Effaclar Duo+ M on top of the basic four, and use it on the whole face rather than only on the spots.</p>"
      },
      {
        id: "timeline",
        heading: "What to expect, and when",
        html:
          "<p>Shine reduces in two to three weeks. Pores look smaller in four to six. Post-acne marks take eight to twelve weeks, and only if you wear sunscreen every day — without it, marks fade far more slowly and often come back darker. Anyone who promises faster is selling you something.</p>"
      }
    ],
    takeaways: [
      "Do not over-wash — it rebounds into more oil",
      "Niacinamide is the single most useful active for oily skin",
      "Always moisturise, even oily skin, and always wear SPF 50",
      "One treatment product at a time, used for at least four weeks"
    ],
    faqs: [
      { q: "Should oily skin use moisturizer?", a: "Yes. Dehydrated skin produces more oil. Use a light gel or oil-free lotion rather than a rich cream." },
      { q: "How often should I exfoliate oily skin?", a: "Two or three nights a week with a gentle acid toner. Daily scrubs or beads damage the barrier." }
    ],
    related: [
      "cerave-foaming-facial-cleanser",
      "ordinary-niacinamide-10-zinc-1",
      "anua-heartleaf-77-soothing-toner",
      "lrp-anthelios-uvmune-400"
    ]
  },

  {
    slug: "how-to-treat-acne",
    photo: "assets/img/guides/how-to-treat-acne.jpg",
    title: "How to Treat Acne: A Routine That Actually Works",
    metaTitle: "How to Treat Acne in Rwanda | Acne Products Rwanda | Skincare Hub Rwanda",
    metaDescription:
      "A step-by-step acne routine that works: what to use, in what order, how long it takes, and when to stop treating at home. Acne products available across Rwanda with same-day Kigali delivery.",
    excerpt:
      "Acne is treated with consistency, not with strength. Here is the order of operations we give clients, the products that do the work, and the honest timeline.",
    category: "Skin concerns",
    author: "Skincare Hub Rwanda advisor team",
    date: "2025-04-22",
    readMins: 9,
    keywords: ["acne products Rwanda", "how to treat acne", "acne routine Kigali", "salicylic acid Rwanda"],
    cover: { tint: "#4e7c4a", pattern: "dots" },
    intro:
      "Almost every acne routine that fails fails for one of four reasons: too many actives at once, no moisturizer, no sunscreen, or giving up at week three. This article fixes all four.",
    sections: [
      {
        id: "what-acne-is",
        heading: "What you are actually treating",
        html:
          "<p>A breakout is a pore blocked by oil and dead skin cells, in which bacteria multiply and the skin becomes inflamed. That means there are four things worth doing: keep the pore clear, reduce the bacteria, calm the inflammation, and fade what is left behind. No single product does all four, which is why a routine beats a hero product.</p>"
      },
      {
        id: "step-by-step",
        heading: "The routine, in order",
        html:
          "<ol><li><strong>Gentle cleanser, twice a day.</strong> Twice, not five times. CeraVe Foaming Facial Cleanser or COSRX Low pH Good Morning Gel Cleanser.</li><li><strong>One acne treatment.</strong> Choose one: salicylic acid, azelaic acid, or La Roche-Posay Effaclar Duo+ M. Apply to the whole face, not only the spots — acne is a whole-face condition with visible peaks.</li><li><strong>Moisturizer.</strong> Non-comedogenic. Most acne treatments dry the skin out and the dryness is what makes people quit.</li><li><strong>Sunscreen every morning.</strong> Two reasons: acids make skin photosensitive, and UV exposure darkens every mark you are trying to fade.</li><li><strong>Optional once a week:</strong> a gentle exfoliating toner, or a stronger peel like The Ordinary AHA 30% + BHA 2% once your skin is used to acids.</li></ol>"
      },
      {
        id: "stacking",
        heading: "How to add actives without wrecking your skin",
        html:
          "<p>Introduce one new product, use it for two weeks, then decide. Signs that you are doing too much: stinging that lasts, new redness, flaking around the mouth and nose, or skin that feels tight after cleansing. When that happens, stop everything except cleanser, moisturizer and sunscreen for two weeks — La Roche-Posay Cicaplast Baume B5 is built for exactly this reprieve.</p><div class=\"callout\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"><path d=\"M12 3l9 16H3z\"/><path d=\"M12 9v4h.01M12 16h.01\"/></svg><p>Never use a strong peel, a retinol and salicylic acid on the same night. That combination causes the barrier damage people mistake for a purge.</p></div>"
      },
      {
        id: "marks",
        heading: "The marks left behind",
        html:
          "<p>Post-inflammatory hyperpigmentation — the brown and red marks from old breakouts — needs a different approach from the acne itself. Alpha arbutin, tranexamic acid, niacinamide and Thiamidol are the actives that shift them, and none of them work without daily sunscreen. Expect eight to twelve weeks. The Eucerin Anti-Pigment Dual Serum and Anua's Niacinamide 10% + TXA 4% serum are the two most effective we stock.</p>"
      },
      {
        id: "when-to-see-doctor",
        heading: "When to stop treating this at home",
        html:
          "<p>See a dermatologist if you have deep, painful nodules or cysts, if acne is leaving indented scars, if it is sudden and severe, or if you have been consistent with a proper routine for three months with no improvement. Topical skincare has limits, and prescription treatment — including isotretinoin — is a medical decision, not a product decision. We will tell you honestly when that point has come.</p>"
      }
    ],
    takeaways: [
      "One treatment active at a time, on the whole face",
      "Never skip moisturizer — dryness is why routines fail",
      "Sunscreen is part of acne treatment, not optional",
      "Give it eight to twelve weeks before judging it"
    ],
    faqs: [
      { q: "Will my skin purge when I start?", a: "A mild increase in breakouts in the first two to four weeks is normal with acids, but it should settle. Severe, prolonged irritation is not a purge — stop and reassess." },
      { q: "Do I need to change my diet?", a: "For most people, no dramatic change is needed. Some people notice high-sugar dairy correlates with their breakouts. Track it for a month before cutting anything out." }
    ],
    related: [
      "lrp-effaclar-duo-m",
      "ordinary-azelaic-acid-10",
      "cosrx-low-ph-good-morning-gel-cleanser",
      "eucerin-anti-pigment-dual-serum"
    ]
  },

  {
    slug: "sunscreen-myths",
    photo: "assets/img/guides/sunscreen-myths.jpg",
    title: "7 Sunscreen Myths That Keep Rwandan Skin Dark-Spotted",
    metaTitle: "Sunscreen Myths Busted | Sunscreen Rwanda | Skincare Hub Rwanda",
    metaDescription:
      "Do you need sunscreen if you have dark skin? Can you tan through clouds? Seven sunscreen myths debunked, with SPF 50 options delivered across Rwanda.",
    excerpt:
      "Rwanda sits close to the equator, where UV is strong all year. These are the seven excuses we hear most often — and what the science actually says.",
    category: "Sun protection",
    author: "Skincare Hub Rwanda advisor team",
    date: "2025-06-03",
    readMins: 7,
    keywords: ["sunscreen Rwanda", "SPF 50 Kigali", "sunscreen for dark skin", "hyperpigmentation Rwanda"],
    cover: { tint: "#c99a5e", pattern: "rings" },
    intro:
      "We ask every client whether they wear sunscreen daily. In Rwanda, most say no — and almost all of them are treating dark spots, uneven tone or marks at the same time. Those two facts are directly connected.",
    sections: [
      {
        id: "myth-1",
        heading: "Myth 1: Dark skin does not need sunscreen",
        html:
          "<p>Melanin does give natural protection — roughly the equivalent of SPF 13. That is not enough. More importantly, melanin does not stop the UVA rays that trigger melanocytes to overproduce pigment, which is exactly how dark spots form in the first place. Deep skin tones are in fact more prone to post-inflammatory pigmentation and melasma, not less. If you are treating pigmentation and not wearing sunscreen, you are refilling the bucket while you bail it out.</p>"
      },
      {
        id: "myth-2",
        heading: "Myth 2: Sunscreen is only for sunny days",
        html:
          "<p>Up to 80% of UVA passes through cloud. Kigali's rainy season does not reduce UV meaningfully, and UVA also passes through window glass — so the light you sit in at a desk beside a window during the day still reaches your skin. Sunscreen is a daily habit, not a beach item.</p>"
      },
      {
        id: "myth-3",
        heading: "Myth 3: A little goes a long way",
        html:
          "<p>SPF 50 tested in a laboratory is applied at 2 mg per square centimetre. On a face, that is about two finger-lengths of product — more than most people use in total. Applied too thinly, an SPF 50 performs like an SPF 10. This single mistake undoes most sunscreen efforts.</p>"
      },
      {
        id: "myth-4",
        heading: "Myth 4: You do not need to reapply",
        html:
          "<p>Filters break down and rub off. If you are indoors, one careful morning application usually carries the working day. If you are outdoors, driving for long stretches, sweating or swimming, reapply every two hours. Powder or mist formats make this realistic during the day.</p>"
      },
      {
        id: "myth-5",
        heading: "Myth 5: Sunscreen will make my skin break out or look grey",
        html:
          "<p>Both complaints come from older, heavier formulas. Modern fluid sunscreens are genuinely invisible on deep skin tones and non-comedogenic. The two we recommend most for this: La Roche-Posay Anthelios UVMune 400 for oily and combination skin, and Beauty of Joseon Relief Sun for dry or sensitive skin, which feels like a moisturizer.</p>"
      },
      {
        id: "myth-6",
        heading: "Myth 6: Makeup with SPF is enough",
        html:
          "<p>You would need to apply foundation at the same thickness as sunscreen to reach the label's SPF, which nobody does. Treat SPF in makeup as a small top-up, not as your protection.</p>"
      },
      {
        id: "myth-7",
        heading: "Myth 7: Sunscreen blocks vitamin D",
        html:
          "<p>Real-world sunscreen use does not cause vitamin D deficiency. Even with daily use, incidental exposure on the hands, arms and neck, and time without sunscreen outdoors, is enough. Vitamin D status is a blood test issue, not a reason to skip SPF.</p>"
      }
    ],
    takeaways: [
      "Dark skin still needs daily SPF — pigmentation is more likely, not less",
      "Apply two finger-lengths to the face, not a pea-sized dab",
      "UVA passes through clouds and window glass",
      "Reapply every two hours outdoors or when sweating"
    ],
    faqs: [
      { q: "Which sunscreen is best for oily skin in Rwanda?", a: "La Roche-Posay Anthelios UVMune 400 Invisible Fluid — light, matte, no white cast. Bioderma Photoderm Aquafluide is a good alternative." },
      { q: "Can I reapply over makeup?", a: "A sunscreen mist or SPF powder over the top is realistic, and better than nothing. On a heavy makeup day, apply generously before the makeup instead." }
    ],
    related: [
      "lrp-anthelios-uvmune-400",
      "beauty-of-joseon-relief-sun",
      "bioderma-photoderm-aquafluide-spf50",
      "eucerin-anti-pigment-dual-serum"
    ]
  },

  {
    slug: "how-to-fade-dark-spots",
    photo: "assets/img/guides/how-to-fade-dark-spots.jpg",
    title: "How to Fade Dark Spots and Hyperpigmentation — With Real Timelines",
    metaTitle: "How to Fade Dark Spots in Rwanda | Hyperpigmentation Products Rwanda",
    metaDescription:
      "A realistic plan to fade dark spots and hyperpigmentation: which actives work, how to combine them, and how long it really takes. Products delivered across Rwanda.",
    excerpt:
      "Dark spots fade, but not in two weeks and not without sunscreen. Here is the combination that works, the order to use it in, and an honest week-by-week timeline.",
    category: "Skin concerns",
    author: "Skincare Hub Rwanda advisor team",
    date: "2025-06-18",
    readMins: 8,
    keywords: ["dark spots Rwanda", "hyperpigmentation products Rwanda", "fade dark spots", "skincare Rwanda"],
    cover: { tint: "#b98bb0", pattern: "blob" },
    intro:
      "Pigmentation is the most requested treatment we get, and the one with the most disappointment attached, because nobody tells clients how long it takes. So this article does.",
    sections: [
      {
        id: "why",
        heading: "Why the spot is there in the first place",
        html:
          "<p>A dark spot is a cluster of melanocytes that have been told to produce more pigment. The trigger is usually inflammation — a breakout, an ingrown hair, a burn, harsh scrubbing — combined with UV exposure that keeps the signal switched on. If you remove the trigger but keep the UV, the spot returns. This is why sunscreen is the treatment, not the add-on.</p>"
      },
      {
        id: "actives",
        heading: "The actives that genuinely fade pigment",
        html:
          "<ul><li><strong>Thiamidol</strong> — the most clinically studied pigmentation active, found in the Eucerin Anti-Pigment range. Our first recommendation for stubborn patches and melasma.</li><li><strong>Tranexamic acid</strong> — effective for melasma and stubborn patches; see Anua's Niacinamide 10% + TXA 4% serum.</li><li><strong>Alpha arbutin</strong> — a gentler, well-tolerated inhibitor. The Ordinary Alpha Arbutin 2% + HA or Beauty of Joseon Glow Deep Serum.</li><li><strong>Azelaic acid</strong> — treats acne and marks at once, tolerated by sensitive skin.</li><li><strong>Vitamin C in the morning</strong> — prevents new pigment and brightens existing tone.</li></ul>"
      },
      {
        id: "routine",
        heading: "How to put it together",
        html:
          "<p><strong>Morning:</strong> gentle cleanser, vitamin C serum, moisturizer, SPF 50 with generous application.</p><p><strong>Evening:</strong> cleanser, one pigmentation serum (Thiamidol, tranexamic acid or alpha arbutin — not three), moisturizer. Add a gentle exfoliating toner twice a week at most.</p><p>Choose one pigmentation serum and use it consistently for three months. Switching every three weeks resets your progress every three weeks.</p>"
      },
      {
        id: "timeline",
        heading: "The honest timeline",
        html:
          "<ul><li><strong>Weeks 1–2:</strong> no visible change. This is normal and it is where most people quit.</li><li><strong>Weeks 4–6:</strong> the first real change — spots usually look slightly lighter and the overall tone more even.</li><li><strong>Weeks 8–12:</strong> clear, measurable fading of most post-acne marks and sun spots.</li><li><strong>Months 4–6:</strong> deeper pigmentation and melasma continue to improve slowly and often need maintenance afterwards.</li></ul><p>Melasma is a chronic condition, not a one-off. It is managed, and it returns if you stop protecting your skin. Knowing that in advance is worth more than any product.</p>"
      },
      {
        id: "dont",
        heading: "What to avoid",
        html:
          "<ul><li><strong>Hydroquinone bought informally.</strong> Unregulated strength and no medical supervision can cause ochronosis — permanent blue-black discolouration.</li><li><strong>Bleaching or mercury-containing creams.</strong> These cause lasting damage and are illegal for good reason.</li><li><strong>Aggressive scrubbing.</strong> Physical irritation makes pigmentation worse, not better.</li><li><strong>Stopping sunscreen.</strong> The single biggest reason results disappear.</li></ul>"
      }
    ],
    takeaways: [
      "Sunscreen is the treatment, not an optional extra",
      "Choose one pigmentation active and stay with it for three months",
      "Melasma improves in months, not weeks — and needs maintenance",
      "Never buy hydroquinone or bleaching creams informally"
    ],
    faqs: [
      { q: "Can I use two pigmentation serums together?", a: "You can pair actives that work differently — for example Thiamidol at night with vitamin C in the morning. Do not use three strong brightening actives in one routine; irritation makes pigment worse." },
      { q: "Will the spots come back if I stop?", a: "Sun spots stay away with daily SPF. Melasma usually returns without maintenance, which is why we keep you on a simple long-term routine." }
    ],
    related: [
      "eucerin-anti-pigment-dual-serum",
      "anua-niacinamide-txa-4-serum",
      "ordinary-alpha-arbutin-2-ha",
      "lrp-anthelios-uvmune-400"
    ]
  }
  ,

  {
    slug: "korean-skincare-guide",
    photo: "assets/img/guides/korean-skincare-guide.jpg",
    title: "The Korean Skincare Guide for Beginners: 10 Steps, Explained",
    metaTitle: "Korean Skincare Guide | Korean Skincare Rwanda | Skincare Hub Rwanda",
    metaDescription:
      "What the 10-step Korean skincare routine actually means, which steps are worth it, and how to start with three. Genuine COSRX, Anua and Beauty of Joseon delivered across Rwanda.",
    excerpt:
      "Korean skincare is not ten mandatory steps — it is a philosophy of layering thin textures and being patient. Here is what each step does and which ones you can skip.",
    category: "K-beauty",
    author: "Skincare Hub Rwanda advisor team",
    date: "2025-05-28",
    readMins: 9,
    keywords: ["korean skincare Rwanda", "COSRX Rwanda", "Anua Rwanda", "Beauty of Joseon Rwanda", "glass skin"],
    cover: { tint: "#c9bfa8", pattern: "grid" },
    intro:
      "The ten-step routine was always a marketing shorthand for a flexible approach, not a rulebook. This guide explains what each step is for, so you can decide which three or four you actually need.",
    sections: [
      {
        id: "philosophy",
        heading: "The idea behind it",
        html:
          "<p>Western skincare often relies on one strong active doing a lot of work. Korean skincare layers several gentle, watery products that each do a little — hydration, soothing, brightening — and relies on consistency. The result is skin that rarely becomes irritated, which matters enormously if you are treating acne or pigmentation, where irritation makes everything worse.</p>"
      },
      {
        id: "steps",
        heading: "The steps, and what each one is for",
        html:
          "<ol><li><strong>Oil cleanser</strong> — melts sunscreen and makeup. Only needed if you wear heavy sunscreen or makeup.</li><li><strong>Water-based cleanser</strong> — the actual cleanse. COSRX Low pH Good Morning Gel Cleanser.</li><li><strong>Exfoliating toner</strong> — two or three times a week, not daily for most people.</li><li><strong>Hydrating toner</strong> — layers water into the skin. Anua Heartleaf 77% is the classic.</li><li><strong>Essence</strong> — a light hydrating layer; COSRX Advanced Snail 96 Mucin is the most famous.</li><li><strong>Ampoule or serum</strong> — where your targeted active lives: niacinamide, tranexamic acid, vitamin C.</li><li><strong>Sheet mask</strong> — optional, an occasional treat rather than a routine step.</li><li><strong>Eye cream</strong> — optional; your regular moisturizer is usually enough.</li><li><strong>Moisturizer</strong> — seals everything in. Always.</li><li><strong>Sunscreen</strong> — the step that makes the other nine worth doing.</li></ol>"
      },
      {
        id: "start",
        heading: "Where to actually start",
        html:
          "<p>Start with three: a low-pH cleanser, a hydrating toner and a sunscreen. Do that for three weeks. Then add one serum for your main concern. Then, if you want, an essence. That is a routine that works and that you will still be following in six months, which is the only thing that matters.</p><div class=\"callout callout--navy\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"><circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 8h.01M11 12h1v4h1\"/></svg><p>Ten steps is not the goal. Skin that is calm, hydrated and protected is the goal — that is what \"glass skin\" actually describes.</p></div>"
      },
      {
        id: "rwanda",
        heading: "Adapting K-beauty to Rwanda",
        html:
          "<p>Two adjustments matter here. First, humidity and heat: heavy cream layers that suit Seoul's winter can feel suffocating in Kigali — choose gels and light lotions, and use the thicker cream only on dry cheeks. Second, the UV is far stronger than in Korea, so the sunscreen step needs a very high SPF applied generously, and re-applied if you are outdoors. Beauty of Joseon Relief Sun and La Roche-Posay Anthelios UVMune 400 both hold up well in this climate.</p>"
      },
      {
        id: "authentic",
        heading: "Buying K-beauty you can trust",
        html:
          "<p>Korean skincare is heavily counterfeited, particularly COSRX and Beauty of Joseon. Buy from a retailer who can show you the batch code and expiry date on the exact unit, whose stock is sealed and whose prices are plausible — not half of market price. Every product we sell comes from the manufacturer or an authorised distributor, and we will send you a photo of the batch code on your unit before you pay.</p>"
      }
    ],
    takeaways: [
      "Korean skincare is about layering light textures consistently, not ten rigid steps",
      "Start with cleanser, hydrating toner and sunscreen — three steps",
      "Add one targeted serum once the base routine is settled",
      "In Rwanda you need higher SPF and lighter creams than in Korea"
    ],
    faqs: [
      { q: "Do I need all ten steps?", a: "No. Four to six is plenty for most people. The essentials are cleanser, hydrating layer, moisturizer and sunscreen." },
      { q: "Is snail mucin suitable for acne?", a: "Yes for most people — it is hydrating and repairing, not oily. Patch-test if you have a dust mite allergy." }
    ],
    related: [
      "cosrx-advanced-snail-96-mucin-power-essence",
      "anua-heartleaf-77-soothing-toner",
      "beauty-of-joseon-relief-sun",
      "cosrx-low-ph-good-morning-gel-cleanser"
    ]
  },

  {
    slug: "beginner-skincare-routine",
    photo: "assets/img/guides/beginner-skincare-routine.jpg",
    title: "The Beginner Skincare Routine: Three Products, No Confusion",
    metaTitle: "Beginner Skincare Routine Rwanda | Start Skincare in 3 Steps",
    metaDescription:
      "New to skincare? Start with three products that cost under 60,000 RWF. A clear, honest beginner routine for Rwanda, with no unnecessary steps.",
    excerpt:
      "If you have never had a routine, three products are enough to change your skin. This is exactly what to buy, how to use it, and what to ignore.",
    category: "Basics",
    author: "Skincare Hub Rwanda advisor team",
    date: "2025-03-30",
    readMins: 6,
    keywords: ["beginner skincare routine", "skincare routine Rwanda", "skincare for beginners Kigali", "moisturizer Rwanda"],
    cover: { tint: "#1f8a8a", pattern: "arcs" },
    intro:
      "Most beginners are sold a shelf of products and quit within a month. You need three, and you need to be told plainly what each one is for.",
    sections: [
      {
        id: "three",
        heading: "The three products that matter",
        html:
          "<ol><li><strong>A gentle cleanser.</strong> To remove sunscreen, sweat and dirt without stripping the skin. AM and PM.</li><li><strong>A moisturizer that suits your skin type.</strong> Gel or light lotion if you are oily, a cream if you are dry, and something fragrance-free if you are sensitive. AM and PM.</li><li><strong>A sunscreen, SPF 50.</strong> Every single morning, generously. This is the one with the biggest long-term effect.</li></ol><p>That is it. Everything else — serums, toners, essences, masks — is a later decision made for a specific reason.</p>"
      },
      {
        id: "how",
        heading: "How to use them",
        html:
          "<p><strong>Morning:</strong> rinse or cleanse, moisturizer, sunscreen. <strong>Evening:</strong> cleanse, moisturizer, done.</p><p>Use lukewarm water, not hot. Pat dry with a clean towel rather than rubbing. Apply moisturizer while your skin is still slightly damp — it traps that water. Give sunscreen about fifteen minutes before going outdoors.</p>"
      },
      {
        id: "cost",
        heading: "What it costs",
        html:
          "<p>A complete three-product routine in Rwanda starts at about 80,000 RWF and lasts roughly two to three months. The most affordable combination we recommend comes to exactly that: Cetaphil Gentle Skin Cleanser (24,000 RWF), Cetaphil Moisturising Lotion (26,000 RWF) and Beauty of Joseon Relief Sun (30,000 RWF). Take the same three steps with premium brands and you are looking at 120,000 RWF or more.</p>"
      },
      {
        id: "mistakes",
        heading: "Five mistakes beginners make",
        html:
          "<ul><li><strong>Changing everything at once.</strong> If your skin reacts, you will not know what caused it.</li><li><strong>Buying actives too early.</strong> Retinol and strong acids are for later, when you know your skin.</li><li><strong>Skipping sunscreen because it is cloudy.</strong> UVA passes through cloud and glass.</li><li><strong>Washing more when skin is oily.</strong> It rebounds into more oil.</li><li><strong>Judging after one week.</strong> Skin turns over roughly every four weeks.</li></ul>"
      },
      {
        id: "next",
        heading: "What to add next, and when",
        html:
          "<p>After a month, if you are happy, stop there — that is a complete routine. If you have a specific concern, add one product: niacinamide for shine and pores, alpha arbutin or tranexamic acid for dark spots, azelaic acid for breakouts. One at a time, four weeks each. Then reassess.</p>"
      }
    ],
    takeaways: [
      "Cleanser, moisturizer and SPF is a complete routine",
      "Apply moisturizer on slightly damp skin",
      "Add one product at a time, and only for a specific concern",
      "Skin turnover is about four weeks — judge nothing before that"
    ],
    faqs: [
      { q: "Can I use soap instead of a cleanser?", a: "No. Bar soap disrupts the skin's pH and strips the barrier, which is why so many people have dry, tight, reactive skin. A proper cleanser costs the same over a few months." },
      { q: "How much should I spend as a beginner?", a: "About 80,000 RWF for the three cheapest genuine products we stock, and up to 120,000 RWF if you choose premium brands. Anything above that as a beginner is usually marketing, not effectiveness." }
    ],
    related: [
      "cetaphil-gentle-skin-cleanser",
      "cetaphil-moisturising-lotion",
      "beauty-of-joseon-relief-sun",
      "cerave-hydrating-facial-cleanser"
    ]
  },

  {
    slug: "how-to-layer-skincare-products",
    photo: "assets/img/guides/how-to-layer-skincare-products.jpg",
    title: "How to Layer Skincare Products in the Right Order",
    metaTitle: "How to Layer Skincare Products | Order of Skincare Routine Rwanda",
    metaDescription:
      "The correct order to apply skincare: thinnest to thickest, with the exceptions that matter. Build a routine that layers without irritation or pilling.",
    excerpt:
      "Wrong order, and your actives do not absorb and your products pill under sunscreen. Here is the sequence, the exceptions, and the combinations to avoid.",
    category: "Basics",
    author: "Skincare Hub Rwanda advisor team",
    date: "2025-02-14",
    readMins: 6,
    keywords: ["how to layer skincare", "order of skincare routine", "skincare routine Rwanda", "serum order"],
    cover: { tint: "#c6a664", pattern: "stripes" },
    intro:
      "Layering is not complicated, but it is not random either. The rule is simple: thinnest texture first, thickest last, and give each step a moment to settle.",
    sections: [
      {
        id: "order",
        heading: "The order",
        html:
          "<ol><li><strong>Oil cleanser</strong> (if you wear heavy sunscreen or makeup)</li><li><strong>Water-based cleanser</strong></li><li><strong>Exfoliating toner</strong> — two to three nights a week</li><li><strong>Hydrating toner</strong> — patted in, can be layered twice</li><li><strong>Essence</strong> — light and watery</li><li><strong>Ampoule or serum</strong> — your targeted active, applied to dry skin</li><li><strong>Eye cream</strong> — optional</li><li><strong>Moisturizer</strong> — cream or lotion</li><li><strong>Facial oil or balm</strong> — evening only, on very dry skin</li><li><strong>Sunscreen SPF 50</strong> — morning, always, as the last step</li></ol>"
      },
      {
        id: "exceptions",
        heading: "The exceptions worth knowing",
        html:
          "<ul><li><strong>Sunscreen in the morning goes last</strong> — after moisturizer, never under it.</li><li><strong>Actives go on dry skin.</strong> Water on the face increases penetration, which is how people irritate themselves with acids.</li><li><strong>Silicone-heavy products go before heavier creams</strong>, otherwise they pill.</li><li><strong>Retinol:</strong> apply after moisturizer if your skin is sensitive — this is called buffering and it slows absorption.</li><li><strong>Vitamin C in the morning, niacinamide any time, acids at night.</strong></li></ul>"
      },
      {
        id: "what-not",
        heading: "Combinations to avoid in one routine",
        html:
          "<ul><li><strong>Retinol plus a strong AHA/BHA peel</strong> on the same night — near-certain irritation.</li><li><strong>Benzoyl peroxide plus retinol</strong> — they deactivate each other.</li><li><strong>Two exfoliating acids</strong> together — pick one per session.</li><li><strong>Strong vitamin C plus strong acids</strong> in the same step — space them morning and evening.</li></ul><p>You can alternate: acids two nights a week, retinol two other nights, nothing but cleanser and moisturizer the rest. Skin needs rest days.</p>"
      },
      {
        id: "patience",
        heading: "How long between steps",
        html:
          "<p>You do not need to wait ten minutes between each product. Twenty to thirty seconds is enough for watery products to settle; wait a minute or two before sunscreen and before makeup. The one real wait is with acids and retinols — give those a couple of minutes before the next layer.</p>"
      },
      {
        id: "sample-orders",
        heading: "Two orders you can copy",
        html:
          "<p><strong>Morning:</strong> gentle cleanser → hydrating toner → vitamin C serum → moisturizer → SPF 50. Five layers, and the sunscreen is the one you never skip.</p><p><strong>Evening:</strong> cleanser → exfoliating toner (two or three nights a week) → treatment serum on dry skin → moisturizer → a thicker balm on any dry patches.</p><p>If you are using a prescription treatment from your dermatologist, apply it exactly as they instructed and keep everything else to cleanser, moisturizer and sunscreen. Do not add acids on the same night.</p>"
      }
    ],
    takeaways: [
      "Thinnest to thickest, and sunscreen always last in the morning",
      "Actives go on completely dry skin",
      "Never pair a strong peel with a retinol on the same night",
      "Alternate nights for strong actives — skin needs rest days"
    ],
    faqs: [
      { q: "Why does my routine pill under sunscreen?", a: "Usually too much product or layers applied too fast, and often silicone-based serums under a heavy cream. Use less, wait a minute between layers, and pat rather than rub." },
      { q: "Can I layer two serums?", a: "Yes, if they do different jobs — for example hydration then a brightening serum. Apply the thinnest first and give each one a moment." }
    ],
    related: [
      "cosrx-advanced-snail-96-mucin-power-essence",
      "beauty-of-joseon-glow-deep-serum",
      "cerave-hydrating-facial-cleanser",
      "lrp-cicaplast-baume-b5"
    ]
  }
];
