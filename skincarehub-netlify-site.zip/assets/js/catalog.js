/* ==========================================================================
   Skincare Hub Rwanda — Product catalogue (35 products / 12 brands)
   Every product carries the content a product page needs: benefits, key
   ingredients, directions, suitable skin types, concerns, reviews and FAQs.
   Plain classic script so the site also works from file://

   PRICES: `price` is what the customer pays. The list price (`was`) is NOT
   written in this file - it is derived from the price by the shop's single
   10% discount rule (SHR.PRICING in site-data.js), which is applied to every
   product at the bottom of this file. Do not add `was` by hand: a second
   hand-kept copy of the discount is exactly what made one product 15% off and
   the next 7% off.

   Products the shop owner adds with tools/product-editor.html live in
   products-own.js and are merged in at the bottom of this file, where the
   header count above still describes the hand-written catalogue.

   STOCK: `stock` (in-stock / low / out) is what the site reads; a product that
   also carries `units` has had its stock counted, and the status then follows
   from the count. The counts come from stock-own.js (SHR.OWN_STOCK), written
   by tools/stock-manager.html, and are applied at the bottom of this file.
   ========================================================================== */
window.SHR = window.SHR || {};

(function () {
  function i(name, role) {
    return { name: name, role: role };
  }
  function r(who, city, rating, date, text) {
    return { who: who, city: city, rating: rating, date: date, text: text };
  }
  function p(o) {
    o = o || {};
    o.price = Math.round(Number(o.price) || 0);
    /* Not written by hand anywhere: SHR.PRICING derives it from the price, so
       every product in the shop carries the same 10% discount. */
    o.was = 0;
    o.also = o.also || [];
    o.collections = o.collections || [];
    o.skinTypes = o.skinTypes || [];
    o.concerns = o.concerns || [];
    o.benefits = o.benefits || [];
    o.ingredients = o.ingredients || [];
    o.reviews = o.reviews || [];
    o.faqs = o.faqs || [];
    o.rating = o.rating || 4.8;
    o.reviewCount = o.reviewCount || 0;
    o.stock = o.stock || "in-stock";
    /* Units on the shelf, or null when nobody has counted them. Supplied by
       SHR.OWN_STOCK at the foot of this file; a number here decides the
       status, through SHR.STOCK in site-data.js. */
    o.units = typeof o.units === "number" && isFinite(o.units) ? Math.max(0, Math.round(o.units)) : null;
    o.form = o.form || "bottle";
    o.tint = o.tint || "#2e6fa8";
    return o;
  }

  var catalogue = [
    /* ───────────────────────────────────────────────────────────── CeraVe */
    p({
      id: "cerave-hydrating-facial-cleanser",
      photos: ["assets/img/cerave-hydrating-facial-cleanser.jpg"],
      name: "Hydrating Facial Cleanser",
      brand: "CeraVe",
      brandId: "cerave",
      price: 28000,
      size: "236 ml",
      form: "pump",
      tint: "#2e6fa8",
      category: "cleansers",
      collections: ["best-sellers"],
      skinTypes: ["dry", "normal", "sensitive", "combination"],
      concerns: ["dryness", "sensitivity"],
      rating: 4.9,
      reviewCount: 214,
      texture: "Cream, non-foaming",
      short:
        "A non-foaming cream cleanser with three ceramides and hyaluronic acid that cleans thoroughly without stripping the barrier.",
      benefits: [
        "Removes sunscreen, makeup and the day's grime without that tight, squeaky feeling afterwards",
        "Three essential ceramides (1, 3, 6-II) replace the lipids dry skin loses fastest",
        "Hyaluronic acid holds water in while you cleanse, so skin feels cushioned rather than stripped",
        "Fragrance-free and non-comedogenic — suitable for eczema-prone and reactive skin"
      ],
      ingredients: [
        i("Ceramides NP, AP, EOP", "Rebuild the lipid barrier that keeps water in"),
        i("Hyaluronic acid", "Attracts and holds water in the upper layers"),
        i("Glycerin", "Humectant that keeps the skin comfortable, not tight"),
        i("MVE delivery technology", "Releases ingredients slowly over the day")
      ],
      directions:
        "Wet your face with lukewarm water. Massage a coin-sized amount in gentle circles for about 30 seconds, rinse and pat dry. Use morning and evening, then apply moisturizer while the skin is still slightly damp.",
      reviews: [
        r("Aline U.", "Nyarugenge, Kigali", 5, "March 2025", "My skin stopped feeling tight the first week. It removes a full face of sunscreen without a second cleanse and it never stings my cheeks."),
        r("Eric T.", "Muhanga", 5, "February 2025", "I used soap for years and could not understand why my face always felt dry. This plus a moisturiser fixed it in two weeks.")
      ],
      faqs: [
        { q: "Will this remove sunscreen?", a: "Yes, with one cleanse. If you wear heavy or water-resistant sunscreen, a micellar water like Bioderma Sensibio H2O first makes it quicker." },
        { q: "Is it good for oily skin too?", a: "It works, but if you are oily all over the foaming version may feel fresher. Combination skin with an oily T-zone is the exception — use this on the cheeks and foaming on the T-zone." }
      ]
    }),
    p({
      id: "cerave-foaming-facial-cleanser",
      photos: ["assets/img/cerave-foaming-facial-cleanser.jpg"],
      name: "Foaming Facial Cleanser",
      brand: "CeraVe",
      brandId: "cerave",
      price: 28000,
      tint: "#2e6fa8",
      size: "236 ml",
      form: "pump",
      category: "cleansers",
      also: ["acne-care"],
      collections: ["best-sellers"],
      skinTypes: ["oily", "combination", "normal"],
      concerns: ["oiliness", "large-pores", "acne"],
      rating: 4.8,
      reviewCount: 178,
      texture: "Gel, lightly foaming",
      short:
        "A gel cleanser with ceramides and niacinamide that lifts oil and congestion without the rebound greasiness of harsh washes.",
      benefits: [
        "Dissolves excess oil, sweat and sunscreen while leaving the barrier lipids in place",
        "Niacinamide helps calm visible redness and refine the look of pores",
        "Fragrance-free formula that foams lightly rather than stripping the skin to squeak",
        "Safe for daily use morning and evening — no rebound oiliness later in the day"
      ],
      ingredients: [
        i("Niacinamide", "Reduces excess sebum and the look of enlarged pores"),
        i("Ceramides NP, AP, EOP", "Protect the barrier while cleansing"),
        i("Hyaluronic acid", "Prevents the tight, dry feeling after washing"),
        i("Cocamidopropyl hydroxysultaine", "Mild cleanser that foams without irritancy")
      ],
      directions:
        "Wet your face, work a small amount into a light lather in your hands, then massage over the face for 30 seconds. Rinse well and follow with moisturizer. Twice daily is enough — more is not better.",
      reviews: [
        r("Kevin M.", "Nyamirambo, Kigali", 5, "April 2025", "Foams just enough and my face is not shiny by 11am any more. I pair it with the niacinamide serum at night."),
        r("Yvette R.", "Rubavu", 4.5, "January 2025", "Cleans well without leaving my skin screaming for moisturiser. One pump is plenty.")
      ]
    }),
    p({
      id: "cerave-moisturizing-cream",
      photos: ["assets/img/cerave-moisturizing-cream.jpg"],
      name: "Moisturizing Cream",
      brand: "CeraVe",
      brandId: "cerave",
      price: 38000,
      tint: "#2e6fa8",
      size: "454 g",
      form: "tub",
      category: "moisturizers",
      also: ["body-care"],
      collections: ["best-sellers"],
      skinTypes: ["dry", "normal", "sensitive"],
      concerns: ["dryness", "body-dryness", "sensitivity"],
      rating: 4.9,
      reviewCount: 302,
      texture: "Rich cream",
      short:
        "The thick ceramide and hyaluronic acid cream that does the heavy lifting for very dry skin on face and body.",
      benefits: [
        "Seals in hydration for 24 hours with a barrier of three ceramides and hyaluronic acid",
        "One tub does face, elbows, knees and the dry patches on legs — exceptional value",
        "Unscented and non-greasy once absorbed, so it layers under sunscreen in the morning",
        "Recommended by dermatologists for eczema-prone, very dry and winter-dry skin"
      ],
      ingredients: [
        i("Ceramides NP, AP, EOP", "Restore the skin's own protective lipids"),
        i("Hyaluronic acid", "Pulls water into the upper layers of the skin"),
        i("Petrolatum and dimethicone", "Prevent water loss overnight"),
        i("MVE delivery technology", "Keeps releasing moisture for 24 hours")
      ],
      directions:
        "Apply a generous layer to clean skin morning and evening, and immediately after bathing while the skin is still damp. For very dry patches, apply a second thicker layer at night. A little goes a long way — warm it between your palms first.",
      reviews: [
        r("Jean-Claude N.", "Musanze", 4.5, "January 2025", "The only cream that survives a cold Musanze evening. No more ashy grey look by mid-afternoon."),
        r("Grace I.", "Rwamagana", 5, "March 2025", "Bought it for my face but it now lives on the whole family. The 454g tub lasts about three months.")
      ]
    }),
    p({
      id: "cerave-sa-smoothing-cleanser",
      photos: ["assets/img/cerave-sa-smoothing-cleanser.jpg"],
      name: "SA Smoothing Cleanser",
      brand: "CeraVe",
      brandId: "cerave",
      price: 32000,
      tint: "#2e6fa8",
      size: "236 ml",
      form: "pump",
      category: "cleansers",
      also: ["acne-care", "body-care"],
      skinTypes: ["oily", "combination", "normal"],
      concerns: ["acne", "large-pores", "body-dryness"],
      rating: 4.7,
      reviewCount: 96,
      texture: "Gel with fine micro-beads",
      short:
        "A salicylic acid cleanser that smooths rough, bumpy texture on the face, shoulders and upper arms.",
      benefits: [
        "Salicylic acid loosens the dead cells that clog pores and cause blackheads",
        "Smooths keratosis pilaris-type bumps on arms and thighs as well as the face",
        "Ceramides keep the barrier intact — this is not a scrub that leaves skin raw",
        "Fragrance-free and gentle enough for daily use on congested skin"
      ],
      ingredients: [
        i("Salicylic acid", "Exfoliates inside the pore to clear congestion"),
        i("Ceramides NP, AP, EOP", "Maintain the barrier during exfoliation"),
        i("Niacinamide", "Calms redness and helps balance oil"),
        i("Hyaluronic acid", "Keeps the skin from drying out")
      ],
      directions:
        "Use once daily at most, either in the morning or evening. Massage onto wet skin for 30 seconds and rinse. If you use a retinol or a peel at night, keep this in the morning. Always follow with moisturizer and daily SPF.",
      reviews: [
        r("Sandrine B.", "Kibagabaga, Kigali", 5, "February 2025", "Cleared the little bumps along my jawline that nothing else touched. I use it every other night."),
        r("Thierry H.", "Kigali", 4.5, "December 2024", "Great on my shoulders too, which I did not expect. Do not use it with the peel on the same night.")
      ]
    }),

    /* ──────────────────────────────────────────────────── La Roche-Posay */
    p({
      id: "lrp-effaclar-duo-m",
      photos: ["assets/img/la-roche-posay-effaclar-duo-plus.jpg"],
      name: "Effaclar Duo+ M Corrective Care",
      brand: "La Roche-Posay",
      brandId: "la-roche-posay",
      price: 45000,
      tint: "#1f6fb2",
      size: "40 ml",
      form: "tube",
      category: "acne-care",
      also: ["hyperpigmentation"],
      collections: ["best-sellers"],
      skinTypes: ["oily", "combination", "normal"],
      concerns: ["acne", "post-acne-marks", "large-pores", "oiliness"],
      rating: 4.8,
      reviewCount: 186,
      texture: "Light gel-cream",
      short:
        "The breakout treatment that also fades the marks left behind — salicylic acid, niacinamide and Procerad in one step.",
      benefits: [
        "Treats active breakouts with salicylic acid and LHA while reducing the number of new ones",
        "Procerad and niacinamide target the red and brown marks acne leaves behind",
        "Light, non-greasy texture that works as your whole moisturizer on oily skin",
        "Suitable as a full-face treatment, not just on the spots — which is how it works best"
      ],
      ingredients: [
        i("Salicylic acid + LHA", "Unclog pores and smooth the surface"),
        i("Niacinamide (4%)", "Reduce inflammation and post-acne redness"),
        i("Procerad", "Helps prevent the marks that form after a breakout"),
        i("Zinc PCA", "Controls sebum production through the day")
      ],
      directions:
        "Apply a thin layer to the whole face after cleansing, morning or evening. Start once daily for the first week if your skin is sensitive, then move to twice daily. Follow with sunscreen every morning — it is essential while fading marks.",
      reviews: [
        r("Aline U.", "Nyarugenge, Kigali", 5, "March 2025", "My dark marks faded faster than with anything else. It also stopped the monthly jawline breakout."),
        r("Josiane M.", "Huye", 4.5, "February 2025", "Took about six weeks to see a real change and they told me that upfront. Worth being patient.")
      ],
      faqs: [
        { q: "Can I use it with the peel at home?", a: "No. Do not layer Effaclar Duo+ M with The Ordinary AHA 30% + BHA 2% Peeling Solution on the same day — use them on alternate nights at most." },
        { q: "Does it bleach or lighten skin?", a: "It does not bleach. It reduces the post-inflammatory marks from acne and evens the surface, which looks like fading but is not skin lightening." }
      ]
    }),
    p({
      id: "lrp-anthelios-uvmune-400",
      photos: ["assets/img/la-roche-posay-anthelios-uvmune-400.jpg"],
      name: "Anthelios UVMune 400 Invisible Fluid SPF 50+",
      brand: "La Roche-Posay",
      brandId: "la-roche-posay",
      price: 52000,
      tint: "#1f6fb2",
      size: "50 ml",
      form: "dropper",
      category: "sunscreens",
      collections: ["best-sellers"],
      skinTypes: ["oily", "combination", "normal", "sensitive"],
      concerns: ["dark-spots", "hyperpigmentation", "oiliness", "fine-lines"],
      rating: 4.9,
      reviewCount: 231,
      texture: "Weightless fluid",
      spf: "SPF 50+ / PA++++",
      short:
        "Invisible fluid sunscreen with Mexoryl 400 that protects against the deep UVA that drives pigmentation.",
      benefits: [
        "Mexoryl 400 filters the longest UVA rays — the ones that keep dark spots coming back",
        "Truly invisible on deep skin tones, with no white cast and no grey film",
        "Light enough to wear every day without making oily skin oilier",
        "Water, sweat and sand resistant — built for the Rwandan dry season and swimming"
      ],
      ingredients: [
        i("Mexoryl 400", "Filters ultra-long UVA, the main driver of pigmentation"),
        i("Broad-spectrum UVB filters", "Prevent burning and sun-induced ageing"),
        i("Vitamin E", "Antioxidant back-up against free radical damage"),
        i("Glycerin", "Keeps the fluid comfortable rather than drying")
      ],
      directions:
        "Apply as the last step of your morning routine — about two finger-lengths for the face and neck, more if you are outdoors all day. Reapply every two hours outdoors, after swimming or heavy sweating. It is not optional when treating dark spots.",
      reviews: [
        r("Yvette R.", "Rubavu", 5, "March 2025", "No white cast on my skin at all, which is why I finally use sunscreen every day. Feels like nothing on the face."),
        r("Claudine A.", "Kigali", 5, "April 2025", "I treat pigmentation and this is the non-negotiable part. My patches stopped coming back after I started applying enough of it.")
      ],
      faqs: [
        { q: "Do I need sunscreen indoors?", a: "If you sit near a window or drive during the day, yes. UVA passes through glass and it is the wavelength that keeps pigment active." },
        { q: "Will it pill under my cream?", a: "Apply moisturizer first, wait a minute, then the fluid. Do not rub hard and do not layer a heavy primer on top." }
      ]
    }),
    p({
      id: "lrp-cicaplast-baume-b5",
      photos: ["assets/img/la-roche-posay-cicaplast-baume-b5.jpg"],
      name: "Cicaplast Baume B5 Repair Balm",
      brand: "La Roche-Posay",
      brandId: "la-roche-posay",
      price: 32000,
      tint: "#1f6fb2",
      size: "40 ml",
      form: "tube",
      category: "moisturizers",
      also: ["body-care"],
      collections: ["best-sellers"],
      skinTypes: ["dry", "sensitive", "normal", "oily"],
      concerns: ["sensitivity", "dryness", "post-acne-marks"],
      rating: 4.9,
      reviewCount: 267,
      texture: "Thick occlusive balm",
      short:
        "The multi-purpose repair balm for irritated, over-treated skin — 5% panthenol plus madecassoside.",
      benefits: [
        "Calms the redness, peeling and tightness that follow too many actives at once",
        "5% panthenol and madecassoside speed up the skin's own repair process",
        "Works on cracked lips, dry patches, post-shaving redness and minor burns",
        "Thick balm that stays put overnight, so you wake up with a barrier again"
      ],
      ingredients: [
        i("Panthenol 5%", "Soothes irritation and supports repair"),
        i("Madecassoside", "Reduces visible redness"),
        i("Shea butter", "Replenishes lipids and seals in water"),
        i("Zinc and manganese", "Protect compromised skin")
      ],
      directions:
        "Apply a thick layer to irritated areas, morning and evening, or as an overnight mask on the whole face after a reaction. It is rich — use it as your last step, and only where you need it. Give your routine a break of two weeks when you repair.",
      reviews: [
        r("Diane K.", "Huye", 5, "April 2025", "Years of harsh cleansers left my cheeks permanently red. Two weeks of this at night and it has almost gone."),
        r("Kevin M.", "Nyamirambo, Kigali", 5, "January 2025", "I overdid the acids once and this saved my face. Now it is my emergency product.")
      ]
    }),
    p({
      id: "lrp-effaclar-purifying-foaming-gel",
      photos: ["assets/img/la-roche-posay-effaclar-purifying-foaming-gel.jpg"],
      name: "Effaclar Purifying Foaming Gel",
      brand: "La Roche-Posay",
      brandId: "la-roche-posay",
      price: 34000,
      tint: "#1f6fb2",
      size: "200 ml",
      form: "pump",
      category: "cleansers",
      also: ["acne-care"],
      skinTypes: ["oily", "combination"],
      concerns: ["oiliness", "acne", "large-pores"],
      rating: 4.7,
      reviewCount: 143,
      texture: "Clear gel, foaming",
      short: "A soap-free purifying gel for oily and congested skin that respects an already-reactive barrier.",
      benefits: [
        "Removes oil, sweat and pollution without soap or alcohol that trigger more oil",
        "pH-balanced so it does not disturb the acid mantle of acne-prone skin",
        "Leaves the skin matte and comfortable rather than tight and stretched",
        "Works as the first step of an Effaclar routine when used with the Duo+ treatment"
      ],
      ingredients: [
        i("Zinc PCA", "Reduces sebum and keeps pores clearer"),
        i("Gentle cleansing base", "Removes oil without stripping"),
        i("La Roche-Posay thermal spring water", "Soothes and softens"),
        i("Citric acid", "Keeps the formula at skin-friendly pH")
      ],
      directions:
        "Use morning and evening. Lather in wet hands and massage over the face for 30 seconds, avoiding the eye area. Rinse thoroughly. Follow with Effaclar Duo+ M and a moisturizer.",
      reviews: [
        r("Patrick N.", "Gikondo, Kigali", 5, "March 2025", "Finally a foaming wash that does not leave my face feeling sandpaper-dry."),
        r("Josiane M.", "Huye", 4.5, "January 2025", "Good for my oily forehead. In the dry season I only use it at night and a hydrating cleanser in the morning.")
      ]
    }),

    /* ─────────────────────────────────────────────────────── The Ordinary */
    p({
      id: "ordinary-niacinamide-10-zinc-1",
      photos: ["assets/img/the-ordinary-niacinamide-10-zinc-1.jpg"],
      name: "Niacinamide 10% + Zinc 1%",
      brand: "The Ordinary",
      brandId: "the-ordinary",
      price: 22000,
      tint: "#7c7c7c",
      size: "30 ml",
      form: "dropper",
      category: "serums",
      also: ["acne-care"],
      collections: ["best-sellers"],
      skinTypes: ["oily", "combination", "normal"],
      concerns: ["oiliness", "large-pores", "acne", "post-acne-marks"],
      rating: 4.8,
      reviewCount: 389,
      texture: "Light watery serum",
      spf: "",
      short:
        "The high-strength niacinamide serum that visibly reduces shine, refines pores and calms blemish-prone skin.",
      benefits: [
        "Noticeably less shine by the middle of the day, usually within two to three weeks",
        "Niacinamide reinforces the barrier while zinc helps regulate sebum",
        "Softens the look of enlarged pores and evens out post-blemish tone",
        "Fragrance-free and silicone-free — it layers under moisturizer without pilling"
      ],
      ingredients: [
        i("Niacinamide 10%", "Iron out shine, redness and uneven tone"),
        i("Zinc PCA 1%", "Balance sebum and reduce congestion"),
        i("Tamarindus indica gum", "Gives the serum its light gel texture"),
        i("Phenoxyethanol", "Gentle preservative system")
      ],
      directions:
        "Apply a few drops to clean, dry skin morning and evening before heavier creams. Do not use it at the same time as a strong vitamin C — keep one for the morning and the other for the evening. Introduce it over a week if your skin is new to niacinamide.",
      reviews: [
        r("Kevin M.", "Nyamirambo, Kigali", 5, "February 2025", "Half a bottle in and the shine and the pores on my nose look completely different. Best 22,000 RWF I have spent."),
        r("Aline U.", "Nyarugenge, Kigali", 4.5, "December 2024", "Works, but it can sting if you layer too much the first day. Start with a few drops only.")
      ],
      faqs: [
        { q: "Why does my bottle look almost empty?", a: "It contains 30 ml of liquid in a standard bottle — The Ordinary fills to the stated volume, not to the shoulder. Weigh it if you are unsure; it is a genuine product." },
        { q: "Can I use it with vitamin C?", a: "Technically yes, but many people find the combination irritating. Alternate: vitamin C in the morning, niacinamide at night." }
      ]
    }),
    p({
      id: "ordinary-alpha-arbutin-2-ha",
      photos: ["assets/img/the-ordinary-alpha-arbutin-2-ha.jpg"],
      name: "Alpha Arbutin 2% + HA",
      brand: "The Ordinary",
      brandId: "the-ordinary",
      price: 26000,
      tint: "#7c7c7c",
      size: "30 ml",
      form: "dropper",
      category: "serums",
      also: ["hyperpigmentation"],
      skinTypes: ["normal", "dry", "combination", "oily", "sensitive"],
      concerns: ["dark-spots", "hyperpigmentation", "post-acne-marks", "dullness"],
      rating: 4.7,
      reviewCount: 246,
      texture: "Watery serum",
      short:
        "A targeted brightening serum for dark spots and uneven tone, gentle enough for sensitive skin to tolerate.",
      benefits: [
        "Alpha arbutin reduces the over-production of melanin that creates dark spots",
        "Visibly fades post-acne marks and sun-induced patches over 8 to 12 weeks",
        "Hyaluronic acid keeps the skin hydrated, so it never feels drying like strong lighteners can",
        "Gentle enough for daily use, unlike hydroquinone or high-strength acids"
      ],
      ingredients: [
        i("Alpha arbutin 2%", "Inhibits excess melanin production at the source"),
        i("Hyaluronic acid", "Holds water to offset any dryness"),
        i("Hydrolysed hyaluronic acid", "Hydrates deeper layers of the skin")
      ],
      directions:
        "Apply a few drops to clean skin morning and evening before moisturizer, on the whole face or just the spots. Sunscreen every morning is essential — without it, no brightening product can work.",
      reviews: [
        r("Sandrine B.", "Kibagabaga, Kigali", 5, "May 2025", "The marks on my cheeks faded slowly but they did fade. Eight weeks, exactly as they told me."),
        r("Claudine A.", "Kigali", 4.5, "March 2025", "One of the few lightening products my skin did not react to. I use it with the Eucerin serum and sunscreen.")
      ]
    }),
    p({
      id: "ordinary-glycolic-acid-7-toning-solution",
      photos: ["assets/img/the-ordinary-glycolic-acid-7-toning-solution.jpg"],
      name: "Glycolic Acid 7% Toning Solution",
      brand: "The Ordinary",
      brandId: "the-ordinary",
      price: 30000,
      tint: "#7c7c7c",
      size: "240 ml",
      form: "bottle",
      category: "toners",
      skinTypes: ["normal", "oily", "combination"],
      concerns: ["dullness", "large-pores", "hyperpigmentation"],
      rating: 4.7,
      reviewCount: 187,
      texture: "Watery exfoliating toner",
      short:
        "An exfoliating toner that resurfaces the skin, restoring glow and smoothing the texture acids have made bumpy.",
      benefits: [
        "Glycolic acid lifts the dead cell layer that makes skin look flat and grey",
        "Smooths rough texture and softens the appearance of pores with regular use",
        "240 ml lasts months — use it on the face, and even on elbows and knees",
        "Ginseng and aloe keep it from being as harsh as a pure acid toner"
      ],
      ingredients: [
        i("Glycolic acid 7%", "Resurfaces and brightens the top layer"),
        i("Aloe barbadensis", "Soothes and reduces stinging"),
        i("Ginseng root extract", "Antioxidant support for tired skin"),
        i("Aminomethyl propanol", "Balances the pH so it is effective but tolerable")
      ],
      directions:
        "Use at night only, after cleansing, on a cotton pad — two or three times a week to start. Avoid the eye and lip areas. Do not use it on the same night as a retinol, a peel or salicylic acid, and always wear sunscreen the next morning.",
      reviews: [
        r("Josiane M.", "Huye", 5, "April 2025", "My skin looks like it has been professionally exfoliated. Twice a week is more than enough."),
        r("Patrick N.", "Gikondo, Kigali", 4.5, "February 2025", "Strong — I learned the hard way not to use it the same night as the peeling solution.")
      ]
    }),
    p({
      id: "ordinary-azelaic-acid-10",
      photos: ["assets/img/the-ordinary-azelaic-acid-10.jpg"],
      name: "Azelaic Acid Suspension 10%",
      brand: "The Ordinary",
      brandId: "the-ordinary",
      price: 24000,
      tint: "#7c7c7c",
      size: "30 ml",
      form: "tube",
      category: "acne-care",
      also: ["hyperpigmentation"],
      skinTypes: ["oily", "combination", "normal", "sensitive"],
      concerns: ["acne", "post-acne-marks", "sensitivity", "hyperpigmentation"],
      rating: 4.6,
      reviewCount: 158,
      texture: "Silicone suspension",
      short:
        "Azelaic acid in a light cream suspension — the gentlest way to treat both breakouts and the marks they leave.",
      benefits: [
        "Reduces acne-causing bacteria and inflammation without the peeling of stronger retinoids",
        "Fades post-acne marks and redness as effectively as it treats the spots",
        "Well tolerated by sensitive and rosacea-prone skin, including during pregnancy",
        "Cream-to-powder finish that also blurs the look of pores"
      ],
      ingredients: [
        i("Azelaic acid 10%", "Antibacterial, anti-inflammatory, fades marks"),
        i("Dimethicone", "Gives the soft powder finish"),
        i("Tocopherol", "Antioxidant protection")
      ],
      directions:
        "Apply a pea-sized amount to clean, dry skin in the evening, on the whole face or just the affected areas. Follow with moisturizer. Some people feel a brief tingling on the first few uses — that settles. Use daily for at least eight weeks.",
      reviews: [
        r("Nadia S.", "Kimironko, Kigali", 4.5, "March 2025", "The first acne treatment that did not turn my face red. The marks are going too."),
        r("Thierry H.", "Kigali", 4.5, "January 2025", "Tingles for the first minute then settles. Use it before the moisturiser, not after.")
      ]
    }),
    p({
      id: "ordinary-aha-30-bha-2-peeling-solution",
      photos: ["assets/img/the-ordinary-aha-30-bha-2-peeling-solution.jpg"],
      name: "AHA 30% + BHA 2% Peeling Solution",
      brand: "The Ordinary",
      brandId: "the-ordinary",
      price: 28000,
      tint: "#7c7c7c",
      size: "30 ml",
      form: "dropper",
      category: "serums",
      also: ["acne-care", "hyperpigmentation"],
      skinTypes: ["normal", "oily", "combination"],
      concerns: ["dullness", "large-pores", "acne", "hyperpigmentation"],
      rating: 4.6,
      reviewCount: 274,
      texture: "Blood-red liquid peel",
      stock: "low",
      short:
        "The ten-minute at-home exfoliating peel that transforms texture and glow — for experienced acid users only.",
      benefits: [
        "Thirty percent AHA acids lift a whole layer of dead cells in ten minutes",
        "BHA gets inside the pore to clear blackheads and congestion",
        "Visible smoothing and glow after the very first use, with texture improving over a month",
        "Noticeably shortens the life of stubborn blackheads on the nose and chin"
      ],
      ingredients: [
        i("Glycolic, lactic, tartaric, citric acids 30%", "Resurface the dead cell layer"),
        i("Salicylic acid 2%", "Clears congestion inside the pore"),
        i("Tasmannia lanceolata", "Reduces the sting of the acids"),
        i("Sodium hyaluronate crosspolymer", "Restores water after the peel")
      ],
      directions:
        "For experienced acid users only. Cleanse and dry the skin completely — damp skin makes it stronger. Apply an even, thin layer avoiding the eye and mouth area. Leave exactly ten minutes and no longer, then rinse thoroughly with lukewarm water. Use once a week at most, never on the same day as retinol, and always with sunscreen the next day. Do not use during pregnancy or on sensitive skin.",
      reviews: [
        r("Josiane M.", "Huye", 5, "February 2025", "My skin is glassy the next morning. Once a week, ten minutes, timer on. But do read the label first."),
        r("Kevin M.", "Nyamirambo, Kigali", 4, "January 2025", "Very strong — I got it wrong once and peeled for three days. Respect the ten minutes.")
      ],
      faqs: [
        { q: "Is this safe for beginners?", a: "No. If you have never used an acid, start with the Glycolic Acid 7% Toning Solution twice a week for a month first, and only then consider this." },
        { q: "It tingles a lot — is that normal?", a: "Mild tingling is expected in the first minutes. Burning pain, or skin that stays red after rinsing, means wash it off sooner next time and build up more slowly." }
      ]
    }),

    /* ───────────────────────────────────────────────────────────────── Anua */
    p({
      id: "anua-heartleaf-77-soothing-toner",
      photos: ["assets/img/anua-heartleaf-77-soothing-toner.jpg"],
      name: "Heartleaf 77% Soothing Toner",
      brand: "Anua",
      brandId: "anua",
      price: 38000,
      tint: "#4e7c4a",
      size: "250 ml",
      form: "bottle",
      category: "toners",
      also: ["korean-skincare"],
      collections: ["best-sellers"],
      skinTypes: ["oily", "combination", "sensitive", "normal"],
      concerns: ["acne", "sensitivity", "large-pores", "oiliness"],
      rating: 4.8,
      reviewCount: 205,
      texture: "Watery toner",
      short:
        "A 77% heartleaf toner that calms angry, reactive skin and preps it for everything that follows.",
      benefits: [
        "Calms redness and the heat of a fresh breakout in minutes of applying",
        "77% heartleaf extract is deeply soothing without fragrance or alcohol",
        "Light, watery texture that hydrates oily skin without any stickiness",
        "Excellent pre-treatment step — layer it before niacinamide or salicylic acid"
      ],
      ingredients: [
        i("Houttuynia cordata (heartleaf) extract 77%", "Calms inflammation and soothes irritated skin"),
        i("Betaine and panthenol", "Attract water and reduce tightness"),
        i("Madecassoside", "Supports barrier recovery"),
        i("Allantoin", "Softens and comforts reactive skin")
      ],
      directions:
        "After cleansing, pour a few drops into your palms and press gently over the face, or sweep with a cotton pad. Layer it two or three times if your skin is dehydrated. Use morning and evening, and follow with serum and moisturizer.",
      reviews: [
        r("Aline U.", "Nyarugenge, Kigali", 5, "April 2025", "When my skin is angry this is the only thing that calms it down. I keep a second bottle at my desk."),
        r("Nadia S.", "Kimironko, Kigali", 5, "March 2025", "Zero reaction, zero fragrance, and it makes my skin feel watered from the inside. 250ml lasts a long time.")
      ],
      faqs: [
        { q: "Is this a cleansing toner or an exfoliating one?", a: "Neither — it is a soothing, hydrating toner. It preps the skin and calms it. For exfoliating, use the COSRX AHA/BHA toner or The Ordinary glycolic toner instead." },
        { q: "Can I use it on acne?", a: "Yes, that is what it is for. It calms the inflammation of active breakouts and makes stronger actives easier to tolerate." }
      ]
    }),
    p({
      id: "anua-heartleaf-80-ampoule",
      photos: ["assets/img/anua-heartleaf-80-ampoule.jpg"],
      name: "Heartleaf 80% Moisture Soothing Ampoule",
      brand: "Anua",
      brandId: "anua",
      price: 42000,
      tint: "#4e7c4a",
      size: "30 ml",
      form: "dropper",
      category: "serums",
      also: ["korean-skincare"],
      collections: ["new-arrivals"],
      skinTypes: ["sensitive", "dry", "combination", "oily"],
      concerns: ["sensitivity", "dryness", "acne", "dullness"],
      rating: 4.7,
      reviewCount: 88,
      texture: "Light milky ampoule",
      short:
        "An 80% heartleaf ampoule that hydrates deeply while it soothes — the calming step for skin that reacts easily.",
      benefits: [
        "Deep, immediate hydration that lasts, without a heavy or greasy finish",
        "80% heartleaf extract calms redness while panthenol reinforces the barrier",
        "Strengthens the skin's tolerance so actives stop causing irritation",
        "Fragrance-free and gentle enough for the most reactive skin"
      ],
      ingredients: [
        i("Houttuynia cordata extract 80%", "Soothes and reduces visible redness"),
        i("Panthenol", "Repairs and comforts a stressed barrier"),
        i("Hyaluronic acid", "Multi-layer hydration"),
        i("Ceramide NP", "Restores barrier lipids")
      ],
      directions:
        "After toning, apply three to four drops and press gently into the skin. Use morning and evening before moisturizer. On very reactive days use it on its own, without any actives.",
      reviews: [
        r("Diane K.", "Huye", 5, "May 2025", "Calmer and less red within a week. It is the step that stopped my skin reacting to everything."),
        r("Yvette R.", "Rubavu", 4.5, "April 2025", "Very light, no fragrance, no stickiness. I use it before the Relief Sun in the morning.")
      ]
    }),
    p({
      id: "anua-niacinamide-txa-4-serum",
      name: "Niacinamide 10% + TXA 4% Serum",
      photos: ["assets/img/anua-niacinamide-txa-4-serum.jpg"],
      brand: "Anua",
      brandId: "anua",
      price: 45000,
      tint: "#4e7c4a",
      size: "30 ml",
      form: "dropper",
      category: "serums",
      also: ["hyperpigmentation", "korean-skincare"],
      collections: ["new-arrivals"],
      skinTypes: ["normal", "combination", "oily", "dry"],
      concerns: ["dark-spots", "hyperpigmentation", "post-acne-marks", "oiliness"],
      rating: 4.8,
      reviewCount: 61,
      texture: "Light serum",
      short:
        "Niacinamide and tranexamic acid together — the K-beauty pair that attacks pigmentation from two angles.",
      benefits: [
        "Tranexamic acid 4% targets stubborn pigmentation that niacinamide alone does not shift",
        "Niacinamide evens tone and reduces the shine and pore size along the way",
        "Lighter and more elegant than most brightening serums, with no pilling under makeup",
        "Fragrance-free and suitable for use with vitamin C or alpha arbutin"
      ],
      ingredients: [
        i("Niacinamide 10%", "Evens tone and controls shine"),
        i("Tranexamic acid 4%", "Targets melasma and stubborn dark patches"),
        i("Alpha-bisabolol", "Cools inflammation that keeps pigment active"),
        i("Panthenol", "Keeps the formula comfortable on sensitised skin")
      ],
      directions:
        "Apply a few drops to clean, dry skin morning and evening before moisturizer. Daily sunscreen is mandatory while using it — tranexamic acid works only when UV exposure is controlled. Give it 8 to 12 weeks.",
      reviews: [
        r("Claudine A.", "Kigali", 5, "May 2025", "I have tried three brightening serums and this is the one that moved the patches on my forehead."),
        r("Sandrine B.", "Kibagabaga, Kigali", 4.5, "April 2025", "Lovely texture, no irritation. Slowly fading marks alongside daily SPF.")
      ]
    }),

    /* ───────────────────────────────────────────────────────────── Bioderma */
    p({
      id: "bioderma-sensibio-h2o",
      photos: ["assets/img/bioderma-sensibio-h2o.jpg"],
      name: "Sensibio H2O Micellar Water",
      brand: "Bioderma",
      brandId: "bioderma",
      price: 40000,
      tint: "#1f8a8a",
      size: "500 ml",
      form: "bottle",
      category: "cleansers",
      collections: ["best-sellers"],
      skinTypes: ["sensitive", "dry", "normal", "combination", "oily"],
      concerns: ["sensitivity", "dryness"],
      rating: 4.9,
      reviewCount: 318,
      texture: "Micellar water",
      short:
        "The original micellar water — takes off sunscreen and makeup in one pass without rubbing or rinsing.",
      benefits: [
        "Removes long-wear makeup and sunscreen in one sweep, with no tugging on the skin",
        "No soap, no fragrance, no alcohol — dermatologists recommend it for reactive skin",
        "Needs no rinsing, so it is perfect when you are tired or travelling",
        "500 ml lasts three to four months used twice a day"
      ],
      ingredients: [
        i("Micelles (gentle surfactants)", "Lift oil, makeup and sunscreen without scrubbing"),
        i("Cucumber and mannitol", "Soothe and reduce reactivity"),
        i("Ginkgo biloba", "Antioxidant support"),
        i("Purified water", "Hypoallergenic base, pH balanced to the skin")
      ],
      directions:
        "Soak a cotton pad and hold it on the eye or lip area for a few seconds before wiping gently downwards. Use a fresh pad for the face. Follow with a cleanser if you wear heavy sunscreen, or use it alone as your evening cleanse on light days.",
      reviews: [
        r("Grace I.", "Rwamagana", 5, "March 2025", "Removes everything in one pad and never stings my eyes. The 500ml bottle is worth it."),
        r("Nadia S.", "Kimironko, Kigali", 5, "February 2025", "My skin is sensitive and this is the only micellar water that does not leave me red.")
      ]
    }),
    p({
      id: "bioderma-atoderm-intensive-baume",
      photos: ["assets/img/bioderma-atoderm-intensive-baume.jpg"],
      name: "Atoderm Intensive Baume",
      brand: "Bioderma",
      brandId: "bioderma",
      price: 42000,
      tint: "#1f8a8a",
      size: "500 ml",
      form: "pump",
      category: "body-care",
      skinTypes: ["dry", "sensitive"],
      concerns: ["body-dryness", "dryness", "sensitivity"],
      rating: 4.8,
      reviewCount: 129,
      texture: "Rich body balm",
      short:
        "A barrier-repairing body balm for very dry, itchy and eczema-prone skin, big enough to use daily.",
      benefits: [
        "Stops the itch-scratch cycle — clinically shown to reduce irritation within days",
        "Skin Barrier Therapy limits the bacteria that aggravate atopic skin",
        "Rich but absorbent, so it is comfortable in Rwandan heat and in bed",
        "500 ml pump for daily use on the whole body, adults and children over 3"
      ],
      ingredients: [
        i("Skin Barrier Therapy", "Reduces the bacterial adhesion behind irritation"),
        i("Ceramide and fatty acids", "Restore the skin's lipid barrier"),
        i("Vitamin PP", "Supports barrier synthesis"),
        i("Glycerin", "Deeply hydrating without a greasy film")
      ],
      directions:
        "Apply once or twice daily to clean, dry skin, and immediately after showering while the skin is still damp. Use lukewarm water and a soap-free wash for best results.",
      reviews: [
        r("Grace I.", "Rwamagana", 5, "April 2025", "The dry patches on my arms and legs that came back every dry season have not returned."),
        r("Jean-Claude N.", "Musanze", 5, "February 2025", "We use it on my son's eczema as well. It stopped the night-time scratching.")
      ]
    }),
    p({
      id: "bioderma-photoderm-aquafluide-spf50",
      photos: ["assets/img/bioderma-photoderm-aquafluide-spf50.jpg"],
      name: "Photoderm Aquafluide SPF 50+",
      brand: "Bioderma",
      brandId: "bioderma",
      price: 38000,
      tint: "#1f8a8a",
      size: "40 ml",
      form: "tube",
      category: "sunscreens",
      skinTypes: ["oily", "combination", "normal", "sensitive"],
      concerns: ["dark-spots", "oiliness", "sensitivity"],
      rating: 4.6,
      reviewCount: 97,
      texture: "Fluid",
      spf: "SPF 50+ / UVA 32",
      short: "An ultra-light sunscreen fluid for combination and sensitive skin that dislikes heavy creams.",
      benefits: [
        "Watery, matte fluid that disappears into the skin with no greasy shine",
        "High UVA protection (UVA 32) to keep pigmentation from reactivating",
        "Tolerated by sensitive and intolerant skin, with no fragrance",
        "A strong alternative for anyone who finds most sunscreens too thick for Kigali heat"
      ],
      ingredients: [
        i("Broad-spectrum filter complex", "UVB plus high UVA protection"),
        i("Vitamin E and C", "Antioxidants that limit sun damage"),
        i("Glycerin", "Keeps the fluid comfortable"),
        i("Sunsitive complex", "Protects against intolerance under UV")
      ],
      directions:
        "Apply generously as the last step of your morning routine, at least 15 minutes before going outside. Reapply every two hours outdoors or after sweating. Shake before use.",
      reviews: [
        r("Kevin M.", "Nyamirambo, Kigali", 4.5, "March 2025", "Very light and no shine. Easier to wear every day than the ones that feel like paint."),
        r("Patrick N.", "Gikondo, Kigali", 4.5, "January 2025", "Good for oily skin. It does leave a slight sheen, so I powder my forehead.")
      ]
    }),
    /* ─────────────────────────────────────────────────────────────── COSRX */
    p({
      id: "cosrx-advanced-snail-96-mucin-power-essence",
      photos: ["assets/img/cosrx-advanced-snail-96-mucin-power-essence.jpg"],
      name: "Advanced Snail 96 Mucin Power Essence",
      brand: "COSRX",
      brandId: "cosrx",
      price: 34000,
      tint: "#c9bfa8",
      size: "100 ml",
      form: "bottle",
      category: "serums",
      also: ["korean-skincare"],
      collections: ["best-sellers"],
      skinTypes: ["dry", "normal", "combination", "sensitive", "oily"],
      concerns: ["dryness", "dullness", "post-acne-marks", "fine-lines"],
      rating: 4.9,
      reviewCount: 356,
      texture: "Light stringy essence",
      short:
        "96% snail secretion filtrate — the cult K-beauty essence that repairs, hydrates and gives skin its bounce back.",
      benefits: [
        "96% snail mucin filtrate supports repair and leaves skin plump and bouncy",
        "Deep hydration without oil, so it suits both dry and oily skin",
        "Evens out the surface so old post-acne marks look less obvious over time",
        "Layers under anything — no pilling, no fragrance, no sting"
      ],
      ingredients: [
        i("Snail secretion filtrate 96%", "Supports repair and deep hydration"),
        i("Sodium hyaluronate", "Draws water into the skin"),
        i("Panthenol", "Soothes and reduces tightness"),
        i("Allantoin", "Softens rough texture")
      ],
      directions:
        "After toning, apply a few drops and press into the skin. Use morning and evening. On very dry days layer it twice, and follow with moisturizer to seal it in.",
      reviews: [
        r("Yvette R.", "Rubavu", 5, "April 2025", "My skin has never been this soft. I use it morning and night and one bottle lasts nearly three months."),
        r("Aline U.", "Nyarugenge, Kigali", 5, "March 2025", "The glow is real. It also calmed my skin after the acids, without any fragrance sting.")
      ],
      faqs: [
        { q: "Is snail mucin safe for acne-prone skin?", a: "Yes — it is a humectant and repair ingredient, not an oil. Many people with acne find it speeds up the healing of marks. If you are allergic to dust mites, patch-test behind the ear first." }
      ]
    }),
    p({
      id: "cosrx-low-ph-good-morning-gel-cleanser",
      photos: ["assets/img/cosrx-low-ph-morning-gel-cleanser.jpg"],
      name: "Low pH Good Morning Gel Cleanser",
      brand: "COSRX",
      brandId: "cosrx",
      price: 26000,
      tint: "#c9bfa8",
      size: "150 ml",
      form: "tube",
      category: "cleansers",
      also: ["korean-skincare", "acne-care"],
      skinTypes: ["oily", "combination", "normal", "sensitive"],
      concerns: ["acne", "oiliness", "large-pores"],
      rating: 4.7,
      reviewCount: 241,
      texture: "Clear gel, mildly foaming",
      short:
        "A mild low-pH gel cleanser that cleans thoroughly without disturbing the acid mantle acne-prone skin needs intact.",
      benefits: [
        "Low pH formula keeps the skin's acid mantle in balance, so oil stays controlled",
        "Tea tree and BHA help keep congestion and small breakouts in check",
        "Mild enough to use twice a day, including on sensitive skin",
        "Removes sunscreen and excess oil without the squeaky tight feeling"
      ],
      ingredients: [
        i("Tea tree leaf oil", "Naturally antibacterial and calming"),
        i("Betaine salicylate", "Gentle daily exfoliation inside the pore"),
        i("Saccharomyces ferment", "Supports the skin's microbiome"),
        i("Mild amino acid surfactants", "Clean without stripping")
      ],
      directions:
        "Use morning and evening. Lather a small amount in wet hands, massage over the face for 30 seconds and rinse thoroughly. Follow with toner and moisturizer.",
      reviews: [
        r("Patrick N.", "Gikondo, Kigali", 5, "March 2025", "Gentle enough for twice a day and my breakouts are calmer since I switched from soap."),
        r("Nadia S.", "Kimironko, Kigali", 4.5, "February 2025", "The tea tree smells fresh and it never leaves my face tight. Good value for 150ml.")
      ]
    }),
    p({
      id: "cosrx-aha-bha-clarifying-toner",
      photos: ["assets/img/cosrx-aha-bha-clarifying-toner.jpg"],
      name: "AHA/BHA Clarifying Treatment Toner",
      brand: "COSRX",
      brandId: "cosrx",
      price: 32000,
      tint: "#c9bfa8",
      size: "150 ml",
      form: "spray",
      category: "toners",
      also: ["korean-skincare", "acne-care"],
      skinTypes: ["oily", "combination", "normal"],
      concerns: ["large-pores", "acne", "dullness", "oiliness"],
      rating: 4.6,
      reviewCount: 132,
      texture: "Fine mist",
      short: "A daily exfoliating mist with AHA and BHA that keeps pores clear without a full acid routine.",
      benefits: [
        "Gentle daily exfoliation that prevents congestion before it becomes a breakout",
        "AHA and BHA together smooth the surface and clean inside the pore",
        "Fine mist format — no cotton pads, no friction, no waste",
        "Preps the skin so serums absorb better straight afterwards"
      ],
      ingredients: [
        i("Glycolic acid (AHA)", "Smooths the surface and brightens"),
        i("Betaine salicylate (BHA)", "Keeps pores clear of congestion"),
        i("Willow bark water", "Natural exfoliating support"),
        i("Butylene glycol", "Hydrates and aids absorption")
      ],
      directions:
        "After cleansing, mist over the face from about 20 cm, morning and evening, and allow it to dry before your next step. If your skin is sensitive, start once a day. Always wear sunscreen.",
      reviews: [
        r("Josiane M.", "Huye", 4.5, "April 2025", "The mist is so easy to use that I actually keep up with it. Fewer blackheads on my nose."),
        r("Kevin M.", "Nyamirambo, Kigali", 5, "January 2025", "I spray it on after cleansing and my niacinamide absorbs better. Two products in one step.")
      ]
    }),

    /* ─────────────────────────────────────────────────── Beauty of Joseon */
    p({
      id: "beauty-of-joseon-relief-sun",
      photos: ["assets/img/beauty-of-joseon-relief-sun.jpg"],
      name: "Relief Sun: Rice + Probiotics SPF 50+",
      brand: "Beauty of Joseon",
      brandId: "beauty-of-joseon",
      price: 30000,
      tint: "#c99a5e",
      size: "50 ml",
      form: "tube",
      category: "sunscreens",
      also: ["korean-skincare"],
      collections: ["best-sellers"],
      skinTypes: ["dry", "normal", "combination", "sensitive"],
      concerns: ["dark-spots", "dryness", "dullness", "fine-lines"],
      rating: 4.9,
      reviewCount: 412,
      texture: "Cream",
      spf: "SPF 50+ / PA++++",
      short:
        "The sunscreen that feels like a moisturizer — zero white cast on deep skin tones, and it disappears into the face.",
      benefits: [
        "Moisturizer-light texture with no white cast on any skin tone, including deep brown skin",
        "Rice extract and probiotics leave the skin soft rather than chalky",
        "Comfortable enough to wear every single day, which is the only way SPF works",
        "Perfect under makeup — no pilling, no greasy shine in Kigali heat"
      ],
      ingredients: [
        i("Rice extract (30%)", "Brightens and softens the skin"),
        i("Panax ginseng and greentea", "Antioxidant support"),
        i("Lactobacillus ferment", "Supports the skin barrier"),
        i("Broad-spectrum UV filters", "SPF 50+ PA++++ protection")
      ],
      directions:
        "Apply a generous amount as the final step of your morning routine — about two finger-lengths for the face and neck. Reapply every two hours when you are outdoors.",
      reviews: [
        r("Yvette R.", "Rubavu", 5, "March 2025", "I gave up on sunscreen because of the grey cast. This one is invisible on my skin and it moisturises at the same time."),
        r("Claudine A.", "Kigali", 5, "May 2025", "I have gone through four tubes. Nothing else sits under makeup this well.")
      ],
      faqs: [
        { q: "Is one application a day enough?", a: "For a working day mostly indoors, yes. If you are outdoors, sweating or in the car for long stretches, reapply every two hours." }
      ]
    }),
    p({
      id: "beauty-of-joseon-glow-deep-serum",
      photos: ["assets/img/beauty-of-joseon-glow-deep-serum.jpg"],
      name: "Glow Deep Serum: Rice + Alpha Arbutin",
      brand: "Beauty of Joseon",
      brandId: "beauty-of-joseon",
      price: 34000,
      tint: "#c99a5e",
      size: "30 ml",
      form: "dropper",
      category: "serums",
      also: ["hyperpigmentation", "korean-skincare"],
      collections: ["new-arrivals"],
      skinTypes: ["normal", "dry", "combination", "oily"],
      concerns: ["dullness", "dark-spots", "hyperpigmentation", "post-acne-marks"],
      rating: 4.8,
      reviewCount: 104,
      texture: "Light silky serum",
      short:
        "A brightening serum that fades pigmentation and brings back the glow, with alpha arbutin from rice.",
      benefits: [
        "Alpha arbutin targets excess melanin, fading dark spots and uneven patches",
        "68% rice bran water brightens and softens dull, tired-looking skin",
        "Light, silky and non-sticky — comfortable in humidity",
        "Fragrance-free and gentle enough for daily use on most skins"
      ],
      ingredients: [
        i("Rice bran water 68%", "Brightens and conditions"),
        i("Alpha arbutin 2%", "Inhibits excess melanin production"),
        i("Niacinamide", "Evens tone and refines texture"),
        i("Panthenol", "Keeps it comfortable on sensitised skin")
      ],
      directions:
        "Apply two to three drops to clean, toned skin morning and evening, before moisturizer. Sunscreen every morning without fail, or the results will not hold.",
      reviews: [
        r("Sandrine B.", "Kibagabaga, Kigali", 5, "April 2025", "Smoother and brighter in about six weeks. It feels like a nice serum rather than a clinical product."),
        r("Diane K.", "Huye", 4.5, "May 2025", "No irritation at all on my sensitive skin, which is rare for a brightening serum.")
      ]
    }),

    /* ────────────────────────────────────────────────────────────── Eucerin */
    p({
      id: "eucerin-anti-pigment-dual-serum",
      photos: ["assets/img/eucerin-anti-pigment-dual-serum.jpg"],
      name: "Anti-Pigment Dual Serum",
      brand: "Eucerin",
      brandId: "eucerin",
      price: 58000,
      tint: "#8aa6c4",
      size: "30 ml",
      form: "dropper",
      category: "hyperpigmentation",
      also: ["serums"],
      collections: ["best-sellers"],
      skinTypes: ["normal", "dry", "combination", "oily", "sensitive"],
      concerns: ["hyperpigmentation", "dark-spots", "post-acne-marks", "dullness"],
      rating: 4.9,
      reviewCount: 173,
      texture: "Dual-chamber silky serum",
      short:
        "Thiamidol, the most clinically studied pigmentation active, in a dual serum that visibly fades dark patches.",
      benefits: [
        "Thiamidol inhibits melanin production at the root — the active behind the Anti-Pigment range",
        "Dual chamber keeps two formulas separate until they meet on your skin",
        "Visible fading of face and hand pigmentation in 4 weeks, continues improving to week 12",
        "Well tolerated, fragrance-free and suitable for all skin tones"
      ],
      ingredients: [
        i("Thiamidol", "Clinically proven to reduce melanin production"),
        i("Hyaluronic acid", "Immediate hydration and plumping"),
        i("Licochalcone A", "Antioxidant that supports skin repair"),
        i("Glycerin", "Keeps the surface comfortable")
      ],
      directions:
        "Press the dispenser to release both chambers together, mix in your palm and apply to the affected areas morning and evening. Use with daily SPF 50 — without it Thiamidol cannot work. Expect 4 weeks for the first visible change and 12 weeks for the full effect.",
      reviews: [
        r("Sandrine B.", "Kibagabaga, Kigali", 5, "May 2025", "The patches on my cheeks that I covered with foundation for years are almost invisible now. It took three months, exactly as promised."),
        r("Claudine A.", "Kigali", 5, "March 2025", "Expensive but it is the only thing that worked on melasma after the pregnancy.")
      ],
      faqs: [
        { q: "How is this different from a lightening cream?", a: "It is not a bleach. Thiamidol reduces excess melanin production specifically in pigmented cells, so it fades patches without lightening the surrounding skin or damaging the barrier." },
        { q: "Can I use it with my other actives?", a: "Yes, but keep it simple: Thiamidol, moisturizer and sunscreen. Adding strong acids on the same night risks irritation, and irritation itself keeps pigment active." }
      ]
    }),
    p({
      id: "eucerin-urearepair-plus-lotion-10",
      photos: ["assets/img/eucerin-urearepair-plus-lotion-10.jpg"],
      name: "UreaRepair Plus Lotion 10% Urea",
      brand: "Eucerin",
      brandId: "eucerin",
      price: 36000,
      tint: "#8aa6c4",
      size: "250 ml",
      form: "pump",
      category: "body-care",
      skinTypes: ["dry", "sensitive", "normal"],
      concerns: ["body-dryness", "dryness"],
      rating: 4.8,
      reviewCount: 118,
      texture: "Light body lotion",
      short:
        "A 10% urea body lotion for very dry, rough and itchy skin — it hydrates and gently smooths at the same time.",
      benefits: [
        "10% urea holds water in the skin and softens rough, bumpy areas",
        "Natural moisturising factors and ceramides rebuild a dry barrier",
        "Relieves itchiness quickly and keeps skin comfortable for 48 hours",
        "Absorbs fast with no greasy film, so you can dress straight after"
      ],
      ingredients: [
        i("Urea 10%", "Deeply hydrating and gently keratolytic"),
        i("Ceramide NP and NMF", "Restore the barrier and lock water in"),
        i("Lactic acid", "Smooths very rough skin"),
        i("Glycerin", "Immediate hydration")
      ],
      directions:
        "Apply daily to the whole body, and immediately after bathing while the skin is still damp. Use on elbows, knees, heels and legs as needed. Avoid broken or cracked skin.",
      reviews: [
        r("Grace I.", "Rwamagana", 5, "March 2025", "The rough bumps on my arms are almost gone after a month. No grease, which I appreciate in this heat."),
        r("Jean-Claude N.", "Musanze", 4.5, "January 2025", "Very dry legs sorted through the dry season. The pump makes it easy to use daily.")
      ]
    }),

    /* ───────────────────────────────────────────────────────────── Cetaphil */
    p({
      id: "cetaphil-gentle-skin-cleanser",
      photos: ["assets/img/cetaphil-gentle-skin-cleanser.jpg"],
      name: "Gentle Skin Cleanser",
      brand: "Cetaphil",
      brandId: "cetaphil",
      price: 24000,
      tint: "#4c7fa6",
      size: "236 ml",
      form: "pump",
      category: "cleansers",
      skinTypes: ["sensitive", "dry", "normal", "combination"],
      concerns: ["sensitivity", "dryness"],
      rating: 4.8,
      reviewCount: 268,
      texture: "Cream, non-foaming",
      short:
        "The fragrance-free classic for reactive skin — gentle enough to use with or without water.",
      benefits: [
        "Removes dirt, oil and light makeup without foaming agents or fragrance",
        "So gentle it can be used with or without water, and on the body too",
        "Ideal when your skin is irritated, after dermatological treatment or in winter",
        "Dermatologist-tested and clinically proven not to strip the barrier"
      ],
      ingredients: [
        i("Glycerin", "Hydrating humectant"),
        i("Cetyl alcohol and stearyl alcohol", "Fatty alcohols that soften, not dry"),
        i("Mild cleansing agents", "Non-soap, non-foaming"),
        i("No fragrance, no paraben", "Formulated for reactive skin")
      ],
      directions:
        "Massage a small amount onto damp skin and wipe off with a soft cloth, or add water and rinse. Use morning and evening. Where skin is very dry, use it without water and tissue it off.",
      reviews: [
        r("Diane K.", "Huye", 5, "February 2025", "It is the only cleanser that has never irritated my skin once. Boring, and that is exactly what I need."),
        r("Grace I.", "Rwamagana", 5, "April 2025", "I use it on my face and my son's skin. Safe, simple, and it lasts a long time.")
      ]
    }),
    p({
      id: "cetaphil-moisturising-lotion",
      photos: ["assets/img/cetaphil-moisturising-lotion.jpg"],
      name: "Moisturising Lotion",
      brand: "Cetaphil",
      brandId: "cetaphil",
      price: 26000,
      tint: "#4c7fa6",
      size: "236 ml",
      form: "pump",
      category: "moisturizers",
      also: ["body-care"],
      skinTypes: ["sensitive", "normal", "dry", "combination"],
      concerns: ["dryness", "sensitivity", "body-dryness"],
      rating: 4.7,
      reviewCount: 194,
      texture: "Light lotion",
      short:
        "A lightweight, fragrance-free daily moisturizer for face and body that is safe for the most sensitive skin.",
      benefits: [
        "Hydrates for 24 hours without fragrance, oils or comedogenic ingredients",
        "Light enough for face, generous enough for the body and hands",
        "Non-greasy finish that sits comfortably under sunscreen in the morning",
        "Suitable for sensitive, reactive and eczema-prone skin at any age"
      ],
      ingredients: [
        i("Glycerin", "Attracts water into the skin"),
        i("Panthenol", "Soothes and conditions"),
        i("Macadamia nut oil", "Emollient softening with no greasy feel"),
        i("Vitamin E", "Antioxidant protection")
      ],
      directions:
        "Apply to clean skin morning and evening, on the face and body. Patch-test on children. Reapply to dry areas like hands and elbows during the day.",
      reviews: [
        r("Nadia S.", "Kimironko, Kigali", 4.5, "March 2025", "A safe everyday lotion for my reactive skin. Not fancy, but it never causes a reaction."),
        r("Eric T.", "Muhanga", 5, "February 2025", "Works on my face and on my dry shins. Two products in one bottle.")
      ]
    }),

    /* ─────────────────────────────────────────────────────────── Dr. Althea */
    p({
      id: "dr-althea-345-relief-cream",
      photos: ["assets/img/dr-althea-345-relief-cream.jpg"],
      name: "345 Relief Cream",
      brand: "Dr. Althea",
      brandId: "dr-althea",
      price: 39000,
      tint: "#b98bb0",
      size: "50 ml",
      form: "jar",
      category: "moisturizers",
      also: ["korean-skincare"],
      collections: ["new-arrivals"],
      skinTypes: ["sensitive", "dry", "combination", "oily"],
      concerns: ["sensitivity", "acne", "post-acne-marks", "dryness"],
      rating: 4.8,
      reviewCount: 76,
      texture: "Gel-cream",
      short:
        "A dermatologist-formulated recovery cream for skin that is red, irritated or healing from breakouts.",
      benefits: [
        "Calms redness and irritation fast with a barrier-repairing complex",
        "Non-comedogenic gel-cream that will not clog acne-prone skin",
        "Speeds up the healing of post-acne marks and general surface damage",
        "Fragrance-free, gentle, and light enough to wear in the day"
      ],
      ingredients: [
        i("Centella asiatica (cica)", "Calms redness and supports repair"),
        i("Panthenol and allantoin", "Soothe and protect compromised skin"),
        i("Ceramide NP", "Restores barrier lipids"),
        i("Hyaluronic acid", "Holds water in the upper layers")
      ],
      directions:
        "Apply an even layer to clean skin morning and evening as your final step. Use it as your recovery cream while you are treating acne, or when a product has irritated your skin.",
      reviews: [
        r("Nadia S.", "Kimironko, Kigali", 5, "May 2025", "My skin was irritated from too many actives and this brought it back in four days. It is my fallback now."),
        r("Aline U.", "Nyarugenge, Kigali", 4.5, "April 2025", "Light enough for daytime and it does not make my T-zone greasy at all.")
      ]
    }),
    p({
      id: "dr-althea-vitamin-c-boosting-serum",
      photos: ["assets/img/dr-althea-vitamin-c-boosting-serum.jpg"],
      name: "Vitamin C Boosting Serum",
      brand: "Dr. Althea",
      brandId: "dr-althea",
      price: 42000,
      tint: "#b98bb0",
      size: "30 ml",
      form: "dropper",
      category: "serums",
      also: ["korean-skincare", "hyperpigmentation"],
      collections: ["new-arrivals"],
      skinTypes: ["normal", "dry", "combination", "oily"],
      concerns: ["dullness", "dark-spots", "hyperpigmentation", "fine-lines"],
      rating: 4.7,
      reviewCount: 58,
      texture: "Light serum",
      short:
        "A stable vitamin C serum that brightens dull skin and defends against the daily damage that causes pigmentation.",
      benefits: [
        "Vitamin C derivative brightens and evens tone without the sting of pure L-ascorbic acid",
        "Antioxidant defence against the sun and pollution damage that dulls skin",
        "Supports collagen for firmer-looking skin over time",
        "Light and stable — it will not oxidise into a dark orange in the bottle"
      ],
      ingredients: [
        i("Ascorbyl derivative", "Stable vitamin C that brightens and protects"),
        i("Niacinamide", "Evens tone and refines pores"),
        i("Adenosine", "Supports skin repair and smoothness"),
        i("Panthenol", "Comforts the skin")
      ],
      directions:
        "Apply two to three drops to clean skin in the morning before moisturizer and sunscreen. If your skin is sensitive, start every other morning for a week. Store away from direct sunlight.",
      reviews: [
        r("Claudine A.", "Kigali", 4.5, "May 2025", "No tingling at all, which is why I can use vitamin C daily for the first time. My skin looks less grey by mid-afternoon."),
        r("Josiane M.", "Huye", 5, "April 2025", "Bright, fresh and it does not smell like hot metal the way some vitamin C serums do.")
      ]
    }),
    /* -- Added from product photography -- */
    p({
      id: "simple-hydrating-light-moisturiser",
      name: "Hydrating Light Moisturiser",
      brand: "Simple",
      brandId: "simple",
      photos: ["assets/img/simple-hydrating-light-moisturiser.jpg"],
      price: 18000,
      size: "125 ml",
      form: "tube",
      tint: "#4ea3d4",
      category: "moisturizers",
      collections: ["new-arrivals", "best-sellers"],
      skinTypes: ["dry", "normal", "sensitive", "combination"],
      concerns: ["dryness", "sensitivity", "dullness"],
      rating: 4.7,
      reviewCount: 88,
      texture: "Light lotion, non-greasy",
      short:
        "A light everyday lotion with pro-vitamin B5 and vitamin E that hydrates for up to 12 hours without a trace of grease, and contains no perfume or colour.",
      benefits: [
        "Hydrates for up to 12 hours without leaving the skin greasy or shiny",
        "Pro-vitamin B5 and vitamin E support the barrier while they moisturise",
        "No perfume, no colourants and no harsh chemicals - kind to reactive skin",
        "Sinks in fast, so it works under sunscreen and makeup without pilling"
      ],
      ingredients: [
        i("Pro-vitamin B5 (panthenol)", "Draws water into the skin and calms tightness"),
        i("Vitamin E", "Antioxidant that supports the barrier"),
        i("Glycerin", "Humectant that keeps the skin comfortable through the day"),
        i("Grape seed oil", "Light emollient that conditions without greasiness")
      ],
      directions:
        "Smooth a small amount over a clean face and neck morning and evening. Apply straight after cleansing while the skin is still slightly damp, then follow with sunscreen in the morning.",
      reviews: [
        r("Sandrine K.", "Kimironko, Kigali", 5, "January 2026", "Light enough to wear under sunscreen in the heat, and my cheeks stopped flaking in the first week."),
        r("Thierry N.", "Musanze", 4.5, "February 2026", "No perfume at all, which is why my skin finally tolerates a moisturiser. Good value for 125 ml.")
      ],
      faqs: [
        { q: "Is it enough on its own for dry skin?", a: "For normal to combination skin, yes. If your skin is very dry, or you are on acids, layer it over a hydrating serum or use the CeraVe Moisturizing Cream at night instead." },
        { q: "Will it clog my pores?", a: "It is non-comedogenic and light enough for daily use on the T-zone. If you are oily all over, apply a thinner layer in the morning." }
      ]
    }),
    p({
      id: "eucerin-sun-oil-control-dry-touch",
      name: "Sun Oil Control Dry Touch SPF 50+",
      brand: "Eucerin",
      brandId: "eucerin",
      photos: ["assets/img/eucerin-sun-oil-control-dry-touch-1.jpg"],
      price: 32000,
      size: "50 ml",
      form: "tube",
      tint: "#2b5ea7",
      category: "sunscreens",
      also: ["acne-care"],
      collections: ["new-arrivals", "best-sellers"],
      skinTypes: ["oily", "combination", "normal"],
      concerns: ["oiliness", "large-pores", "dark-spots", "acne"],
      spf: "SPF 50+",
      rating: 4.8,
      reviewCount: 74,
      texture: "Dry-touch gel-cream",
      short:
        "A high-protection face sunscreen built for oily and blemish-prone skin: SPF 50+ UVA and UVB, with an oil-control finish that stays matte.",
      benefits: [
        "SPF 50+ with UVA protection, for daily use in strong equatorial sun",
        "An oil-control complex keeps shine down for hours after application",
        "Dry-touch finish - no greasy film, so it layers cleanly under makeup",
        "Non-comedogenic and tested on blemish-prone skin"
      ],
      ingredients: [
        i("Oil-control mattifying complex", "Absorbs surface oil and keeps the finish matte"),
        i("Broad-spectrum UV filters", "Block the UVA that drives pigmentation and the UVB that burns"),
        i("Licochalcone A", "Antioxidant that helps defend skin cells from UV stress"),
        i("Glycyrrhetinic acid", "Supports the barrier and calms the look of redness")
      ],
      directions:
        "Apply generously to face and neck every morning as the last step of your routine, about 15 minutes before going outside. Reapply every two hours in strong sun, and after swimming or heavy sweating. Use a separate sunscreen for the body.",
      reviews: [
        r("Chantal M.", "Kacyiru, Kigali", 5, "January 2026", "The only SPF 50+ I have tried that does not leave my forehead shining by mid-morning, and it does not sting my eyes."),
        r("Patrick H.", "Rwamagana", 4.5, "December 2025", "Thick enough to trust, but it dries down matte with no white cast on my skin tone.")
      ],
      faqs: [
        { q: "Will it make my acne worse?", a: "It is non-comedogenic and formulated for oily, blemish-prone skin. If you use acne treatments, apply this after your moisturiser and give each layer a minute to settle." },
        { q: "Do I need it if I stay indoors?", a: "Yes, if you sit near a window or travel by moto. UVA passes through glass, and it is the wavelength that keeps pigmentation from fading." }
      ]
    }),
    p({
      id: "anua-rice-70-ceramide-glow-toner",
      name: "Rice 70 Ceramide Glow Toner",
      brand: "Anua",
      brandId: "anua",
      photos: ["assets/img/anua-rice-70-ceramide-glow-toner.jpg"],
      price: 34000,
      size: "250 ml",
      form: "bottle",
      tint: "#7fa66b",
      category: "toners",
      also: ["korean-skincare", "hyperpigmentation"],
      collections: ["new-arrivals"],
      skinTypes: ["dry", "normal", "combination", "sensitive", "oily"],
      concerns: ["dullness", "dryness", "dark-spots", "hyperpigmentation"],
      rating: 4.8,
      reviewCount: 61,
      texture: "Milky, lightly viscous",
      short:
        "A milky rice-bran toner with 70 percent rice extract and ceramides that layers hydration for a soft, glassy glow without a sticky finish.",
      benefits: [
        "70 percent rice bran extract gently brightens dull, tired-looking skin",
        "Ceramides top up the barrier so the moisture actually stays in",
        "Layers beautifully - pat in two or three rounds for a bouncier finish",
        "Fragrance-free and gentle enough for skin that reacts easily"
      ],
      ingredients: [
        i("Rice bran extract, 70 percent", "Brightens and smooths for a clear, glassy look"),
        i("Ceramides", "Rebuild the barrier lipids that hold water in"),
        i("Niacinamide", "Evens tone and helps refine the look of pores"),
        i("Panthenol", "Calms and softens the skin")
      ],
      directions:
        "After cleansing, pour a few drops into your palms and press over the face, or swipe with a cotton pad. Repeat two or three times for a deeper layer of hydration. Follow with serum and moisturiser, morning and evening.",
      reviews: [
        r("Aline M.", "Gikondo, Kigali", 5, "February 2026", "My skin looks lit from within and it never feels sticky. Cheaper per use than the serums I was buying."),
        r("Divine I.", "Rusizi", 4.5, "January 2026", "Layered three times it fixed the tightness I get from acids, and the bottle lasts a long time.")
      ],
      faqs: [
        { q: "Is this an exfoliating toner?", a: "No. It is a hydrating, brightening toner with no acids, so it is safe morning and evening and alongside any active you already use." },
        { q: "Where does it go in my routine?", a: "Straight after cleansing, before serum. If you use an exfoliating toner, use that first and then follow with this to put the water back." }
      ]
    }),
    p({
      id: "good-molecules-discoloration-correcting-serum",
      name: "Discoloration Correcting Serum",
      brand: "Good Molecules",
      brandId: "good-molecules",
      photos: ["assets/img/good-molecules-discoloration-correcting-serum.jpg"],
      price: 28000,
      size: "30 ml",
      form: "dropper",
      tint: "#3d6b8e",
      category: "serums",
      also: ["hyperpigmentation"],
      collections: ["new-arrivals", "best-sellers"],
      skinTypes: ["normal", "combination", "oily", "dry"],
      concerns: ["dark-spots", "hyperpigmentation", "post-acne-marks", "dullness"],
      rating: 4.7,
      reviewCount: 93,
      texture: "Light, fast-absorbing serum",
      short:
        "A brightening serum with tranexamic acid and niacinamide that targets dark spots, post-acne marks and uneven tone without the irritation of stronger lighteners.",
      benefits: [
        "Tranexamic acid helps interrupt the pigment production that keeps marks from fading",
        "Niacinamide evens overall tone and supports the barrier at the same time",
        "Light enough to layer under sunscreen every morning",
        "A gentler route than hydroquinone, so it suits long-term daily use"
      ],
      ingredients: [
        i("Tranexamic acid", "Targets stubborn pigmentation and post-acne marks"),
        i("Niacinamide", "Evens tone, reduces redness and refines pores"),
        i("Hyaluronic acid", "Keeps the serum hydrating rather than drying"),
        i("Licorice root extract", "Calms the skin while it brightens")
      ],
      directions:
        "Apply three to four drops to clean skin morning and evening, before moisturiser. Follow with sunscreen every morning - no brightening serum works without daily SPF. Expect visible change over eight to twelve weeks, not days.",
      reviews: [
        r("Josiane B.", "Nyarugenge, Kigali", 5, "February 2026", "Three months in and the marks from last year have faded. No stinging, unlike the stronger serums I tried."),
        r("Emmanuel K.", "Kabuga", 4, "January 2026", "Slow but real. It took eight weeks before I could see the difference in photos, and it stacks well with my sunscreen.")
      ],
      faqs: [
        { q: "How long before I see a difference?", a: "Pigmentation fades on its own timetable - roughly eight to twelve weeks of daily use. Take a photo in daylight every four weeks so you can see the change, because it is hard to notice day to day." },
        { q: "Can I use it with vitamin C or retinol?", a: "Yes with vitamin C, which pairs well in the morning. If you use retinol at night, apply retinol first, wait a few minutes, then this. Introduce one new active at a time." }
      ]
    }),
    p({
      id: "lrp-toleriane-double-repair",
      photos: ["assets/img/la-roche-posay-toleriane-double-repair.jpg"],
      name: "Toleriane Double Repair Face Moisturizer",
      brand: "La Roche-Posay",
      brandId: "la-roche-posay",
      price: 43000,
      tint: "#1f6fb2",
      size: "75 ml",
      form: "tube",
      category: "moisturizers",
      skinTypes: ["dry", "normal", "sensitive", "combination"],
      concerns: ["dryness", "sensitivity", "dullness"],
      rating: 4.7,
      reviewCount: 132,
      texture: "Light cream",
      short:
        "Ceramide-3 and niacinamide in one tube: barrier repair morning and night, in the size that survives using it on your neck as well.",
      benefits: [
        "Ceramide-3 replaces the lipid that dry and over-cleansed skin runs out of first",
        "Niacinamide at a comfortable strength strengthens the barrier and evens tone over weeks",
        "Prebiotic thermal water supports the microbiome, which is what keeps sensitivity from returning",
        "Absorbs in under a minute, so it works under sunscreen without pilling"
      ],
      ingredients: [
        i("Ceramide-3", "Rebuilds the lipid barrier that holds water in"),
        i("Niacinamide", "Strengthens the barrier and slowly evens out tone"),
        i("Prebiotic thermal water", "Feeds the skin microbiome"),
        i("Glycerin", "Pulls water into the upper layers and keeps it there")
      ],
      directions:
        "Apply to clean skin morning and evening, on the face, neck and the back of the hands if they are dry. Use it on slightly damp skin for the best seal, and follow with sunscreen in the morning.",
      reviews: [
        r("Clarisse U.", "Nyarutarama, Kigali", 5, "February 2026", "One tube lasts me about two months and my cheeks stopped flaking in the dry season. It never pills under my SPF."),
        r("Jean-Paul H.", "Musanze", 4, "December 2025", "Good for the whole face and cheap enough per millilitre to use on my neck. It is not a rich cream, so in the cold season I layer it twice.")
      ],
      faqs: [
        { q: "Is this the same as the Dermallergo cream?", a: "No. Dermallergo is the minimalist option for skin that reacts to everything. Double Repair adds ceramide-3 and niacinamide, so it does more for dryness and uneven tone, but it is the more likely of the two to be felt by very reactive skin." },
        { q: "Will 75 ml last?", a: "At two applications a day on the face only, roughly two to three months. Most people use it on the neck as well, which brings it closer to two." }
      ]
    })
  ];

  /* ── Products and prices the shop owner added ─────────────────────────
     assets/js/products-own.js carries what tools/product-editor.html wrote:
     SHR.OWN_PRODUCTS for the products, and SHR.OWN_BRANDS for a brand that is
     not in site-data.js yet. An entry whose id matches a product above
     REPLACES it - that is how the price of an existing product is changed
     without editing this file - and an id that matches nothing is appended. */
  SHR.BASE_PRODUCTS = catalogue.slice();
  SHR.BASE_BRANDS = (SHR.BRANDS || []).slice();

  var ownBrands = SHR.OWN_BRANDS || [];
  for (var b = 0; b < ownBrands.length; b++) {
    var brand = ownBrands[b];
    if (!brand || !brand.id || !SHR.BRANDS) continue;
    var known = false;
    for (var k = 0; k < SHR.BRANDS.length; k++) {
      if (SHR.BRANDS[k].id === brand.id) known = true;
    }
    if (!known) SHR.BRANDS.push(brand);
  }

  var own = SHR.OWN_PRODUCTS || [];
  for (var n = 0; n < own.length; n++) {
    var entry = p(own[n]);
    if (!entry.id) continue;
    var at = -1;
    for (var j = 0; j < catalogue.length; j++) {
      if (catalogue[j].id === entry.id) { at = j; break; }
    }
    if (at >= 0) catalogue[at] = entry;
    else catalogue.push(entry);
  }

  /* ── What is actually on the shelf ─────────────────────────────────────
     assets/js/stock-own.js carries what tools/stock-manager.html wrote:
     SHR.OWN_STOCK, a map of product id to { status, units }. It is applied
     last, to whatever the shop has - the hand-written catalogue and the
     products added in products-own.js alike - so one stock screen covers
     everything. An id that no product matches is skipped here; the catalogue
     test reports it, because it means a typo or a product that has gone. */
  var ledger = SHR.OWN_STOCK || {};
  for (var key in ledger) {
    if (!Object.prototype.hasOwnProperty.call(ledger, key)) continue;
    var ledgerAt = -1;
    for (var m = 0; m < catalogue.length; m++) {
      if (catalogue[m].id === key) { ledgerAt = m; break; }
    }
    if (ledgerAt < 0) continue;
    var onShelf = catalogue[ledgerAt];
    var ledgerEntry = ledger[key] || {};
    if (SHR.STOCK && SHR.STOCK.statuses.indexOf(ledgerEntry.status) >= 0) onShelf.stock = ledgerEntry.status;
    if (typeof ledgerEntry.units === "number" && isFinite(ledgerEntry.units)) {
      onShelf.units = Math.max(0, Math.round(ledgerEntry.units));
      if (SHR.STOCK) SHR.STOCK.apply(onShelf);
    }
  }

  /* The shop's one discount rule, applied to every product: the ones written
     above and the ones added later. See SHR.PRICING in site-data.js. */
  SHR.PRODUCTS = SHR.PRICING.applyAll(catalogue);
})();
