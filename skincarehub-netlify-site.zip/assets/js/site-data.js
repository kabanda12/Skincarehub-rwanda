/* ==========================================================================
   Skincare Hub Rwanda — Site data
   Loaded first, before catalog.js, app.js and pages.js.
   Plain classic script (no ES modules) so the site also works from file://
   ========================================================================== */
window.SHR = window.SHR || {};

/* ───────────────────────────────────────────────────────────── Business */
SHR.CONFIG = {
  name: "Skincare Hub Rwanda",
  shortName: "Skincare Hub",
  tagline: "Authentic Skincare. Healthy, Radiant Skin.",
  whatsapp: "+250787851681",
  whatsappDisplay: "+250 787 851 681",
  /* The address and the opening hours below are the owner's own and were
     confirmed by them. The inbox is the owner's too: skincarehubrwanda12@gmail.com,
     supplied by them directly - a mailbox the business can actually read. */
  email: "skincarehubrwanda12@gmail.com",
  address: {
    line1: "Unify House, KN 2 St",
    city: "Kigali",
    country: "Rwanda",
    full: "Unify House, KN 2 St, Kigali, Rwanda",
    mapQuery: "Unify House, KN 2 St, Kigali, Rwanda"
  },
  currency: "RWF",
  delivery: {
    freeFrom: 50000,
    kigaliFee: 2000,
    upcountryFee: 3500,
    kigaliEta: "Same day to 24 hours",
    upcountryEta: "2 to 4 working days",
    note:
      "We deliver to all 30 districts of Rwanda. Kigali orders placed before 2pm are usually delivered the same day."
  },
  /* One row per run of days that keeps the same hours, Monday–Saturday then
     Sunday. `from`/`to` are [weekday, hour] with weekday 0 = Sunday, and the
     day window is inclusive on both ends. */
  hours: [
    { day: "Monday – Saturday", time: "9:00 – 21:00", from: [1, 9], to: [6, 21] },
    { day: "Sunday", time: "11:00 – 18:00", from: [0, 11], to: [0, 18] },
    { day: "WhatsApp support", time: "During opening hours" },
    { day: "Online orders", time: "24 hours, 7 days" }
  ],
  socials: [
    { label: "Instagram", href: "https://instagram.com/" },
    { label: "Facebook", href: "https://facebook.com/" },
    { label: "TikTok", href: "https://tiktok.com/" }
  ],
  /* ── Honest placeholders: fill these in before going live ───────────────
     gaMeasurementId : Google Analytics 4 id, e.g. "G-XXXXXXXXXX"
     gscVerification : the content value of your Google Search Console meta tag
     formsEndpoint   : optional POST endpoint (Formspree, Netlify, Getform…).
                       Left empty the forms fall back to WhatsApp / e-mail.
     -------------------------------------------------------------------- */
  analytics: {
    gaMeasurementId: "",
    gscVerification: "",
    formsEndpoint: ""
  },
  /* ── Taking money online ────────────────────────────────────────────────
     Left as it ships, the checkout records the order and confirms it with
     the customer before any money moves. To capture card and mobile-money
     payments on the site itself, open a Flutterwave account (cards + MTN
     MoMo + Airtel Money, settling in RWF), paste your PUBLISHABLE key below
     and set provider to "flutterwave".

     A publishable key is designed to sit in client-side code. The SECRET key
     must never appear in this file: confirming that the amount paid matches
     the order needs the secret key and therefore runs on a server — see
     tools/payments/verify-payment.example.js.

     momoPayCode    : your MTN MoMoPay merchant code (5–7 digits), so a
                      customer can pay from their own wallet without a card.
     verifyEndpoint : optional https URL that confirms the amount server-side
                      (leave empty and every payment is marked "pending
                      verification" until you check it in the provider's
                      dashboard).
     -------------------------------------------------------------------- */
  payments: {
    provider: "",            // "" (confirm first, as today) | "flutterwave"
    publicKey: "",           // FLWPUBK-… publishable key only
    testMode: false,         // true while you are on Flutterwave test keys
    verifyEndpoint: "",      // optional https endpoint, see tools/payments
    checkoutScript: "https://checkout.flutterwave.com/v3.js",
    momoPayCode: "",         // e.g. "123456" → customers dial *182*8*1*123456*amount#
    momoPayName: "Skincare Hub Rwanda",
    description: "Authentic skincare, delivered across Rwanda",
    logo: "assets/img/app-icon-512.png",
    sessionMinutes: 30,
    maxRetries: 3
  },
  promos: {
    GLOW10: { type: "percent", value: 10, label: "GLOW10 — 10% off your order" },
    FIRSTGLOW: { type: "fixed", value: 3000, label: "FIRSTGLOW — 3,000 RWF off" },
    KOREAN15: { type: "percent", value: 15, label: "KOREAN15 — 15% off Korean skincare" }
  },

  /* ── What this site is allowed to claim ────────────────────────────────
     The two switches that decide whether the site states something as fact.
     They are here rather than buried in the markup so that turning a claim on
     is a deliberate act.

     reviewsVerified     : true ONLY once every star rating, review count and
                           customer quote on the site came from a real customer
                           who agreed to it being published. While it is false
                           no rating, count or testimonial is displayed, and the
                           site says plainly that reviews are coming instead.
     freeDeliveryActive  : the free-delivery announcement and the cart's
                           "add X more" bar only appear while this is true. Set
                           it false (and delivery.freeFrom to 0) the moment the
                           policy changes, so no customer sees a promise the
                           shop is not keeping.
     -------------------------------------------------------------------- */
  claims: {
    reviewsVerified: false,
    freeDeliveryActive: true
  }
};

/* ─────────────────────────────────────────────────────────────── Pricing */
/* The shop's discount rule, in one place.

   Every product is sold at one uniform discount: `price` is what the customer
   pays, `was` is the list price it is compared against, and `was` is DERIVED
   from `price` rather than typed in by hand. catalog.js runs every product
   through applyAll() on load, so a discount of any other size cannot reach the
   site - not from the catalogue, and not from a product added with
   tools/product-editor.html.

   Change discountPercent and the whole shop follows: the list price, the
   "Save" amount and the wording of the sale badge. Nothing else needs
   editing, and no file stores a list price you have to keep in step by hand.

   The list price is rounded DOWN to the nearest roundTo (100 RWF) so the real
   discount can never come out ABOVE the stated percentage: rounding up would
   quietly sell at 10.4% off while the badge said 10%. */
SHR.PRICING = {
  discountPercent: 10,
  roundTo: 100,
  label: "10% off",

  /* The list price shown next to a price of `price`. */
  compareAt: function (price) {
    var pay = Math.round(Number(price) || 0);
    if (pay <= 0) return 0;
    var step = SHR.PRICING.roundTo || 1;
    var list = Math.floor(pay / (1 - SHR.PRICING.discountPercent / 100) / step) * step;
    return Math.max(pay + step, list);
  },

  /* What one unit saves, in RWF. */
  saving: function (item) {
    if (!item) return 0;
    return Math.max(0, (Number(item.was) || 0) - (Number(item.price) || 0));
  },

  /* The discount as a percentage of the list price, to one decimal place. A
     rounded-down list price lands just under the rate for a price that does
     not divide evenly - 9.97% on a 28,000 RWF product - which is why the
     badge shows the rule and not a recomputation of it. */
  percentOff: function (item) {
    var list = item ? Number(item.was) || 0 : 0;
    if (list <= 0) return 0;
    return Math.round(((list - (Number(item.price) || 0)) / list) * 1000) / 10;
  },

  /* Put one product on the rule, discarding any list price it carried. */
  apply: function (item) {
    if (item) item.was = SHR.PRICING.compareAt(item.price);
    return item;
  },

  /* And the whole catalogue. */
  applyAll: function (list) {
    var items = list || [];
    for (var n = 0; n < items.length; n++) SHR.PRICING.apply(items[n]);
    return items;
  }
};

/* ───────────────────────────────────────────────────────────────── Stock */
/* How much of each product is on the shelf, in one place.

   Every product carries `stock`, one of three states: "in-stock", "low" or
   "out". It is what the shop filters on, what the quiz scores against, what
   disables the Add to cart button and what the product page reports to Google
   as schema.org availability - so getting it right here is the whole job.

   A product may also carry `units`, the number actually on the shelf, and then
   the status is DERIVED from the units rather than typed in: counting stock is
   one number, and the state follows from it. `units` is null when nobody has
   counted, and the hand-written status stands.

   The counts themselves live in assets/js/stock-own.js (SHR.OWN_STOCK), which
   tools/stock-manager.html writes; catalog.js applies them to every product on
   load, whoever added it and whatever catalogue it came from. */
SHR.STOCK = {
  /* At or below this many units a product is shown as low stock. */
  lowAt: 5,

  /* The three states, in the order a shop thinks about them. */
  statuses: ["in-stock", "low", "out"],

  /* The status a number of units implies. Anything that is not a real number
     means "not counted", and the caller keeps the status it already had. */
  statusFor: function (units) {
    var n = Number(units);
    if (units === null || units === undefined || !isFinite(n)) return "";
    if (n <= 0) return "out";
    if (n <= SHR.STOCK.lowAt) return "low";
    return "in-stock";
  },

  /* Availability in words and in a class name, as the cards, the quick view and
     the product page show it. Counted units make the low-stock line specific:
     "Only 3 left" sells better than "Low stock". */
  label: function (item) {
    var p = item || {};
    var units = typeof p.units === "number" ? p.units : null;
    if (p.stock === "out") return { text: "Out of stock", cls: "pcard__stock--out" };
    if (p.stock === "low") {
      return {
        text: units !== null && units > 0 ? "Only " + units + " left — order soon" : "Low stock — order soon",
        cls: "pcard__stock--low"
      };
    }
    return { text: "In stock", cls: "pcard__stock--in" };
  },

  /* Put a product's units on the product and let them set the status. */
  apply: function (item) {
    if (!item) return item;
    var derived = SHR.STOCK.statusFor(item.units);
    if (derived) item.stock = derived;
    return item;
  }
};

/* ────────────────────────────────────────────────────────── Categories */
SHR.CATEGORIES = [
  {
    id: "cleansers",
    name: "Cleansers",
    blurb: "Gentle daily face washes and micellar waters",
    kind: "type"
  },
  { id: "moisturizers", name: "Moisturizers", blurb: "Creams, balms and lotions that restore the barrier", kind: "type" },
  { id: "sunscreens", name: "Sunscreens", blurb: "Daily SPF 50+ protection — no white cast", kind: "type" },
  { id: "serums", name: "Serums", blurb: "Targeted actives: niacinamide, vitamin C, snail mucin", kind: "type" },
  { id: "toners", name: "Toners", blurb: "Hydrating and exfoliating toners for every skin type", kind: "type" },
  { id: "body-care", name: "Body Care", blurb: "Body lotions, balms and hand care", kind: "type" },
  { id: "acne-care", name: "Acne Care", blurb: "Breakout control without stripping your skin", kind: "type" },
  { id: "hyperpigmentation", name: "Hyperpigmentation", blurb: "Dark spots, post-acne marks and uneven tone", kind: "type" },
  { id: "korean-skincare", name: "Korean Skincare", blurb: "Glass-skin essentials from Seoul's best-loved brands", kind: "type" },
  { id: "new-arrivals", name: "New Arrivals", blurb: "Freshly landed products in Kigali", kind: "collection" },
  { id: "best-sellers", name: "Best Sellers", blurb: "What Rwanda is buying again and again", kind: "collection" }
];

/* ────────────────────────────────────────────────────────────── Brands */
/* `logo` is set only on a brand whose real logo was fetched and then looked at,
   from the pinned sources in tools\fetch-brand-logos.ps1. Every other brand
   keeps its initials monogram, which is what the cards showed before any of
   this existed - a wrong logo is worse than none. Adding one is a file in
   assets\img\brands plus a `logo` line here. */
SHR.BRANDS = [
  {
    id: "cerave",
    name: "CeraVe",
    country: "USA",
    logo: "assets/img/brands/cerave.png",
    note: "Developed with dermatologists, built on ceramides and MVE delivery technology."
  },
  { id: "la-roche-posay", name: "La Roche-Posay", country: "France", logo: "assets/img/brands/la-roche-posay.png", note: "Skin sensitive to everything? This is where dermatologists send you." },
  { id: "the-ordinary", name: "The Ordinary", country: "Canada", logo: "assets/img/brands/the-ordinary.jpg", note: "Single-ingredient actives at honest prices, no false promises." },
  { id: "anua", name: "Anua", country: "South Korea", logo: "assets/img/brands/anua.jpg", note: "Heartleaf-forward calming skincare for reactive, acne-prone skin." },
  { id: "bioderma", name: "Bioderma", country: "France", logo: "assets/img/brands/bioderma.png", note: "Micellar water pioneers and barrier-repair specialists." },
  { id: "cosrx", name: "COSRX", country: "South Korea", logo: "assets/img/brands/cosrx.jpg", note: "K-beauty cult essentials — snail mucin and low-pH cleansing." },
  { id: "beauty-of-joseon", name: "Beauty of Joseon", country: "South Korea", logo: "assets/img/brands/beauty-of-joseon.jpg", note: "Heritage ingredients, elegant textures, the famous Relief Sun." },
  { id: "eucerin", name: "Eucerin", country: "Germany", logo: "assets/img/brands/eucerin.png", note: "Clinically proven actives for pigmentation and very dry skin." },
  { id: "cetaphil", name: "Cetaphil", country: "USA", logo: "assets/img/brands/cetaphil.jpg", note: "The gentle, fragrance-free starting point for sensitive skin." },
  { id: "dr-althea", name: "Dr. Althea", country: "South Korea", logo: "assets/img/brands/dr-althea.jpg", note: "Dermatologist-led K-beauty for barrier repair and brightening." },
  { id: "simple", name: "Simple", country: "United Kingdom", logo: "assets/img/brands/simple.jpg", note: "No perfume, no colourants and no harsh chemicals - the gentlest starting point for reactive skin." },
  { id: "good-molecules", name: "Good Molecules", country: "USA", logo: "assets/img/brands/good-molecules.png", note: "Straightforward, well-priced actives for uneven tone and texture." }
];

/* ────────────────────────────────────────────────────────── Skin profile */
SHR.SKIN_TYPES = [
  { id: "dry", label: "Dry", meta: "Tight, flaky, rarely shiny" },
  { id: "oily", label: "Oily", meta: "Shiny by midday, visible pores" },
  { id: "combination", label: "Combination", meta: "Oily T-zone, dry cheeks" },
  { id: "normal", label: "Normal", meta: "Comfortable and balanced" },
  { id: "sensitive", label: "Sensitive", meta: "Reacts, stings or flushes easily" }
];

SHR.CONCERNS = [
  { id: "acne", label: "Acne & breakouts", group: "Blemishes" },
  { id: "post-acne-marks", label: "Post-acne marks", group: "Blemishes" },
  { id: "dark-spots", label: "Dark spots", group: "Pigmentation" },
  { id: "hyperpigmentation", label: "Uneven tone", group: "Pigmentation" },
  { id: "dryness", label: "Dryness & dehydration", group: "Barrier" },
  { id: "sensitivity", label: "Sensitivity & redness", group: "Barrier" },
  { id: "oiliness", label: "Oiliness & shine", group: "Balance" },
  { id: "large-pores", label: "Blackheads & pores", group: "Balance" },
  { id: "dullness", label: "Dullness & no glow", group: "Radiance" },
  { id: "fine-lines", label: "First fine lines", group: "Radiance" },
  { id: "body-dryness", label: "Dry body skin", group: "Body" }
];

/* ────────────────────────────────────────── Shop by concern (home page) */
/* The eight cards in the "What are you looking to improve?" section, and the
   checkboxes in the shop's concern filter. Every card points at a filter that
   exists, so a card can never lead to an empty shelf. `values` is the OR of
   the concern ids it covers — "Skin barrier", for example, is the dry and the
   sensitive products together, which is what a customer means by it.
   `photo` is a real photograph, fetched once by tools\fetch-concern-photos.ps1
   and stored in this project rather than hotlinked, so the card still works
   from file:// with no network. It sits at assets/img/concerns/<id>.jpg, named
   for the facet it belongs to; a facet without one keeps the generated art. */
SHR.CONCERN_FACETS = [
  { id: "acne", label: "Acne", values: ["acne"], tint: "#1f6fb2", pattern: "arcs", photo: "assets/img/concerns/acne.jpg", note: "Breakouts, blackheads and congestion" },
  { id: "dark-spots", label: "Dark spots", values: ["dark-spots", "post-acne-marks"], tint: "#c6a664", pattern: "rings", photo: "assets/img/concerns/dark-spots.jpg", note: "Marks left behind by spots and sun" },
  { id: "dryness", label: "Dry skin", values: ["dryness", "body-dryness"], tint: "#8aa6c4", pattern: "waves", photo: "assets/img/concerns/dryness.jpg", note: "Tightness, flaking and dehydration" },
  { id: "oiliness", label: "Oily skin", values: ["oiliness", "large-pores"], tint: "#4e7c4a", pattern: "dots", photo: "assets/img/concerns/oiliness.jpg", note: "Shine, visible pores and midday grease" },
  { id: "sensitivity", label: "Sensitive skin", values: ["sensitivity"], tint: "#b98bb0", pattern: "blob", photo: "assets/img/concerns/sensitivity.jpg", note: "Redness, stinging and reactivity" },
  { id: "dullness", label: "Dull skin", values: ["dullness", "fine-lines"], tint: "#c99a5e", pattern: "grid", photo: "assets/img/concerns/dullness.jpg", note: "No glow, uneven texture and first fine lines" },
  { id: "skin-barrier", label: "Skin barrier", values: ["dryness", "sensitivity"], tint: "#1f8a8a", pattern: "stripes", photo: "assets/img/concerns/skin-barrier.jpg", note: "Repair after over-treating your skin" },
  { id: "sunscreen", label: "Sunscreen", values: [], category: "sunscreens", tint: "#2e6fa8", pattern: "arcs", photo: "assets/img/concerns/sunscreen.jpg", note: "Daily SPF 50+ for Rwandan sun" }
];

/* ─────────────────────────────────────────────── Shop category filter */
/* The category checkboxes in the shop, in the order the brief lists them.
   "Treatments" is the two treatment shelves together, which is what a customer
   means by the word — acne care and hyperpigmentation. A facet is a view of the
   catalogue, never a new shelf: every category here exists in SHR.CATEGORIES. */
SHR.CATEGORY_FACETS = [
  { id: "cleansers", label: "Cleansers", categories: ["cleansers"] },
  { id: "toners", label: "Toners", categories: ["toners"] },
  { id: "serums", label: "Serums", categories: ["serums"] },
  { id: "moisturizers", label: "Moisturizers", categories: ["moisturizers"] },
  { id: "sunscreens", label: "Sunscreens", categories: ["sunscreens"] },
  { id: "treatments", label: "Treatments", categories: ["acne-care", "hyperpigmentation"] },
  { id: "body-care", label: "Body Care", categories: ["body-care"] },
  { id: "korean-skincare", label: "Korean Skincare", categories: ["korean-skincare"] },
  { id: "new-arrivals", label: "New Arrivals", categories: ["new-arrivals"] },
  { id: "best-sellers", label: "Best Sellers", categories: ["best-sellers"] }
];

/* ──────────────────────────────────────────────────────────── Payments */
/* kind    : "online" pays inside the checkout (needs a provider key),
             "manual" is confirmed with the customer first, as today.
   channel : the provider's payment option, used when kind is "online". */
SHR.PAYMENTS = [
  { id: "card", label: "Visa / Mastercard", meta: "Secure 3-D Secure card payment", icon: "card", kind: "online", channel: "card" },
  { id: "mtn-momo", label: "MTN Mobile Money", meta: "Approve the request on your phone", icon: "phone", kind: "online", channel: "mobilemoneyrwanda" },
  { id: "airtel-money", label: "Airtel Money", meta: "Approve the request on your phone", icon: "phone", kind: "online", channel: "mobilemoneyrwanda" },
  { id: "momo-pay", label: "MTN MoMoPay code", meta: "Pay from your own MoMo wallet — no card needed", icon: "phone", kind: "manual" },
  { id: "cod", label: "Cash on delivery", meta: "Kigali only — pay the rider", icon: "cash", kind: "manual" }
];

SHR.SHIPPING_OPTIONS = [
  {
    id: "kigali",
    label: "Kigali delivery",
    meta: "Same day to 24 hours",
    fee: 2000
  },
  {
    id: "upcountry",
    label: "Upcountry delivery",
    meta: "2 to 4 working days",
    fee: 3500
  },
  {
    id: "pickup",
    label: "Pick up at our shop",
    meta: "Unify House, KN 2 St — free",
    fee: 0
  }
];

/* ──────────────────────────────────────────── Why choose us + promise */
SHR.WHY_US = [
  {
    icon: "shield",
    title: "Authentic Products",
    text:
      "Every item arrives sealed, with the batch code and expiry date intact and checked by our team on arrival. Ask us and we will send you a photograph of the batch code on the exact unit you are buying. We do not sell testers, refills or grey-market stock."
  },
  {
    icon: "sparkle",
    title: "Personalized Recommendations",
    text:
      "Free skin quiz and human consultation. Tell us your skin type and concerns and we build a routine around your skin — not around what we want to sell."
  },
  {
    icon: "globe",
    title: "Premium International Brands",
    text:
      "CeraVe, La Roche-Posay, The Ordinary, Anua, COSRX, Beauty of Joseon, Bioderma, Eucerin, Cetaphil and Dr. Althea — the formulas dermatologists actually recommend."
  },
  {
    icon: "truck",
    title: "Fast Delivery Across Rwanda",
    text:
      "Same-day delivery in Kigali for orders placed before 2pm, and 2 to 4 working days to every other district. Free over 50,000 RWF."
  },
  {
    icon: "chat",
    title: "Trusted Customer Support",
    text:
      "Real people on WhatsApp through opening hours — 9:00 to 21:00 Monday to Saturday, 11:00 to 18:00 on Sunday — who will read your routine, answer questions and follow up after you buy."
  },
  {
    icon: "lock",
    title: "Safe Shopping Experience",
    text:
      "SSL-secured checkout, mobile money or card payment, and a 7-day return promise on unopened products. Your data stays yours."
  }
];

SHR.PROMISES = [
  { icon: "shield", title: "Authenticity guaranteed", meta: "Sealed, batch-coded, source-verified" },
  { icon: "truck", title: "Free delivery over 50,000 RWF", meta: "Across all 30 districts" },
  { icon: "chat", title: "Free routine advice", meta: "WhatsApp support 7 days a week" },
  { icon: "return", title: "7-day easy returns", meta: "On unopened products" }
];

/* ──────────────────────────────────────────────────────────────── FAQ */
SHR.FAQS = [
  {
    id: "authentic",
    category: "Products",
    q: "Are your products authentic?",
    a:
      "Yes. Every product arrives sealed with an intact batch code and expiry date, and our team checks each shipment on arrival. Ask us and we will send you a photo of the batch code on the exact unit you are buying before you pay. We do not sell testers, decanted refills or grey-market stock."
  },
  {
    id: "delivery",
    category: "Delivery",
    q: "How long does delivery take?",
    a:
      "Orders inside Kigali placed before 2pm are usually delivered the same day, and always within 24 hours. Every other district in Rwanda takes 2 to 4 working days. Delivery is 2,000 RWF in Kigali and 3,500 RWF upcountry, and it is free on orders above 50,000 RWF. You can also collect free of charge at our shop, Unify House, KN 2 St, in Kigali."
  },
  {
    id: "acne",
    category: "Skin advice",
    q: "Which products are suitable for acne?",
    a:
      "For active breakouts we usually start with a gentle cleanser (CeraVe Foaming Facial Cleanser or COSRX Low pH Good Morning Gel Cleanser), a non-comedogenic moisturizer, and one targeted active — The Ordinary Niacinamide 10% + Zinc 1%, salicylic acid, or Adapalene-style acne care. Anua's Heartleaf line calms redness while you treat. Never stack three strong actives at once: start with one, use it for four weeks, then reassess."
  },
  {
    id: "recommendations",
    category: "Skin advice",
    q: "Can I receive personalized recommendations?",
    a:
      "Yes, and it is free. Take the two-minute Skin Quiz for an instant routine, or send us your details and photos through the Personalized Consultation form and a skincare advisor will reply on WhatsApp with a written routine, product order and a budget that fits. We answer every consultation within one working day."
  },
  {
    id: "sunscreen",
    category: "Skin advice",
    q: "Which sunscreen is best for my skin?",
    a:
      "Rwanda sits close to the equator, so daily SPF 50 is not optional — it is the single most effective thing you can do for dark spots. Oily or acne-prone: La Roche-Posay Anthelios UVMune 400, a light fluid with no white cast. Dry or sensitive: Beauty of Joseon Relief Sun Rice + Probiotics, which feels like a moisturizer. Normal to combination: Bioderma Photoderm Aquafluide. Reapply every two hours outdoors."
  },
  {
    id: "payment",
    category: "Orders",
    q: "What payment methods do you accept?",
    a:
      "MTN Mobile Money, Airtel Money, Visa and Mastercard, and cash on delivery inside Kigali. You can also confirm your order on WhatsApp and pay by MoMo once our agent has confirmed stock. Every card payment runs over an SSL-secured, 3-D Secure connection."
  },
  {
    id: "returns",
    category: "Orders",
    q: "What is your return policy?",
    a:
      "Unopened products in their original sealed packaging can be returned within 7 days of delivery for a refund or exchange. If a product arrives damaged, expired or not what you ordered, tell us within 48 hours with a photo and we replace it at our cost — no argument. For hygiene reasons we cannot accept opened skincare unless it is faulty."
  },
  {
    id: "expiry",
    category: "Products",
    q: "How do I know the products are not expired?",
    a:
      "Every unit we ship has at least 12 months of shelf life remaining, and most have far more. The manufacturing and expiry dates are printed on the carton and the bottle. Period-after-opening (12M, 6M) is printed on the label — we include a note with your order telling you when to replace what."
  },
  {
    id: "skin-type",
    category: "Skin advice",
    q: "I do not know my skin type. Can you help?",
    a:
      "Take the Skin Quiz — it takes two minutes and gives you a full routine. In short: if your face feels tight and flaky after cleansing you are dry; if it is shiny all over within two hours you are oily; a shiny T-zone with dry cheeks is combination; and if your skin stings, flushes or breaks out easily you are sensitive. Combination and sensitive skin are the two most common answers we get in Rwanda."
  },
  {
    id: "men",
    category: "Skin advice",
    q: "Are these products suitable for men?",
    a:
      "Yes. Skin is skin — none of our products are gendered. Men often tell us they prefer the lighter textures: CeraVe Foaming Facial Cleanser, The Ordinary Niacinamide for shine and post-shaving marks, and the Anthelios UVMune 400 fluid sunscreen which disappears on contact."
  },
  {
    id: "whatsapp-order",
    category: "Orders",
    q: "Can I order on WhatsApp?",
    a:
      "Absolutely. Tap the green WhatsApp button anywhere on this site, tell us the products you want and your district, and we will confirm stock, total and delivery time. You can pay by MTN Mobile Money or Airtel Money straight from the chat."
  },
  {
    id: "shop",
    category: "Orders",
    q: "Do you have a physical shop?",
    a:
      "Yes — you can visit us at Unify House, KN 2 St in Kigali, and test textures before you buy. We are open Monday to Saturday 9:00–21:00 and Sunday 11:00–18:00. Call or WhatsApp ahead if you want a specific product held for you."
  }
];

/* Shared product-page questions appended to every product */
SHR.PRODUCT_FAQS = [
  {
    q: "Is this product authentic?",
    a:
      "Yes. It arrives sealed, and the batch code and expiry date are checked by our team before dispatch. Ask us and we will send you a photo of the batch code on your exact unit."
  },
  {
    q: "How long will delivery take?",
    a:
      "Same day to 24 hours inside Kigali for orders placed before 2pm, and 2 to 4 working days for the rest of Rwanda. Free over 50,000 RWF, otherwise 2,000 RWF in Kigali and 3,500 RWF upcountry."
  },
  {
    q: "Can I use it with the rest of my routine?",
    a:
      "Tell us what you already use on WhatsApp and we will check it for you before you buy — free of charge. In general, introduce one new active at a time, use it for two weeks, and patch-test behind the ear if your skin is sensitive."
  },
  {
    q: "What if it does not suit my skin?",
    a:
      "Unopened products can be returned for a refund or exchange within 7 days. If your skin reacts, message us with a photo and we will suggest a replacement from a different family of ingredients."
  }
];

/* ───────────────────────────────────────────────────────── Testimonials
   SAMPLE CONTENT — these are written examples that show how the review layout
   works, not real customers. They are not displayed anywhere while
   SHR.CONFIG.claims.reviewsVerified is false, and publishing them as real
   reviews would be both dishonest and, in most markets, unlawful. Replace them
   with verified customer reviews, then set the switch to true. */
SHR.TESTIMONIALS = [
  {
    name: "Aline U.",
    city: "Nyarugenge, Kigali",
    rating: 5,
    date: "March 2025",
    verified: true,
    tag: "Oily, acne-prone",
    text:
      "I have bought skincare in Kigali before and got fake product twice. Here everything came sealed with the batch code visible, and the advisor on WhatsApp actually read my routine and told me to drop one of the serums. Three months later my acne marks are almost gone.",
    product: "La Roche-Posay Effaclar Duo+ M"
  },
  {
    name: "Kevin M.",
    city: "Nyamirambo, Kigali",
    rating: 5,
    date: "February 2025",
    verified: true,
    tag: "Combination, big pores",
    text:
      "Delivered the same afternoon with a MoMo receipt. The Ordinary niacinamide on a cotton pad at night has done more for my shine and pores than anything I tried before. Straight advice, no upselling.",
    product: "The Ordinary Niacinamide 10% + Zinc 1%"
  },
  {
    name: "Diane K.",
    city: "Huye",
    rating: 5,
    date: "April 2025",
    verified: true,
    tag: "Sensitive, redness",
    text:
      "I ordered from Huye and it arrived in three days, properly packed. The Cicaplast took the redness from years of hard cleansers down in about two weeks. I love that they answered my questions before I paid instead of after.",
    product: "La Roche-Posay Cicaplast Baume B5"
  },
  {
    name: "Jean-Claude N.",
    city: "Musanze",
    rating: 4.5,
    date: "January 2025",
    verified: true,
    tag: "Dry skin",
    text:
      "The CeraVe tub is the only moisturiser that lasts through a Musanze evening without my face turning grey and ashy. I took the quiz on the website and the routine it gave me was sensible — three products, not ten.",
    product: "CeraVe Moisturizing Cream"
  },
  {
    name: "Sandrine B.",
    city: "Kibagabaga, Kigali",
    rating: 5,
    date: "May 2025",
    verified: true,
    tag: "Pigmentation",
    text:
      "The Eucerin dual serum plus daily sunscreen faded the patches on my cheeks that I had covered with foundation for years. They warned me it would take eight to twelve weeks. It did. Honest timelines matter.",
    product: "Eucerin Anti-Pigment Dual Serum"
  },
  {
    name: "Yvette R.",
    city: "Rubavu",
    rating: 5,
    date: "March 2025",
    verified: true,
    tag: "Korean skincare",
    text:
      "Genuine COSRX and Beauty of Joseon at a price I can actually afford, and the Relief Sun leaves no white cast on deep skin — I had given up on sunscreen before this. Delivery to Rubavu was four days, exactly as promised.",
    product: "Beauty of Joseon Relief Sun"
  },
  {
    name: "Eric T.",
    city: "Muhanga",
    rating: 4.5,
    date: "February 2025",
    verified: true,
    tag: "Beginner",
    text:
      "I asked for a routine under 60,000 RWF for a complete beginner and that is exactly what I got — cleanser, moisturiser, sunscreen. No pressure to buy anything else. My skin stopped feeling tight in the first week.",
    product: "CeraVe Hydrating Facial Cleanser"
  },
  {
    name: "Grace I.",
    city: "Rwamagana",
    rating: 5,
    date: "April 2025",
    verified: true,
    tag: "Body dryness",
    text:
      "The Bioderma Atoderm Balm fixed the dry patches on my arms and legs that came back every dry season. They also followed up on WhatsApp a week later to ask how it was going. Nobody does that here.",
    product: "Bioderma Atoderm Intensive Baume"
  }
];

/* ───────────────────────────────────────────────────────────────── Quiz */
SHR.QUIZ = {
  steps: [
    {
      id: "skinType",
      type: "single",
      title: "How does your skin usually feel after washing?",
      hint: "Answer for a normal day — not straight after exercise or a hot shower.",
      options: [
        { value: "dry", label: "Dry or tight", meta: "It feels stretched and needs cream straight away" },
        { value: "normal", label: "Comfortable", meta: "No tightness and no shine" },
        { value: "oily", label: "Oily", meta: "It is shiny again within a couple of hours" },
        { value: "combination", label: "Oily in some areas and dry in others", meta: "Shiny T-zone, dry cheeks" }
      ]
    },
    {
      id: "concern",
      type: "single",
      title: "What is your main skin concern?",
      hint: "Choose the one that bothers you most — the routine is built around it.",
      options: [
        { value: "acne", label: "Acne" },
        { value: "dark-spots", label: "Dark spots" },
        { value: "dryness", label: "Dryness" },
        { value: "hyperpigmentation", label: "Uneven skin tone" },
        { value: "sensitivity", label: "Sensitivity" },
        { value: "dullness", label: "Dullness" },
        { value: "fine-lines", label: "Fine lines" }
      ]
    },
    {
      id: "sensitivity",
      type: "single",
      title: "How sensitive is your skin?",
      hint: "This decides how gentle we make the first step.",
      options: [
        { value: "high", label: "Very sensitive", meta: "New products usually sting, flush or irritate" },
        { value: "mild", label: "Sometimes sensitive", meta: "Occasional stinging with strong products" },
        { value: "low", label: "Not usually sensitive", meta: "I can tolerate almost anything" }
      ]
    },
    {
      id: "spf",
      type: "single",
      title: "Do you use sunscreen?",
      hint: "In Rwanda this is the step that decides whether dark spots fade, or keep coming back.",
      options: [
        { value: "daily", label: "Every day", meta: "Rain or shine" },
        { value: "sometimes", label: "Sometimes", meta: "When I remember, or when it is very bright" },
        { value: "no", label: "No", meta: "I do not use sunscreen yet" }
      ]
    },
    {
      id: "budget",
      type: "single",
      title: "What is your skincare budget?",
      hint: "We recommend only what fits. A good routine does not have to be expensive.",
      options: [
        { value: "low", label: "Under 30,000 RWF", meta: "Start with the essentials" },
        { value: "mid", label: "30,000 – 60,000 RWF", meta: "The basics plus one serum" },
        { value: "high", label: "60,000 – 100,000 RWF", meta: "A complete routine with targeted actives" },
        { value: "plus", label: "100,000+ RWF", meta: "Everything the routine needs, and nothing it does not" }
      ]
    },
    {
      id: "routine",
      type: "single",
      title: "What type of routine do you want?",
      hint: "There is no wrong answer — this is only so we do not overwhelm you.",
      options: [
        { value: "basic", label: "Basic routine", meta: "Cleanse, moisturise, protect" },
        { value: "complete", label: "Complete routine", meta: "The three essentials plus a serum" },
        { value: "advanced", label: "Advanced routine", meta: "Adds a targeted treatment" }
      ]
    }
  ],

  /* Written advice per skin type, used on the result screen */
  profiles: {
    dry: {
      title: "Dry & dehydrated skin",
      summary:
        "Your barrier is losing water faster than it can replace it. The fix is not more products — it is fewer, richer ones that put ceramides back and hold water in.",
      morning: [
        "Rinse with lukewarm water only, or use a hydrating cleanser if you feel oily",
        "A hyaluronic or ceramide-rich serum onto damp skin",
        "A rich moisturizer while the skin is still damp",
        "SPF 50 every single morning, and reapply if you are outdoors"
      ],
      evening: [
        "Hydrating cleanser, without foaming agents where possible",
        "Treatment serum if you have one, on dry skin",
        "A thick layer of moisturizer — do not be shy with it",
        "Add a face oil or balm on very dry nights"
      ],
      avoid: "Foaming gel cleansers, daily alcohol-based toners, scrubs and any product that leaves the skin feeling tight."
    },
    oily: {
      title: "Oily skin",
      summary:
        "Oiliness is not a cleansing problem, it is a hydration and barrier problem. Strip the skin and it produces more oil. We balance it instead.",
      morning: [
        "Gentle foaming cleanser — twice a day is plenty",
        "Lightweight niacinamide serum to control sebum and refine pores",
        "Oil-free gel moisturizer, always",
        "Matte or fluid SPF 50 — never skip it, sun makes oil worse"
      ],
      evening: [
        "Cleanser, then a salicylic or BHA toner two or three nights a week",
        "Niacinamide or azelaic acid for marks and pores",
        "Light gel moisturizer to finish",
        "Blot, do not wash, during the day"
      ],
      avoid: "Alcohol-heavy toners, harsh scrubs every day, coconut oil and heavy creams, and over-washing which rebounds into more oil."
    },
    combination: {
      title: "Combination skin",
      summary:
        "Two skins in one face. We treat the T-zone and the cheeks separately instead of using one heavy product everywhere.",
      morning: [
        "Gentle gel or hydrating cleanser — something that does neither extreme",
        "Light hydrating serum all over",
        "Gel-cream moisturizer, and a richer layer on the cheeks only",
        "Fluid SPF 50 for the whole face"
      ],
      evening: [
        "Cleanser, then a BHA toner on the T-zone only",
        "Niacinamide for shine and pore control",
        "Moisturizer, lighter in the T-zone, richer on the cheeks"
      ],
      avoid: "One heavy cream for the whole face, aggressive stripping of the cheeks, and leaving sunscreen off because it makes the T-zone shine."
    },
    normal: {
      title: "Balanced skin",
      summary:
        "Your skin is doing well. Our job is protecting it — sun protection, gentle cleansing and a simple routine slow ageing down more than any hero serum.",
      morning: [
        "Gentle cleanser or a water rinse",
        "Antioxidant serum, vitamin C if you want glow",
        "Light moisturizer",
        "SPF 50 daily, without exception"
      ],
      evening: [
        "Cleanse away sunscreen and the day",
        "A retinoid two or three nights a week, if you want to prevent fine lines",
        "Moisturizer to seal it in",
        "Exfoliate gently once a week"
      ],
      avoid: "Adding actives you do not need, skipping sunscreen, and changing products every three weeks before they have had time to work."
    },
    sensitive: {
      title: "Sensitive & reactive skin",
      summary:
        "Your skin reacts first and asks questions later. We start with barrier repair, no fragrance, and one change at a time.",
      morning: [
        "Rinse with lukewarm water, or a fragrance-free micellar water",
        "Barrier cream with ceramides or panthenol",
        "Mineral or gentle chemical SPF 50 — test it on your jaw first"
      ],
      evening: [
        "Fragrance-free cleanser, patted — never rubbed",
        "A barrier balm, thick enough to leave a film",
        "Nothing else for the first two weeks"
      ],
      avoid: "Fragrance, essential oils, denatured alcohol, physical scrubs, hot water on the face, and introducing more than one new product at a time."
    }
  },

  /* Which product family to pick for each routine slot. `label` is what the
     customer sees in the result, `step` groups it under the four-step routine
     used across the site: cleanse, treat, moisturize, protect. */
  routineSlots: [
    { id: "cleanser", category: "cleansers", label: "Cleanser", step: "Cleanse", note: "Morning and evening" },
    { id: "serum", category: "serums", label: "Serum", step: "Treat", note: "After cleansing, before moisturizer" },
    { id: "treatment", category: "acne-care", label: "Treatment", step: "Treat", note: "Evening, or every other evening" },
    { id: "moisturizer", category: "moisturizers", label: "Moisturizer", step: "Moisturize", note: "Morning and evening" },
    { id: "spf", category: "sunscreens", label: "Sunscreen", step: "Protect", note: "Every morning, whatever the weather" }
  ],

  /* What each budget answer means in practice. `perItem` is the ceiling we try
     to stay under for one product; `total` is what the whole routine should
     ideally come to. We never hide a product to hit a number — if the honest
     routine costs more, the result says so and gives the order to buy in. */
  budgetCaps: {
    low: { perItem: 20000, total: 30000, label: "under 30,000 RWF" },
    mid: { perItem: 30000, total: 60000, label: "30,000 – 60,000 RWF" },
    high: { perItem: 50000, total: 100000, label: "60,000 – 100,000 RWF" },
    plus: { perItem: 120000, total: 200000, label: "over 100,000 RWF" }
  }
};

/* ─────────────────────────────────────────────── Consultation form copy */
SHR.CONSULTATION = {
  steps: [
    { n: "1", title: "Tell us about your skin", text: "Two minutes on the form — your skin type, your concerns and what you have already tried." },
    { n: "2", title: "We read it properly", text: "A skincare advisor reviews your answers, and your photos if you sent them, and checks them against what we actually stock." },
    { n: "3", title: "You get a written routine", text: "A morning and evening routine, the products in order, what to expect and how long it will take. On WhatsApp, within one working day." },
    { n: "4", title: "We follow up", text: "Two weeks later we check in. If something is stinging or you are running out, we adjust the routine — no charge, no pressure." }
  ],
  whatYouGet: [
    "A morning and an evening routine written for your skin, in order",
    "Product recommendations at your budget — cheapest options included",
    "What to avoid with your skin type, and why",
    "Realistic timelines for dark spots, acne and barrier repair",
    "A free two-week follow-up on WhatsApp"
  ]
};

/* Skincare tips — the short rules we actually give customers on WhatsApp,
   shown on the home page. Each one carries the shelf or the guide that goes
   with it, so a tip is never a dead end. Deliberately few: six rules someone
   will follow beat twenty they will not, and none of them promises a result
   a skincare product cannot deliver. */
SHR.TIPS = [
  {
    n: "01",
    title: "Sunscreen every morning, cloud or not",
    text: "Rwanda sits close to the equator, so UV stays high all year and cloud does not block it. A broad-spectrum SPF 50 in the morning is the step that decides how fast dark spots fade.",
    href: "shop.html?category=sunscreens",
    link: "Shop sunscreens"
  },
  {
    n: "02",
    title: "Add one new product at a time",
    text: "Introduce one active every two weeks and keep the rest of your routine boring and unchanged. If something stings or breaks you out, you then know exactly what did it.",
    href: "article.html?slug=how-to-layer-skincare-products",
    link: "How to layer products"
  },
  {
    n: "03",
    title: "Moisturize while the skin is damp",
    text: "Apply moisturizer within a minute of cleansing, before the skin dries. It seals that water in instead of sitting on a dry surface doing very little.",
    href: "shop.html?category=moisturizers",
    link: "Shop moisturizers"
  },
  {
    n: "04",
    title: "Patch test before your whole face",
    text: "Three nights on the jaw or behind an ear is enough to catch a reaction before it reaches the middle of your face. Worth the wait with any acid, retinoid or brightening serum.",
    href: "article.html?slug=beginner-skincare-routine",
    link: "Start a simple routine"
  },
  {
    n: "05",
    title: "Do not stack strong actives on one night",
    text: "A retinoid and an exfoliating acid in the same evening is what usually causes the irritation people then blame on the product. Use them on alternate nights instead.",
    href: "article.html?slug=how-to-treat-acne",
    link: "Treating acne"
  },
  {
    n: "06",
    title: "Give it eight to twelve weeks",
    text: "Skin renews on a roughly four-week cycle and pigmentation takes longer still. A fair trial is eight weeks of consistent use, morning and evening — changing products every week tells you nothing.",
    href: "article.html?slug=how-to-fade-dark-spots",
    link: "Fading dark spots"
  }
];
