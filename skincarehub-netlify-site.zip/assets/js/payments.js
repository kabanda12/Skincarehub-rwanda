/* ==========================================================================
   Skincare Hub Rwanda — online payments
   Loaded after app.js, before the page controllers.

   Everything a real online payment needs, in one place:
     · card + mobile money capture through the provider configured in
       SHR.CONFIG.payments (Flutterwave by default — cards, MTN MoMo and
       Airtel Money, settling in RWF)
     · an MTN MoMoPay merchant-code path that needs no integration at all
     · the words the checkout shows, so no page ever claims a payment was or
       was not taken when it was not true

   Design rules:
     · Only a PUBLISHABLE key belongs in this file. It is client-side code.
     · Confirming that the amount paid matches the order needs the provider's
       SECRET key, so it happens server-side. With no endpoint configured a
       successful payment is recorded as "pending-verification" — never as
       "paid" — and the merchant checks it in the provider's dashboard.
     · Nothing here runs, and no external script is fetched, until
       SHR.CONFIG.payments.publicKey is filled in.
   ========================================================================== */
window.SHR = window.SHR || {};
(function () {
  "use strict";

  var api = SHR.api;
  var CONFIG = SHR.CONFIG;

  var DEFAULT_SCRIPT = "https://checkout.flutterwave.com/v3.js";
  var SCRIPT_TIMEOUT = 12000;
  var PENDING = "pending-verification";

  var scriptPromise = null;

  /* ──────────────────────────────────────────────────────── configuration */
  function cfg() {
    var c = CONFIG.payments || {};
    return {
      provider: String(c.provider || ""),
      publicKey: String(c.publicKey || ""),
      testMode: !!c.testMode,
      verifyEndpoint: String(c.verifyEndpoint || ""),
      checkoutScript: String(c.checkoutScript || DEFAULT_SCRIPT),
      momoPayCode: String(c.momoPayCode || ""),
      momoPayName: String(c.momoPayName || CONFIG.name || ""),
      description: String(c.description || CONFIG.tagline || ""),
      logo: String(c.logo || ""),
      sessionMinutes: Number(c.sessionMinutes) || 30,
      maxRetries: Number(c.maxRetries) || 3
    };
  }

  function provider() {
    return cfg().provider;
  }

  /* A public key is the only thing that turns online capture on. */
  function isReady() {
    var c = cfg();
    return c.provider === "flutterwave" && /^FLWPUBK/.test(c.publicKey);
  }

  function isTest() {
    var c = cfg();
    return isReady() && (c.testMode || /_TEST/i.test(c.publicKey));
  }

  function momoCode() {
    return cfg().momoPayCode.replace(/[^0-9]/g, "");
  }

  /* ───────────────────────────────────────────────────────── the numbers */
  /* RWF has no minor unit, so the provider is sent whole francs: 15,000 RWF
     is 15000, not 1500000. */
  function amountFor(total) {
    var n = Number(total);
    if (!isFinite(n) || n <= 0) return 0;
    return Math.round(n);
  }

  /* 0787 851 681 → 250787851681 */
  function phoneFor(raw) {
    var d = String(raw || "").replace(/[^0-9]/g, "");
    if (d.indexOf("250") === 0 && d.length >= 12) return d;
    if (d.charAt(0) === "0" && d.length === 10) return "250" + d.slice(1);
    if (d.length === 9) return "250" + d;
    return d;
  }

  /* *182*8*1*<merchant code>*<amount># — the shortcut for an MTN MoMoPay code */
  function ussd(amount, code) {
    var c = String(code || momoCode()).replace(/[^0-9]/g, "");
    if (!c) return "";
    var a = amountFor(amount);
    return "*182*8*1*" + c + (a ? "*" + a : "") + "#";
  }

  /* ─────────────────────────────────────────────────────── the methods */
  function methods() {
    return (SHR.PAYMENTS || []).map(function (p) {
      var online = p.kind === "online";
      return {
        id: p.id,
        label: p.label,
        meta: p.meta,
        icon: p.icon || "card",
        kind: online ? "online" : "manual",
        channel: p.channel || "",
        online: online,
        live: online && isReady()
      };
    });
  }

  function methodById(id) {
    var all = methods();
    for (var i = 0; i < all.length; i++) {
      if (all[i].id === id) return all[i];
    }
    return null;
  }

  /* One group when money is confirmed by hand, two once online capture is on. */
  function groups() {
    var all = methods();
    if (!isReady()) return [{ title: "", methods: all }];
    var out = [
      { title: "Pay now, on this page", methods: all.filter(function (m) { return m.live; }) },
      { title: "Pay once we confirm your order", methods: all.filter(function (m) { return !m.live; }) }
    ];
    return out.filter(function (g) { return g.methods.length; });
  }

  /* ─────────────────────────────────────────────────────── the request */
  function paymentOptions(methodId) {
    var m = methodById(methodId);
    return (m && m.channel) || "card";
  }

  function shortItems(order) {
    return (order.items || []).map(function (i) {
      return i.qty + "x " + i.brand + " " + i.name;
    }).join("; ").slice(0, 200);
  }

  function logoUrl(logo) {
    if (!logo) return "";
    var http = typeof window !== "undefined" && window.location && /^https?:$/.test(window.location.protocol);
    if (!http) return "";
    try {
      return new URL(logo, window.location.href).href;
    } catch (e) {
      return "";
    }
  }

  /* The exact object FlutterwaveCheckout() is called with, minus the
     callbacks (they are functions, so they are added at call time — this
     keeps payload() inspectable and testable). */
  function payload(order) {
    var c = cfg();
    var customer = order.customer || {};
    var amount = amountFor((order.totals || {}).total);
    return {
      public_key: c.publicKey,
      tx_ref: order.ref,
      amount: amount,
      currency: CONFIG.currency,
      payment_options: paymentOptions(order.payment),
      customer: {
        email: customer.email || "",
        phone_number: phoneFor(customer.phone),
        name: [customer.firstName, customer.lastName].filter(Boolean).join(" ") || "Skincare Hub customer"
      },
      customizations: {
        title: c.momoPayName,
        description: c.description || ("Order " + order.ref),
        logo: logoUrl(c.logo)
      },
      meta: {
        order_ref: order.ref,
        method: order.payment || "",
        items: shortItems(order)
      },
      configurations: {
        session_duration: c.sessionMinutes,
        max_retry_attempt: c.maxRetries
      }
    };
  }

  /* ─────────────────────────────────────────────────── launch + confirm */
  function loadScript(url) {
    if (typeof window.FlutterwaveCheckout === "function") return Promise.resolve();
    if (scriptPromise) return scriptPromise;
    scriptPromise = new Promise(function (resolve, reject) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        scriptPromise = null;
        reject(new Error("The payment page did not load. Check your connection and try again."));
      }, SCRIPT_TIMEOUT);
      var s = document.createElement("script");
      s.src = url;
      s.async = true;
      s.onload = function () {
        if (done) return;
        done = true;
        clearTimeout(timer);
        if (typeof window.FlutterwaveCheckout === "function") resolve();
        else {
          scriptPromise = null;
          reject(new Error("The payment page did not start up. Please try again or message us on WhatsApp."));
        }
      };
      s.onerror = function () {
        if (done) return;
        done = true;
        clearTimeout(timer);
        scriptPromise = null;
        reject(new Error("We could not reach the payment page. Check your connection and try again."));
      };
      document.head.appendChild(s);
    });
    return scriptPromise;
  }

  /* Resolves with one of:
       success                — the customer completed the payment
       cancelled              — they closed the modal, nothing was taken
       failed                 — the provider reported a non-successful charge
       unavailable            — no key configured, or the provider is unreachable */
  function pay(order) {
    if (!isReady()) {
      return Promise.resolve({ status: "unavailable", message: "Online payment is not switched on yet." });
    }
    var amount = amountFor(((order || {}).totals || {}).total);
    if (!amount) {
      return Promise.resolve({ status: "failed", message: "This order has no amount to pay." });
    }
    return loadScript(cfg().checkoutScript).then(function () {
      return new Promise(function (resolve) {
        var settled = false;
        function settle(result) {
          if (settled) return;
          settled = true;
          resolve(result);
        }
        function start() {
          var settings = Object.assign(payload(order), {
            callback: function (payment) {
              var ok = !!payment && (payment.status === "successful" || payment.status === "completed");
              settle({
                status: ok ? "success" : "failed",
                message: ok ? "" : "The payment did not go through.",
                amount: amount,
                method: order.payment || "",
                transactionRef: String((payment && (payment.transaction_id || payment.flw_ref)) || ""),
                payment: payment || {}
              });
            },
            onclose: function (incomplete) {
              if (incomplete) {
                settle({ status: "cancelled", message: "The payment window was closed before the payment finished.", amount: amount, method: order.payment || "" });
              }
            }
          });
          try {
            window.FlutterwaveCheckout(settings);
          } catch (e) {
            settle({ status: "failed", message: "The payment window could not open. Please try again." });
          }
        }
        start();
      });
    }).catch(function (err) {
      return { status: "unavailable", message: (err && err.message) || "Online payment is temporarily unavailable." };
    });
  }

  /* Confirming an amount needs the secret key, so it is done by a server.
     With no endpoint configured the payment is recorded, never trusted. */
  function verify(order, result) {
    var c = cfg();
    var amount = amountFor(((order || {}).totals || {}).total);
    if (!c.verifyEndpoint || typeof fetch !== "function") {
      return Promise.resolve({
        verified: false,
        status: PENDING,
        message: "We check every payment against our provider before your order ships."
      });
    }
    return fetch(c.verifyEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        reference: order.ref,
        transactionId: (result && result.transactionRef) || "",
        amount: amount,
        currency: CONFIG.currency
      })
    }).then(function (res) {
      return res.json();
    }).then(function (data) {
      if (data && data.verified === true && Number(data.amount || amount) >= amount) {
        return { verified: true, status: "paid", message: "Payment confirmed." };
      }
      if (data && data.status === "amount-mismatch") {
        return { verified: false, status: "amount-mismatch", message: "The amount we received does not match this order — we will contact you." };
      }
      return { verified: false, status: PENDING, message: "Your payment is recorded and is being checked." };
    }).catch(function () {
      return { verified: false, status: PENDING, message: "We could not reach our confirmation service just now, so your payment is checked before dispatch." };
    });
  }

  /* The status an order record should carry after a payment attempt. */
  function complete(order, result) {
    if (!result || result.status !== "success") {
      return Promise.resolve({ verified: false, status: "unpaid", message: (result && result.message) || "" });
    }
    return verify(order, result);
  }

  function payable(order) {
    if (!order || !isReady()) return false;
    if (order.paymentStatus === "paid") return false;
    return amountFor((order.totals || {}).total) > 0 && !!order.customer && !!order.customer.email;
  }

  /* ─────────────────────────────────────────────────────── the wording */
  function statusLabel(status) {
    if (status === "paid") return "Paid";
    if (status === PENDING) return "Payment being checked";
    if (status === "awaiting-payment") return "Awaiting payment";
    if (status === "amount-mismatch") return "Amount to check";
    return "Not paid yet";
  }

  function statusClass(status) {
    if (status === "paid") return "badge--new";
    if (status === PENDING || status === "amount-mismatch") return "badge--low";
    return "badge--out";
  }

  function note() {
    var tail = " Never send payment to any other number than " + CONFIG.whatsappDisplay + ".";
    if (isReady()) {
      return (isTest()
        ? "Test mode is on, so no real money moves. "
        : "") +
        "Card and mobile money payments run over an SSL-secured, 3-D Secure connection and we never see or store your card number." +
        " We check every payment against our provider before your order ships." + tail;
    }
    return "You are not charged on this page. Place the order and we confirm stock and the final total with you first." + tail;
  }

  function footnote() {
    return isReady()
      ? "A secure payment page opens when you place the order. Your card details are never stored on this site."
      : "No payment is taken now. We confirm first, then you pay.";
  }

  function intro() {
    return isReady()
      ? "Three short steps, then pay on a secure payment page by card, MTN MoMo or Airtel Money."
      : "Three short steps. We confirm everything with you on WhatsApp before any payment is taken.";
  }

  function buttonLabel(methodId, total) {
    var m = methodById(methodId);
    var amount = amountFor(total);
    if (m && m.live && amount) return "Pay " + api.money(amount) + " securely";
    return "Place the order";
  }

  function momoCodeHTML(amount) {
    var code = momoCode();
    var label = amount ? api.money(amount) : "";
    if (!code) {
      return "<p class=\"form-note\">We confirm your order first, then send the MTN MoMo request to your number. Approve it with your PIN — nothing is charged before that.</p>";
    }
    return "<p class=\"form-note\">Pay from your own MTN MoMo wallet — no card needed. Dial <strong>*182#</strong>, choose " +
      "<strong>Pay merchant</strong>, enter our code <strong>" + api.esc(code) + "</strong>" +
      (label ? " and " + label : "") + ", then your PIN. The money reaches us instantly.</p>" +
      "<p class=\"form-note\">Shortcut, where your SIM supports it: <strong>" + api.esc(ussd(amount)) + "</strong></p>";
  }

  /* What to tell the customer about the method they picked. Pure string
     building, so the tests can assert on the exact advice shown. */
  function hintHTML(methodId, ctx) {
    ctx = ctx || {};
    var m = methodById(methodId);
    if (!m) return "";
    var amount = amountFor(ctx.total);
    var label = amount ? api.money(amount) : "";
    var phone = ctx.phone ? "<strong>" + api.esc(ctx.phone) + "</strong>" : "the number you entered";

    if (m.id === "card") {
      return m.live
        ? "<p class=\"form-note\">When you place the order a secure card form opens where you pay " + label + ". " +
          "Your card number is never stored on this site and every card payment runs over 3-D Secure.</p>"
        : "<p class=\"form-note\">We confirm stock and the total with you on WhatsApp first, then send a secure card payment link" +
          (label ? " for " + label : "") + ".</p>";
    }
    if (m.id === "mtn-momo" || m.id === "airtel-money") {
      var wallet = m.id === "mtn-momo" ? "MTN MoMo" : "Airtel Money";
      if (m.live) {
        return "<p class=\"form-note\">You pay " + label + " from " + wallet + ": the request is pushed to " + phone +
          " the moment you place the order. Approve it with your PIN and you are done.</p>";
      }
      if (m.id === "mtn-momo" && momoCode()) return momoCodeHTML(amount);
      return "<p class=\"form-note\">We confirm your order, then send the " + wallet + " request" +
        (label ? " for " + label : "") + " to " + phone + ". Approve it with your PIN — nothing is charged before that.</p>";
    }
    if (m.id === "momo-pay") return momoCodeHTML(amount);
    if (m.id === "cod") {
      return "<p class=\"form-note\">Pay the rider in cash when your parcel arrives" +
        (label ? " (" + label + ")" : "") + ". Cash on delivery is available inside Kigali.</p>";
    }
    return "";
  }

  SHR.pay = {
    provider: provider,
    isReady: isReady,
    isTest: isTest,
    config: cfg,
    amountFor: amountFor,
    phoneFor: phoneFor,
    ussd: ussd,
    momoCode: momoCode,
    methods: methods,
    methodById: methodById,
    groups: groups,
    paymentOptions: paymentOptions,
    payload: payload,
    loadScript: loadScript,
    pay: pay,
    verify: verify,
    complete: complete,
    payable: payable,
    statusLabel: statusLabel,
    statusClass: statusClass,
    note: note,
    footnote: footnote,
    intro: intro,
    buttonLabel: buttonLabel,
    hintHTML: hintHTML
  };
})();
