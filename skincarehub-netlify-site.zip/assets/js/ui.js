/* ==========================================================================
   Skincare Hub Rwanda — Site chrome
   Sticky header, mobile nav drawer, cart drawer, search overlay, live chat,
   floating actions, toast host, reveal-on-scroll, carousels, quantity widgets.
   Everything here is injected once and works on every page.
   ========================================================================== */
window.SHR = window.SHR || {};
(function () {
  "use strict";

  var api = SHR.api;
  var $ = api.$, $$ = api.$$, esc = api.esc, icon = api.icon, money = api.money;
  var CONFIG = SHR.CONFIG, CATEGORIES = SHR.CATEGORIES, BRANDS = SHR.BRANDS;

  /* The desktop bar stays short: shop, the quiz, who we are, how to reach us.
     Everything else - blog, FAQ, reviews, consultation, policies - lives in
     the footer and in the mobile menu, where it is easier to find on a phone. */
  var NAV_LINKS = [
    { href: "shop.html", label: "Shop", page: "shop", mega: true },
    { href: "quiz.html", label: "Skin Quiz", page: "quiz" },
    { href: "about.html", label: "About", page: "about" },
    { href: "contact.html", label: "Contact", page: "contact" }
  ];

  /* The mobile menu keeps the long list, because a drawer has the room */
  var DRAWER_LINKS = NAV_LINKS.concat([
    { href: "index.html", label: "Home", page: "home" },
    { href: "consultation.html", label: "Personalized Consultation", page: "consultation" },
    { href: "reviews.html", label: "Customer Reviews", page: "reviews" },
    { href: "blog.html", label: "Skincare Blog", page: "blog" },
    { href: "faq.html", label: "FAQ", page: "faq" },
    { href: "policies.html", label: "Delivery, returns &amp; policies", page: "policies" }
  ]);

  var POPULAR_SEARCHES = [
    "CeraVe",
    "sunscreen",
    "niacinamide",
    "dark spots",
    "acne",
    "Korean skincare",
    "moisturizer",
    "The Ordinary"
  ];

  /* ─────────────────────────────────────────────── small markup pieces */
  function categoryLinks(limit) {
    return CATEGORIES.filter(function (c) {
      return c.kind === "type";
    })
      .slice(0, limit || 12)
      .map(function (c) {
        return '<a href="shop.html?category=' + c.id + '">' + esc(c.name) + "</a>";
      })
      .join("");
  }
  function brandLinks() {
    return BRANDS.map(function (b) {
      return '<a href="shop.html?brand=' + b.id + '">' + esc(b.name) + "</a>";
    }).join("");
  }
  function concernLinks() {
    return (SHR.CONCERN_FACETS || []).map(function (c) {
      return '<a href="' + esc(api.concernHref(c)) + '">' + esc(c.label) + "</a>";
    }).join("");
  }
  function currentPage() {
    return (document.body && document.body.getAttribute("data-page")) || "";
  }

  /* ──────────────────────────────────────────────── header navigation */
  function enhanceHeader() {
    var page = currentPage();
    $$(".mainnav__link, .mobile-nav__link").forEach(function (a) {
      var href = a.getAttribute("href") || "";
      var match = NAV_LINKS.filter(function (l) {
        return href.indexOf(l.href) === 0;
      })[0];
      if (match && (match.page === page || (page === "article" && match.page === "blog") || (page === "product" && match.page === "shop"))) {
        a.setAttribute("aria-current", "page");
      }
    });
    /* megamenu built from the catalogue so it never drifts out of date */
    $$("[data-megamenu]").forEach(function (node) {
      node.innerHTML =
        '<div><p class="megamenu__title">Shop by category</p><div class="megamenu__links">' +
        categoryLinks(12) +
        '</div><p class="megamenu__title mt-3">Shop by brand</p><div class="megamenu__links">' +
        brandLinks() +
        '</div></div>' +
        '<div><p class="megamenu__title">Shop by concern</p><div class="megamenu__links">' +
        concernLinks() +
        "</div></div>" +
        '<div class="megamenu__cta"><strong>Not sure where to start?</strong>' +
        "<p>Answer six quick questions and we will build your routine from scratch.</p>" +
        '<a class="btn btn--gold btn--sm" href="quiz.html">' + icon("sparkle") + "Find Your Routine</a>" +
        '<a class="link-arrow" href="shop.html?category=best-sellers" style="color:#fff">Browse Best Sellers ' + icon("arrowRight") + "</a></div>";
    });
    /* mobile drawer list */
    $$("[data-mobile-nav]").forEach(function (node) {
      node.innerHTML =
        '<div class="mobile-nav">' +
        DRAWER_LINKS.map(function (l) {
          return '<a class="mobile-nav__link" href="' + l.href + '">' + l.label + icon("arrowRight") + "</a>";
        }).join("") +
        "</div>" +
        '<p class="mobile-nav__group">Shop by concern</p><div class="mobile-nav__chips">' +
        (SHR.CONCERN_FACETS || []).map(function (c) {
          return '<a class="chip" href="' + esc(api.concernHref(c)) + '">' + esc(c.label) + "</a>";
        }).join("") +
        "</div>" +
        '<p class="mobile-nav__group">Categories</p><div class="mobile-nav__chips">' +
        CATEGORIES.map(function (c) {
          return '<a class="chip" href="shop.html?category=' + c.id + '">' + esc(c.name) + "</a>";
        }).join("") +
        '</div><p class="mobile-nav__group">Brands</p><div class="mobile-nav__chips">' +
        BRANDS.map(function (b) {
          return '<a class="chip" href="shop.html?brand=' + b.id + '">' + esc(b.name) + "</a>";
        }).join("") +
        "</div>" +
        '<p class="mobile-nav__group">Your account</p><div class="mobile-nav__chips">' +
        '<a class="chip" href="cart.html">Cart</a>' +
        '<a class="chip" href="wishlist.html">Wishlist</a><a class="chip" href="account.html">My account</a>' +
        "</div>";
    });
  }

  function stickyHeader() {
    var header = $(".site-header");
    if (!header) return;
    function syncHeight() {
      document.documentElement.style.setProperty("--header-h", header.offsetHeight + "px");
    }
    function onScroll() {
      header.classList.toggle("is-stuck", window.scrollY > 8);
      var top = $(".fab--top");
      if (top) top.classList.toggle("is-shown", window.scrollY > 700);
    }
    syncHeight();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", api.debounce(syncHeight, 200));
    onScroll();
  }

  /* ──────────────────────────────────────────────── overlay factories */
  function overlayHost() {
    var host = $("#shrOverlays");
    if (!host) {
      host = document.createElement("div");
      host.id = "shrOverlays";
      document.body.appendChild(host);
    }
    return host;
  }

  function navDrawerHTML() {
    return (
      '<div class="drawer" id="navDrawer" hidden>' +
      '<div class="drawer__scrim" data-close-all></div>' +
      '<aside class="drawer__panel" role="dialog" aria-modal="true" aria-label="Main menu">' +
      '<div class="drawer__head"><h2 class="drawer__title">Menu</h2>' +
      '<button class="icon-btn" type="button" data-close-all aria-label="Close menu">' + icon("close") + "</button></div>" +
      '<div class="drawer__body" data-mobile-nav></div>' +
      '<div class="drawer__foot"><a class="btn btn--whatsapp btn--block" href="' + esc(api.waLink("Hello Skincare Hub Rwanda, I need help choosing products.")) +
      '" target="_blank" rel="noopener">' + icon("whatsapp") + "Chat on WhatsApp</a></div>" +
      "</aside></div>"
    );
  }

  function cartDrawerHTML() {
    return (
      '<div class="drawer drawer--right" id="cartDrawer" hidden>' +
      '<div class="drawer__scrim" data-close-all></div>' +
      '<aside class="drawer__panel" role="dialog" aria-modal="true" aria-label="Shopping cart">' +
      '<div class="drawer__head">' +
      '<h2 class="drawer__title">Your cart <span class="text-muted" data-cart-drawer-count></span></h2>' +
      '<button class="icon-btn" type="button" data-close-all aria-label="Close cart">' + icon("close") + "</button></div>" +
      '<div class="drawer__body" data-cart-body></div>' +
      '<div class="drawer__foot" data-cart-foot></div>' +
      "</aside></div>"
    );
  }

  function searchOverlayHTML() {
    return (
      '<div class="search-overlay" id="searchOverlay" hidden>' +
      '<div class="search-overlay__inner">' +
      '<div class="search-overlay__row">' + icon("search") +
      '<label class="sr-only" for="shrSearchInput">Search products</label>' +
      '<input class="search-overlay__input" id="shrSearchInput" type="search" autocomplete="off" ' +
      'placeholder="Search products, brands, concerns…" data-search-input>' +
      '<button class="icon-btn" type="button" data-close-all aria-label="Close search">' + icon("close") + "</button></div>" +
      '<div class="search-suggest"><p class="eyebrow">Popular right now</p>' +
      '<div class="chip-row">' + POPULAR_SEARCHES.map(function (s) {
        return '<button class="chip" type="button" data-search-chip="' + esc(s) + '">' + esc(s) + "</button>";
      }).join("") + "</div></div>" +
      '<div class="search-results" data-search-results aria-live="polite"></div>' +
      "</div></div>"
    );
  }

  function chatHTML() {
    return (
      '<section class="chat" id="shrChat" aria-label="Live chat">' +
      '<header class="chat__head"><span class="chat__avatar">SH</span>' +
      '<span class="chat__id"><strong>Skincare Hub Rwanda</strong><span>Advisor online</span></span>' +
      '<button class="chat__close" type="button" data-chat-close aria-label="Close chat">' + icon("close") + "</button></header>" +
      '<div class="chat__body" data-chat-body></div>' +
      '<div class="chat__quick" data-chat-quick></div>' +
      '<form class="chat__foot" data-chat-form>' +
      '<label class="sr-only" for="shrChatInput">Message</label>' +
      '<input class="input" id="shrChatInput" type="text" placeholder="Type your question…" data-chat-input autocomplete="off">' +
      '<button class="chat__send" type="submit" aria-label="Send message">' + icon("send") + "</button></form>" +
      '<p class="chat__footnote">Automated replies — a human advisor answers on WhatsApp within working hours.</p>' +
      "</section>"
    );
  }

  function floatersHTML() {
    return (
      '<div class="floaters">' +
      '<a class="fab fab--whatsapp" href="' + esc(api.waLink()) + '" target="_blank" rel="noopener" ' +
      'aria-label="Chat with us on WhatsApp">' + icon("whatsapp") + "</a>" +
      '<button class="fab fab--chat" type="button" data-chat-open aria-label="Open live chat">' + icon("chat") +
      '<span class="fab__dot"></span></button>' +
      '<button class="fab fab--top" type="button" data-scroll-top aria-label="Back to top">' + icon("arrowUp") + "</button>" +
      "</div>"
    );
  }

  /* The bar that sits at the bottom of a phone screen: home, shop, quiz,
     WhatsApp, cart. It is in the markup on every page and hidden by CSS on
     anything wide enough for the header to be enough. */
  function bottomNavHTML() {
    var page = currentPage();
    function is(p) {
      return page === p || (page === "article" && p === "blog") || (page === "product" && p === "shop") ? ' aria-current="page"' : "";
    }
    return (
      '<nav class="bottom-nav" aria-label="Quick navigation">' +
      '<a class="bottom-nav__item" href="index.html"' + (page === "home" ? ' aria-current="page"' : "") + ">" + icon("home") + "<span>Home</span></a>" +
      '<a class="bottom-nav__item" href="shop.html"' + is("shop") + ">" + icon("bag") + "<span>Shop</span></a>" +
      '<a class="bottom-nav__item" href="quiz.html"' + is("quiz") + ">" + icon("sparkle") + "<span>Quiz</span></a>" +
      '<a class="bottom-nav__item bottom-nav__item--wa" href="' + esc(api.waLink("Hello Skincare Hub Rwanda, I would like help choosing skincare.")) +
      '" target="_blank" rel="noopener">' + icon("whatsapp") + "<span>WhatsApp</span></a>" +
      '<button class="bottom-nav__item" type="button" data-cart-open aria-label="Open cart">' + icon("cart") +
      '<span>Cart</span><span class="count" data-cart-count data-empty="true">0</span></button>' +
      "</nav>"
    );
  }

  /* ── quick view: the product, without leaving the grid ─────────────── */
  function quickViewShellHTML() {
    return (
      '<div class="quickview" id="quickView" hidden>' +
      '<div class="quickview__scrim" data-close-all></div>' +
      '<div class="quickview__panel" role="dialog" aria-modal="true" aria-labelledby="quickViewTitle" data-quickview-panel></div>' +
      "</div>"
    );
  }
  function openQuickView(id) {
    var p = api.getProduct(id);
    var node = $("#quickView");
    var panel = node ? $("[data-quickview-panel]", node) : null;
    if (!p || !node || !panel) return;
    panel.innerHTML =
      '<button class="icon-btn quickview__close" type="button" data-close-all aria-label="Close quick view">' + icon("close") + "</button>" +
      api.quickViewHTML(p);
    node.hidden = false;
    window.requestAnimationFrame(function () {
      node.classList.add("is-open");
    });
    document.body.classList.add("is-locked");
    var focusable = panel.querySelector("button, a[href]");
    if (focusable) focusable.focus();
    api.analytics.event("view_item_quick", { item_id: p.id });
  }
  function closeQuickView() {
    var node = $("#quickView");
    if (!node || node.hidden) return;
    node.classList.remove("is-open");
    setTimeout(function () {
      node.hidden = true;
    }, 260);
  }

  /* ──────────────────────────────────────────────────── cart drawer */
  function renderCart() {
    var body = $("[data-cart-body]");
    if (!body) return;
    var lines = api.cart.detailed();
    var count = api.cart.count();
    var countNode = $("[data-cart-drawer-count]");
    if (countNode) countNode.textContent = count ? "(" + count + " item" + (count === 1 ? "" : "s") + ")" : "";

    if (!lines.length) {
      body.innerHTML =
        '<div class="empty-state">' + icon("cart") +
        "<p>Your cart is empty.</p>" +
        '<a class="btn btn--gold btn--sm" href="shop.html?category=best-sellers">Browse Best Sellers</a>' +
        "</div>";
    } else {
      body.innerHTML = lines.map(function (l) {
        var url = "product.html?id=" + encodeURIComponent(l.product.id);
        return (
          '<div class="line-item">' +
          '<a class="line-item__thumb" href="' + url + '" tabindex="-1" aria-hidden="true"><span class="visual">' +
          api.productVisual(l.product) + "</span></a>" +
          '<div class="line-item__info">' +
          '<span class="line-item__brand">' + esc(l.product.brand) + "</span>" +
          '<a class="line-item__name" href="' + url + '">' + esc(l.product.name) + "</a>" +
          '<span class="line-item__meta">' + esc(l.product.size) + "</span>" +
          '<div class="qty mt-1" data-qty="' + esc(l.product.id) + '">' +
          '<button type="button" data-qty-minus aria-label="Decrease quantity of ' + esc(l.product.name) + '">&minus;</button>' +
          "<span data-qty-value>" + l.qty + "</span>" +
          '<button type="button" data-qty-plus aria-label="Increase quantity of ' + esc(l.product.name) + '">+</button></div>' +
          '<button class="remove-link mt-1" type="button" data-cart-remove="' + esc(l.product.id) + '">Remove</button>' +
          "</div>" +
          '<div class="line-item__price">' + money(l.lineTotal) + "</div>" +
          "</div>"
        );
      }).join("");
    }

    var foot = $("[data-cart-foot]");
    if (!foot) return;
    if (!lines.length) {
      foot.innerHTML = '<a class="btn btn--outline btn--block" href="shop.html">Start shopping</a>';
      return;
    }
    var prog = api.cart.freeDeliveryProgress();
    var discount = api.cart.discount();
    foot.innerHTML =
      '<div class="drawer__summary">' +
      '<div class="summary-row"><span>Subtotal</span><strong>' + money(api.cart.subtotal()) + "</strong></div>" +
      (discount ? '<div class="summary-row"><span>Discount (' + esc(api.cart.promoCode()) + ')</span><strong>&minus;' + money(discount) + "</strong></div>" : "") +
      '<div class="summary-row"><span>Delivery in Kigali</span><strong>' + (api.cart.shippingDefault() === 0 ? "Free" : money(api.cart.shippingDefault())) + "</strong></div>" +
      '<div class="summary-row summary-row--total"><span>Total</span><strong>' + money(api.cart.total()) + "</strong></div>" +
      "</div>" +
      (api.cart.freeDeliveryActive()
        ? '<div class="progress" aria-hidden="true"><div class="progress__bar" style="width:' + prog.percent + '%"></div></div>' +
          '<p class="progress-note mb-2 mt-1">' +
          (prog.remaining > 0
            ? "Add <strong>" + money(prog.remaining) + "</strong> more for free delivery across Rwanda."
            : "<strong>Free delivery unlocked.</strong> Well chosen.") +
          "</p>"
        : "") +
      '<a class="btn btn--gold btn--block" href="checkout.html">' + icon("lock") + "Proceed to checkout</a>" +
      '<p class="text-center mt-2"><a class="link-arrow" href="cart.html">View full cart ' + icon("arrowRight") + "</a></p>";
  }

  /* ───────────────────────────────────────────────── search overlay */
  function renderSearch(term) {
    var host = $("[data-search-results]");
    if (!host) return;
    var q = String(term || "").trim();
    if (!q) {
      host.innerHTML =
        '<p class="search-empty">Search for a product, a brand or a concern — for example “CeraVe”, “sunscreen” or “dark spots”.</p>';
      return;
    }
    var hits = api.searchProducts(q, 8);
    if (!hits.length) {
      host.innerHTML =
        '<p class="search-empty">No products match “' + esc(q) + '”. <a href="' + esc(api.waLink("Hello, I am looking for " + q + ". Do you have it?")) +
        '" target="_blank" rel="noopener">Ask us on WhatsApp</a> — we can often order it in.</p>';
      return;
    }
    host.innerHTML = hits.map(function (p) {
      return (
        '<a class="search-result" href="product.html?id=' + encodeURIComponent(p.id) + '">' +
        '<span class="search-result__thumb"><span class="visual">' + api.productVisual(p, "front") + "</span></span>" +
        '<span class="search-result__meta"><span class="search-result__name">' + esc(p.brand + " " + p.name) + "</span>" +
        '<span class="search-result__sub">' + esc(p.size) + " &middot; " + esc(api.skinTypeLabel((p.skinTypes || [])[0] || "")) + "</span></span>" +
        '<span class="search-result__price">' + money(p.price) + "</span></a>"
      );
    }).join("") +
      '<p class="mt-2"><a class="btn btn--outline btn--sm" href="shop.html?q=' + encodeURIComponent(q) + '">See all results for “' + esc(q) + '”</a></p>';
  }

  /* ─────────────────────────────────────────────────────── live chat */
  var CHAT_START = [
    "Hello 👋 Welcome to Skincare Hub Rwanda. I can help with products, delivery or a routine for your skin.",
    "You can also reach a human advisor on WhatsApp — we answer 9:00 to 21:00 Monday to Saturday, 11:00 to 18:00 on Sunday."
  ];
  var CHAT_QUICK = [
    { label: "Are your products authentic?", q: "authentic" },
    { label: "Delivery in Rwanda", q: "delivery" },
    { label: "Best for acne", q: "acne" },
    { label: "Which sunscreen?", q: "sunscreen" },
    { label: "What is my skin type?", q: "skin type" },
    { label: "Talk to a human", q: "human" }
  ];
  /* Answers are grounded in the site's own FAQ content */
  var CHAT_KB = [
    { keys: ["authentic", "fake", "genuine", "original", "real"], faq: "authentic" },
    { keys: ["delivery", "deliver", "ship", "shipping", "how long", "kigali", "upcountry"], faq: "delivery" },
    { keys: ["acne", "breakout", "pimple", "spots", "blemish"], faq: "acne" },
    { keys: ["sunscreen", "spf", "sun", "white cast"], faq: "sunscreen" },
    { keys: ["pay", "payment", "momo", "mobile money", "card", "airtel", "cash"], faq: "payment" },
    { keys: ["return", "refund", "exchange", "damaged"], faq: "returns" },
    { keys: ["expire", "expiry", "expired", "batch", "old"], faq: "expiry" },
    { keys: ["skin type", "my skin", "oily", "dry", "combination", "sensitive"], faq: "skin-type" },
    { keys: ["man", "men", "male", "mens"], faq: "men" },
    { keys: ["order", "whatsapp order", "buy on whatsapp"], faq: "whatsapp-order" },
    { keys: ["shop", "location", "where", "visit", "open"], faq: "shop" },
    { keys: ["recommend", "routine", "advice", "consult", "quiz"], faq: "recommendations" }
  ];
  function faqById(id) {
    var found = null;
    (SHR.FAQS || []).forEach(function (f) {
      if (f.id === id) found = f;
    });
    return found;
  }
  function chatAnswer(text) {
    var t = String(text || "").toLowerCase();
    if (/human|agent|advisor|person|talk to someone/.test(t)) {
      return "Of course — the fastest way to a real person is WhatsApp: <a href=\"" +
        esc(api.waLink("Hello Skincare Hub Rwanda, I would like to speak to a skincare advisor.")) +
        "\" target=\"_blank\" rel=\"noopener\">open WhatsApp chat</a>. Advisors are online 9:00–21:00 Monday to Saturday, 11:00–18:00 on Sunday.";
    }
    var best = null, bestScore = 0;
    CHAT_KB.forEach(function (entry) {
      var score = 0;
      entry.keys.forEach(function (k) {
        if (t.indexOf(k) >= 0) score += k.length;
      });
      if (score > bestScore) {
        bestScore = score;
        best = entry;
      }
    });
    if (best) {
      var faq = faqById(best.faq);
      if (faq) return "<strong>" + esc(faq.q) + "</strong><br>" + esc(faq.a);
    }
    var products = api.searchProducts(t, 3);
    if (products.length) {
      return "Here is what I found: " + products.map(function (p) {
        return '<a href="product.html?id=' + encodeURIComponent(p.id) + '">' + esc(p.brand + " " + p.name) + "</a> (" + money(p.price) + ")";
      }).join(", ") + ".";
    }
    return "I am not sure I understood that one. Take the <a href=\"quiz.html\">two-minute skin quiz</a> for a full routine, " +
      "or <a href=\"" + esc(api.waLink("Hello, I have a question: " + text)) + "\" target=\"_blank\" rel=\"noopener\">ask an advisor on WhatsApp</a>.";
  }
  function chatSay(who, html) {
    var body = $("[data-chat-body]");
    if (!body) return;
    var node = document.createElement("div");
    node.className = "bubble bubble--" + (who === "me" ? "me" : "bot");
    node.innerHTML = html;
    body.appendChild(node);
    body.scrollTop = body.scrollHeight;
  }
  var chatStarted = false;
  function openChat() {
    var chat = $("#shrChat");
    if (!chat) return;
    var wasOpen = chat.classList.contains("is-open");
    chat.classList.add("is-open");
    if (!wasOpen && !chatStarted) {
      chatStarted = true;
      CHAT_START.forEach(function (line) {
        chatSay("bot", line);
      });
      var quick = $("[data-chat-quick]");
      if (quick) {
        quick.innerHTML = CHAT_QUICK.map(function (q) {
          return '<button class="chip" type="button" data-chat-quick="' + esc(q.q) + '">' + esc(q.label) + "</button>";
        }).join("");
      }
    }
    var input = $("[data-chat-input]");
    if (input && window.matchMedia("(min-width: 700px)").matches) input.focus();
  }
  function closeChat() {
    var chat = $("#shrChat");
    if (chat) chat.classList.remove("is-open");
  }

  /* ─────────────────────────────────────────────── drawer open/close */
  function openDrawer(id) {
    var node = document.getElementById(id);
    if (!node) return;
    node.hidden = false;
    /* force a frame so the transition runs */
    window.requestAnimationFrame(function () {
      node.classList.add("is-open");
    });
    document.body.classList.add("is-locked");
    var focusable = node.querySelector("button, a[href], input, [tabindex]:not([tabindex='-1'])");
    if (focusable) focusable.focus();
    if (id === "cartDrawer") renderCart();
  }
  function closeAll() {
    $$(".drawer.is-open").forEach(function (d) {
      d.classList.remove("is-open");
      setTimeout(function () {
        d.hidden = true;
      }, 380);
    });
    var overlay = $("#searchOverlay");
    if (overlay && !overlay.hidden) {
      overlay.classList.remove("is-open");
      setTimeout(function () {
        overlay.hidden = true;
      }, 320);
    }
    closeQuickView();
    $$(".shop-sidebar.is-open").forEach(function (n) {
      n.classList.remove("is-open");
    });
    $$(".shop-scrim.is-open").forEach(function (n) {
      n.classList.remove("is-open");
    });
    document.body.classList.remove("is-locked");
  }
  function openSearch() {
    var overlay = $("#searchOverlay");
    if (!overlay) return;
    overlay.hidden = false;
    window.requestAnimationFrame(function () {
      overlay.classList.add("is-open");
    });
    document.body.classList.add("is-locked");
    renderSearch("");
    var input = $("[data-search-input]");
    if (input) {
      input.value = "";
      setTimeout(function () {
        input.focus();
      }, 60);
    }
  }

  /* ───────────────────────────────────────────── delegating handlers */
  function wireGlobalClicks() {
    document.addEventListener("click", function (e) {
      var t = e.target;
      if (!t || !t.closest) return;

      var add = t.closest("[data-add]");
      if (add) {
        e.preventDefault();
        api.cart.add(add.getAttribute("data-add"), 1);
        return;
      }
      var wish = t.closest("[data-wish-toggle]");
      if (wish) {
        e.preventDefault();
        var on = api.wish.toggle(wish.getAttribute("data-wish-toggle"));
        var all = $$('[data-wish-toggle="' + wish.getAttribute("data-wish-toggle") + '"]');
        all.forEach(function (b) {
          b.classList.toggle("is-on", on);
          b.setAttribute("aria-pressed", on ? "true" : "false");
        });
        return;
      }
      var rm = t.closest("[data-cart-remove]");
      if (rm) {
        e.preventDefault();
        api.cart.remove(rm.getAttribute("data-cart-remove"));
        return;
      }
      var quick = t.closest("[data-quick-view]");
      if (quick) {
        e.preventDefault();
        openQuickView(quick.getAttribute("data-quick-view"));
        return;
      }
      /* one button adds a whole set — a routine, or the steps around a product */
      var set = t.closest("[data-add-routine-set]");
      if (set) {
        e.preventDefault();
        var ids = String(set.getAttribute("data-add-routine-set") || "").split(",").filter(Boolean);
        if (!ids.length) return;
        ids.forEach(function (id) {
          api.cart.add(id, 1, { silent: true });
        });
        api.toast(ids.length + (ids.length === 1 ? " product" : " products") + " added to your cart", {
          kind: "gold",
          icon: "cart",
          action: { label: "Checkout", href: "checkout.html" }
        });
        return;
      }
      var plus = t.closest("[data-qty-plus]");
      var minus = t.closest("[data-qty-minus]");
      if (plus || minus) {
        e.preventDefault();
        var wrap = (plus || minus).closest("[data-qty]");
        if (!wrap) return;
        var valNode = wrap.querySelector("[data-qty-value]");
        var current = valNode ? parseInt(valNode.textContent, 10) || 1 : 1;
        var final = Math.max(1, Math.min(12, current + (plus ? 1 : -1)));
        var boundId = wrap.getAttribute("data-qty");
        if (boundId) api.cart.setQty(boundId, final);
        else if (valNode) valNode.textContent = final;
        var hidden = wrap.querySelector("[data-qty-input]");
        if (hidden) hidden.value = final;
        wrap.dispatchEvent(new CustomEvent("qty:change", { bubbles: true, detail: { value: final } }));
        return;
      }
      if (t.closest("[data-cart-open]")) {
        e.preventDefault();
        openDrawer("cartDrawer");
        renderCart();
        return;
      }
      if (t.closest("[data-drawer-open='nav']")) {
        e.preventDefault();
        openDrawer("navDrawer");
        return;
      }
      if (t.closest("[data-search-open]")) {
        e.preventDefault();
        openSearch();
        return;
      }
      if (t.closest("[data-close-all]")) {
        e.preventDefault();
        closeAll();
        return;
      }
      if (t.closest("[data-chat-open]")) {
        e.preventDefault();
        openChat();
        return;
      }
      if (t.closest("[data-chat-close]")) {
        e.preventDefault();
        closeChat();
        return;
      }
      var chip = t.closest("[data-search-chip]");
      if (chip) {
        e.preventDefault();
        var input = $("[data-search-input]");
        if (input) input.value = chip.getAttribute("data-search-chip");
        renderSearch(chip.getAttribute("data-search-chip"));
        return;
      }
      var quick = t.closest("[data-chat-quick]");
      if (quick) {
        e.preventDefault();
        var q = quick.getAttribute("data-chat-quick");
        chatSay("me", esc(quick.textContent));
        setTimeout(function () {
          chatSay("bot", chatAnswer(q));
        }, 260);
        return;
      }
      if (t.closest("[data-scroll-top]")) {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
      var filterToggle = t.closest("[data-filters-toggle]");
      if (filterToggle) {
        e.preventDefault();
        var sidebar = $(".shop-sidebar");
        var scrimEl = $(".shop-scrim");
        if (sidebar) sidebar.classList.toggle("is-open");
        if (scrimEl) scrimEl.classList.toggle("is-open");
        return;
      }
    });

    document.addEventListener("input", function (e) {
      if (e.target && e.target.matches("[data-search-input]")) renderSearch(e.target.value);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeAll();
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        openSearch();
      }
    });
  }

  /* ────────────────────────────────────────── chat form + newsletter */
  function wireForms() {
    var chatForm = $("[data-chat-form]");
    if (chatForm) {
      chatForm.addEventListener("submit", function (e) {
        e.preventDefault();
        var input = $("[data-chat-input]");
        var text = input ? input.value.trim() : "";
        if (!text) return;
        chatSay("me", esc(text));
        if (input) input.value = "";
        setTimeout(function () {
          chatSay("bot", chatAnswer(text));
        }, 280);
      });
    }
    $$('[data-form="newsletter"]').forEach(function (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        api.submitForm(form, {
          name: "newsletter",
          intro: "New newsletter subscriber from the website",
          successTitle: "You are on the list.",
          successNote: "We send one email a month — routines, honest product notes and Rwandan skincare tips. No spam, unsubscribe any time."
        });
      });
    });
  }

  /* ────────────────────────────────────────────────── count badges */
  function renderCounts() {
    var c = api.cart.count(), w = api.wish.count();
    $$("[data-cart-count]").forEach(function (n) {
      n.textContent = c;
      n.setAttribute("data-empty", c ? "false" : "true");
    });
    $$("[data-wishlist-count]").forEach(function (n) {
      n.textContent = w;
      n.setAttribute("data-empty", w ? "false" : "true");
    });
    $$("[data-cart-total-inline]").forEach(function (n) {
      n.textContent = money(api.cart.total());
    });
  }

  /* ─────────────────────────────────────────────── reveal on scroll */
  function initReveal() {
    var nodes = $$(".reveal");
    if (!nodes.length) return;
    if (!("IntersectionObserver" in window)) {
      nodes.forEach(function (n) {
        n.classList.add("is-visible");
      });
      return;
    }
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.05 }
    );
    nodes.forEach(function (n) {
      io.observe(n);
    });
  }

  /* ──────────────────────────────────────────────────── carousels */
  function initCarousels(root) {
    $$(root ? "[data-carousel]" : "[data-carousel]", root || document).forEach(function (car) {
      var track = car.querySelector(".carousel__viewport");
      if (!track) return;
      var slideCount = track.children.length;
      /* page controllers inject slides after load, so re-initialise when that changes */
      if (car.getAttribute("data-ready") === "true" && car.getAttribute("data-count") === String(slideCount)) return;
      var prev = car.querySelector("[data-carousel-prev]");
      var next = car.querySelector("[data-carousel-next]");
      var dots = car.querySelector("[data-carousel-dots]");
      car.setAttribute("data-ready", "true");
      car.setAttribute("data-count", String(slideCount));
      var slides = Array.prototype.slice.call(track.children);
      function step() {
        var first = slides[0];
        return first ? first.getBoundingClientRect().width + 20 : 340;
      }
      if (prev) prev.onclick = function (e) { e.preventDefault(); track.scrollBy({ left: -step(), behavior: "smooth" }); };
      if (next) next.onclick = function (e) { e.preventDefault(); track.scrollBy({ left: step(), behavior: "smooth" }); };
      if (dots) {
        dots.innerHTML = slides.map(function (s, i) {
          return '<button type="button" data-carousel-dot="' + i + '" aria-label="Go to review ' + (i + 1) + '"></button>';
        }).join("");
        dots.onclick = function (e) {
          var dot = e.target.closest("[data-carousel-dot]");
          if (!dot) return;
          var i = Number(dot.getAttribute("data-carousel-dot"));
          if (slides[i]) track.scrollTo({ left: slides[i].offsetLeft - track.offsetLeft, behavior: "smooth" });
        };
      }
      function syncDots() {
        if (!dots) return;
        var idx = Math.round(track.scrollLeft / step());
        $$("[data-carousel-dot]", dots).forEach(function (d, i) {
          d.setAttribute("aria-current", i === idx ? "true" : "false");
        });
      }
      track.onscroll = api.debounce(syncDots, 90);
      syncDots();
    });
  }

  /* ───────────────────────────────────────────────── form fields */
  function initFileUploads() {
    $$("[data-upload]").forEach(function (wrap) {
      var input = wrap.querySelector("input[type=file]");
      var list = wrap.parentNode.querySelector("[data-upload-list]");
      if (!input || !list) return;
      var chosen = [];
      wrap.addEventListener("click", function (e) {
        if (e.target === input) return;
        input.click();
      });
      input.addEventListener("change", function () {
        chosen = chosen.concat(Array.prototype.slice.call(input.files || []));
        if (chosen.length > 4) chosen = chosen.slice(0, 4);
        renderFiles();
      });
      function renderFiles() {
        list.innerHTML = chosen.map(function (f, i) {
          var url = "";
          try { url = URL.createObjectURL(f); } catch (err) { url = ""; }
          return (
            '<span class="upload-list__item">' +
            (url ? '<img src="' + url + '" alt="" loading="lazy">' : icon("camera")) +
            "<span>" + esc(f.name.length > 22 ? f.name.slice(0, 20) + "…" : f.name) + "</span>" +
            '<button type="button" data-file-remove="' + i + '" aria-label="Remove ' + esc(f.name) + '">' + icon("close") + "</button></span>"
          );
        }).join("");
      }
      list.addEventListener("click", function (e) {
        var rm = e.target.closest("[data-file-remove]");
        if (!rm) return;
        chosen.splice(Number(rm.getAttribute("data-file-remove")), 1);
        renderFiles();
      });
    });
  }

  /* ─────────────────────────────────── WhatsApp + contact anchors */
  /* What the strip along the top says. It is built from configuration so the
     site can never advertise a delivery promise that has been switched off,
     or claim a payment is taken on the page before a key exists for it. */
  function announceCopy(page) {
    var claims = CONFIG.claims || {};
    var delivery = CONFIG.delivery || {};
    var freeDelivery = claims.freeDeliveryActive !== false && delivery.freeFrom > 0;
    if (page === "checkout") {
      return SHR.pay && SHR.pay.isReady()
        ? "Secure checkout &middot; pay online by card, MTN MoMo or Airtel Money"
        : "Secure checkout &middot; nothing is charged until we confirm your order";
    }
    if (!freeDelivery) return "Authentic skincare, delivered across Rwanda";
    return "🚚 Free delivery on orders above " + money(delivery.freeFrom);
  }

  /* Payment methods are listed from SHR.PAYMENTS, so removing a method the
     shop no longer accepts removes it from the footer with it. While no
     provider key is configured the line says plainly that payment is
     confirmed with the customer first, rather than implying the checkout
     captures a card. */
  function renderPayList() {
    var host = $("[data-pay-list]");
    if (!host) return;
    var live = SHR.pay && SHR.pay.isReady();
    var names = {
      "card": "Visa &amp; Mastercard",
      "mtn-momo": "MTN MoMo",
      "airtel-money": "Airtel Money",
      "momo-pay": "MTN MoMoPay",
      "cod": "Cash on delivery"
    };
    host.innerHTML =
      (SHR.PAYMENTS || []).map(function (m) {
        return "<span>" + (names[m.id] || esc(m.label)) + (m.kind === "online" ? "" : " <em>confirmed first</em>") + "</span>";
      }).join("") +
      (live ? "" : '<span class="pay-list__note">Payment is confirmed with you before any money moves</span>');
  }

  function initWaAnchors() {
    var page = currentPage();
    $$("[data-wa]").forEach(function (a) {
      var msg = a.getAttribute("data-wa");
      a.setAttribute("href", api.waLink(msg && msg !== "true" ? msg : undefined));
      if (!a.getAttribute("target")) {
        a.setAttribute("target", "_blank");
        a.setAttribute("rel", "noopener");
      }
    });
    $$("[data-year]").forEach(function (n) {
      n.textContent = new Date().getFullYear();
    });
    $$("[data-address]").forEach(function (n) {
      n.textContent = CONFIG.address.full;
    });
    $$("[data-phone]").forEach(function (n) {
      n.textContent = CONFIG.whatsappDisplay;
      if (n.tagName === "A") n.setAttribute("href", "tel:" + CONFIG.whatsapp);
    });
    $$("[data-email]").forEach(function (n) {
      if (n.tagName === "A") n.setAttribute("href", "mailto:" + CONFIG.email);
      /* An icon button keeps its icon. Writing the address in as text replaced
         the envelope glyph with a 151px line of text inside a 42px circle, which
         then hung out of the footer on every page; the label screen readers use
         is the aria-label, which is already there. */
      if (!n.classList.contains("icon-btn")) { n.textContent = CONFIG.email; }
    });
    $$("[data-announce-note]").forEach(function (n) {
      n.innerHTML = announceCopy(page);
    });
  }

  /* ───────────────────────────────────────── analytics notice bar */
  function initNotice() {
    if (!CONFIG.analytics.gaMeasurementId) return;
    if (api.store.get("noticeDismissed", false)) return;
    var bar = document.createElement("div");
    bar.className = "notice-bar is-shown";
    bar.innerHTML =
      "<span>We use privacy-friendly analytics to understand which pages help people. <a href=\"policies.html#privacy\">Privacy policy</a></span>" +
      '<button class="btn btn--sm btn--outline" type="button" data-notice-close>Got it</button>';
    document.body.appendChild(bar);
    bar.addEventListener("click", function (e) {
      if (!e.target.closest("[data-notice-close]")) return;
      api.store.set("noticeDismissed", true);
      bar.remove();
    });
  }

  /* ───────────────────────────────────────────────────────── init */
  function init() {
    api.analytics.init();
    var host = overlayHost();
    host.insertAdjacentHTML(
      "beforeend",
      navDrawerHTML() + cartDrawerHTML() + searchOverlayHTML() + floatersHTML() + chatHTML() + quickViewShellHTML() + bottomNavHTML()
    );
    enhanceHeader();
    stickyHeader();
    wireGlobalClicks();
    wireForms();
    initWaAnchors();
    renderPayList();
    initFileUploads();
    initReveal();
    initCarousels();
    initNotice();

    var page = currentPage();
    api.cart.onChange(renderCounts);
    api.wish.onChange(renderCounts);
    api.cart.onChange(renderCart);
    renderCounts();
    renderCart();
    api.analytics.page(page || document.title, { path: window.location.pathname });
  }

  SHR.ui = {
    init: init,
    renderCart: renderCart,
    renderCounts: renderCounts,
    openDrawer: openDrawer,
    closeAll: closeAll,
    openSearch: openSearch,
    openChat: openChat,
    initCarousels: initCarousels,
    initReveal: initReveal,
    refresh: function () {
      initWaAnchors();
      renderPayList();
      initCarousels();
      initReveal();
      $$(".reveal").forEach(function (n) {
        if (n.getBoundingClientRect().top < window.innerHeight) n.classList.add("is-visible");
      });
    }
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
