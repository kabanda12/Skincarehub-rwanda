/* ==========================================================================
   Skincare Hub Rwanda — the products and prices YOU added
   ---------------------------------------------------------------------------
   This file is generated: open tools/product-editor.html in your browser, add
   your products, then press "Download products-own.js" and replace this file
   with the download. Editing it by hand works too, and the shape is the same
   either way — there is a filled-in template at the bottom.

   What happens to it:
     • catalog.js reads this file BEFORE it builds the shop, and merges:
         SHR.OWN_PRODUCTS  your products. An id that matches a product in
                           catalog.js REPLACES it — that is how the price of a
                           product you already sell is changed — and an id that
                           matches nothing is added to the catalogue.
         SHR.OWN_BRANDS    a brand that is not in site-data.js yet.
     • every price is then put through the shop's single 10% discount rule
       (SHR.PRICING in site-data.js): the customer pays `price`, and the list
       price they see struck through is derived from it. You set one price per
       product, never two.

   SHIPPED STATE: 87 products across 16 new brands — the stock that came in
   with the new photography. Every price below is a SUGGESTION set to sit
   alongside the existing catalogue; change any of them in the editor (or right
   here) and the struck-through list price follows automatically.
   ========================================================================== */
window.SHR = window.SHR || {};

/* A brand that is not in site-data.js yet, so your products have somewhere to
   belong. `logo` is optional — a brand without one shows its initials. */
SHR.OWN_BRANDS = [
  { id: "medicube", name: "Medicube", country: "South Korea", logo: "assets/img/brands/medicube.jpg", note: "Seoul dermacosmetics: clinical actives with the device-grade delivery that made the brand famous." },
  { id: "panoxyl", name: "PanOxyl", country: "USA", logo: "assets/img/brands/panoxyl.jpg", note: "The benzoyl peroxide wash dermatologists reach for first when acne needs a real active." },
  { id: "olay", name: "Olay", country: "USA", logo: "assets/img/brands/olay.jpg", note: "Body care built on niacinamide and vitamin C at supermarket prices, in sizes that last." },
  { id: "dr-teals", name: "Dr Teal's", country: "USA", logo: "assets/img/brands/dr-teals.jpg", note: "Epsom-salt bathing and body care built on essential oils — the ritual end of the shelf." },
  { id: "pro-lab", name: "Pro Lab", country: "Imported", logo: "assets/img/brands/pro-lab.jpg", note: "Half-litre pump bottles for the whole body: kojic acid, ceramides and alpha arbutin at family size." },
  { id: "k-secret", name: "K-Secret", country: "South Korea", logo: "assets/img/brands/k-secret.jpg", note: "Seoul 1988 line — encapsulated retinal and fermented black ginseng, packaged without theatre." },
  { id: "skin1004", name: "SKIN1004", country: "South Korea", logo: "assets/img/brands/skin1004.jpg", note: "Madagascar centella, grown and extracted for one job: calming skin that reacts to everything." },
  { id: "celimax", name: "Celimax", country: "South Korea", logo: "assets/img/brands/celimax.jpg", note: "Retinal and peptide boosters at percentages you can actually read on the box." },
  { id: "arencia", name: "Arencia", country: "South Korea", logo: "assets/img/brands/arencia.jpg", note: "Vitamin C in its several forms, stabilised and stacked, for tone that will not shift." },
  { id: "advanced-korean-skin", name: "Advanced Korean Skin", country: "Imported", logo: "assets/img/brands/advanced-korean-skin.jpg", note: "Korean-formula body lotions in half-litre bottles: brightening, moisture and smoothing." },
  { id: "eos", name: "EOS", country: "USA", logo: "assets/img/brands/eos.jpg", note: "Shea Better body lotions — shea butter, seven oils and butters, and a scent you will actually use every day." },
  { id: "vaseline", name: "Vaseline", country: "USA", logo: "assets/img/brands/vaseline.jpg", note: "The everyday body-care shelf: petroleum jelly heritage, Gluta-Hya serums and serious sizes for the price." },
  { id: "mixa", name: "Mixa", country: "France", logo: "assets/img/brands/mixa.jpg", note: "French pharmacy care for very dry and sensitive skin, built on urea, shea butter and niacinamide." },
  { id: "axis-y", name: "AXIS-Y", country: "South Korea", logo: "assets/img/brands/axis-y.jpg", note: "Seoul K-beauty with a dark-spot specialism — niacinamide, willow bark and mineral sunscreen." },
  { id: "garnier", name: "Garnier", country: "France", logo: "assets/img/brands/garnier.jpg", note: "Micellar water and Pure Active acne care: the affordable shelf that actually works." },
  { id: "neutrogena", name: "Neutrogena", country: "USA", logo: "assets/img/brands/neutrogena.jpg", note: "Dermatologist-adjacent basics — the Hydro Boost water gel is the one everybody repurchases." }
];

/* Your products, and your prices. */
SHR.OWN_PRODUCTS = [
  /* ───────────────────────────────────────────────────────────── CeraVe */
  {
    id: "cerave-am-facial-moisturizing-lotion-spf-30",
    photos: ["assets/img/cerave-am-facial-moisturizing-lotion-spf-30.jpg"],
    name: "AM Facial Moisturizing Lotion SPF 30",
    brand: "CeraVe",
    brandId: "cerave",
    price: 34000,
    size: "89 ml",
    form: "pump",
    tint: "#2e6fa8",
    category: "moisturizers",
    also: ["sunscreens"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["dryness", "dullness"],
    rating: 4.8,
    reviewCount: 46,
    texture: "Lightweight lotion with sunscreen",
    short:
      "The morning half of CeraVe's pair: three ceramides and hyaluronic acid under a broad-spectrum SPF 30, in an oil-free lotion that sinks in without a white cast.",
    benefits: [
      "SPF 30 broad-spectrum protection in the moisturiser itself, so the step that gets skipped is the one that is already done",
      "Ceramides NP, AP and EOP top up the barrier that sun and air conditioning wear down",
      "Niacinamide calms redness and evens tone while the sunscreen does its work",
      "Oil-free and non-comedogenic — it does not turn a combination T-zone into a shine by noon"
    ],
    ingredients: [
      { name: "Broad-spectrum UV filters (SPF 30)", role: "Absorb and scatter UVA and UVB before it reaches the skin" },
      { name: "Ceramides NP, AP, EOP", role: "Replace the lipids the barrier loses fastest" },
      { name: "Niacinamide", role: "Calms redness and evens tone over weeks" },
      { name: "Hyaluronic acid", role: "Holds water in the upper layers so the lotion never feels tight" }
    ],
    directions:
      "Apply two finger-lengths to the face and neck every morning as the last step before makeup. Reapply at midday if you are outdoors — one application gives you the SPF number on the pack only if the amount is right.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "One bottle, one step, no white film on my skin. I stopped buying a separate sunscreen for office days." },
      { who: "Olivier N.", city: "Huye", rating: 4.5, date: "February 2026", text: "It is light enough to wear under a mask all day. For a long day in the sun I still take the 50+." }
    ],
    faqs: [
      { q: "Is SPF 30 enough in Kigali?", a: "For a commute, an office day and the walk home, yes — provided you apply enough and top it up at midday. If you are outside for hours, at altitude or on the lake, use a dedicated SPF 50+ like Anthelios UVMune 400 and keep this as your moisturiser." },
      { q: "Will it pill under makeup?", a: "It should not. Give it two minutes to set before foundation, and do not rub — press." }
    ]
  },
  {
    id: "cerave-pm-facial-moisturizing-lotion",
    photos: ["assets/img/cerave-pm-facial-moisturizing-lotion.jpg"],
    name: "PM Facial Moisturizing Lotion",
    brand: "CeraVe",
    brandId: "cerave",
    price: 32000,
    size: "89 ml",
    form: "pump",
    tint: "#2e6fa8",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "sensitive", "combination", "oily"],
    concerns: ["dryness", "sensitivity", "dullness"],
    rating: 4.9,
    reviewCount: 52,
    texture: "Ultra-lightweight lotion",
    short:
      "The night half: the same ceramides and niacinamide as the morning lotion, with no sunscreen in the way, in a texture light enough for oily skin to wear under a fan.",
    benefits: [
      "Niacinamide at a comfortable strength works on tone and redness through the night, when nothing is competing with it",
      "Ceramides repair the barrier overnight — the eight hours when the skin is actually rebuilding",
      "Ultra-light and oil-free, so it does not feel like a mask in a warm room",
      "Fragrance-free and non-comedogenic, which is what makes it safe to use alongside acids and retinoids"
    ],
    ingredients: [
      { name: "Niacinamide", role: "Evens tone, calms redness and supports the barrier" },
      { name: "Ceramides NP, AP, EOP", role: "Rebuild the lipid barrier that holds water in" },
      { name: "Hyaluronic acid", role: "Draws water into the upper layers while you sleep" },
      { name: "MVE delivery technology", role: "Releases the moisturising ingredients slowly across the night" }
    ],
    directions:
      "Apply to clean skin at night, on the face and neck, after any serum or treatment. If you use a retinoid, apply that first, wait two minutes, then this. In the morning follow with the AM lotion.",
    reviews: [
      { who: "Diane U.", city: "Nyarugenge, Kigali", rating: 5, date: "February 2026", text: "It is the only night cream my oily skin tolerates. I wake up matte, not greasy, and my cheeks are not tight." },
      { who: "Fabrice K.", city: "Rwamagana", rating: 5, date: "January 2026", text: "I pair it with the 2% BHA twice a week and the flaking I used to get is gone." }
    ],
    faqs: [
      { q: "Can I use it in the morning too?", a: "You can, but it has no sunscreen, so you would have to add one on top. The AM lotion exists to save you that step." },
      { q: "Is it rich enough for dry skin in the dry season?", a: "For many people, yes. If your skin still feels tight, use the CeraVe Moisturizing Cream at night instead and keep this for daytime." }
    ]
  },
  {
    id: "cerave-blemish-control-cleanser",
    photos: ["assets/img/cerave-blemish-control-cleanser.jpg"],
    name: "Blemish Control Cleanser",
    brand: "CeraVe",
    brandId: "cerave",
    price: 38000,
    size: "473 ml",
    form: "pump",
    tint: "#2e6fa8",
    category: "cleansers",
    also: ["acne-care"],
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["oily", "combination", "normal"],
    concerns: ["acne", "oiliness", "large-pores", "post-acne-marks"],
    rating: 4.7,
    reviewCount: 38,
    texture: "Gel, lightly foaming",
    short:
      "Salicylic acid and oil-absorbing clay in a foaming gel that clears the day's oil without the tight, stripped feeling that makes oily skin produce more.",
    benefits: [
      "Salicylic acid gets into the pore lining, where blackheads and the seeds of breakouts actually sit",
      "Oil-absorbing technology and clay lift the shine that a plain cleanser leaves behind",
      "Three ceramides are there so the barrier does not pay for the exfoliation",
      "The half-litre pump lasts about four months at twice a day — the cheapest step in an acne routine"
    ],
    ingredients: [
      { name: "Salicylic acid", role: "Exfoliates inside the pore to unclog blackheads and prevent new blemishes" },
      { name: "Oil-absorbing clay", role: "Lifts surface oil and keeps the finish matte" },
      { name: "Ceramides NP, AP, EOP", role: "Protect the barrier while the acid works" },
      { name: "Niacinamide", role: "Calms the redness left by old spots" }
    ],
    directions:
      "Massage onto damp skin morning and evening, leave for thirty seconds so the salicylic acid has time to work, then rinse. If your skin is new to acids, start once a day. Always follow with sunscreen in the morning.",
    reviews: [
      { who: "Patrick H.", city: "Nyarugenge, Kigali", rating: 5, date: "March 2026", text: "Two weeks and the blackheads on my nose are visibly fewer. It does not leave my face squeaking like soap does." },
      { who: "Sandrine B.", city: "Muhanga", rating: 4, date: "December 2025", text: "Good for my chin and forehead, a little drying on the cheeks, so I use it once a day and a gentle cleanser at night." }
    ],
    faqs: [
      { q: "Can I use it with retinol or benzoyl peroxide?", a: "Yes, but stagger them: cleanser in the morning, retinol at night, and do not stack salicylic acid with PanOxyl's 10% benzoyl peroxide in the same routine until your skin has adjusted to each separately." },
      { q: "Will it clear my acne on its own?", a: "It will help with blackheads and mild congestion. Inflammatory acne usually needs a leave-on active — benzoyl peroxide, adapalene or azelaic acid — not just a wash." }
    ]
  },
  {
    id: "cerave-oil-control-gel-cream-moisturizer",
    photos: ["assets/img/cerave-oil-control-gel-cream-moisturizer.jpg"],
    name: "Oil Control Moisturizing Gel-Cream",
    brand: "CeraVe",
    brandId: "cerave",
    price: 32000,
    size: "52 ml",
    form: "jar",
    tint: "#2e6fa8",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination"],
    concerns: ["oiliness", "large-pores", "acne"],
    rating: 4.7,
    reviewCount: 29,
    texture: "Cooling gel-cream",
    short:
      "A gel-cream for skin that needs water but not oil: ceramides and niacinamide in a base that absorbs in seconds and keeps the T-zone matte for hours.",
    benefits: [
      "Rebalances oily skin — hydration without the occlusive film that makes it greasy by midday",
      "Three ceramides plus niacinamide keep the barrier intact, which is what stops oily skin from over-producing",
      "Gel texture is genuinely comfortable in Kigali heat, so you will actually use it twice a day",
      "Sits under sunscreen and makeup without pilling or sliding"
    ],
    ingredients: [
      { name: "Niacinamide", role: "Regulates oil, refines pores and evens tone" },
      { name: "Ceramides NP, AP, EOP", role: "Replace the barrier lipids that over-cleansing strips out" },
      { name: "Hyaluronic acid", role: "Hydrates without adding any oil to the formula" },
      { name: "Silica and mattifying powders", role: "Blot surface shine through the day" }
    ],
    directions:
      "Smooth a pea-sized amount over clean skin morning and evening, on its own or after serum. Use less than you think you need — the gel spreads far. Follow with sunscreen in the morning.",
    reviews: [
      { who: "Yvette A.", city: "Kicukiro, Kigali", rating: 5, date: "February 2026", text: "First moisturiser that does not make my face shiny an hour later. My makeup stays put." },
      { who: "Emmanuel R.", city: "Musanze", rating: 4.5, date: "January 2026", text: "Feels like nothing on the skin, which is what I wanted. On cold nights I use a richer cream instead." }
    ],
    faqs: [
      { q: "Is a gel enough for dehydrated oily skin?", a: "Yes — dehydration is a lack of water, not oil, and this delivers water. If your skin is tight after cleansing, add a hydrating serum under it rather than a heavier cream." },
      { q: "Can I use it over a serum?", a: "Yes. Apply the serum first, let it sink for a minute, then this. In the morning finish with sunscreen." }
    ]
  },

  /* ─────────────────────────────────────────────────────────────── Anua */
  {
    id: "anua-azelaic-acid-10-hyaluron-serum",
    photos: ["assets/img/anua-azelaic-acid-10-hyaluron-serum.jpg"],
    name: "Azelaic Acid 10 + Hyaluron Redness Soothing Serum",
    brand: "Anua",
    brandId: "anua",
    price: 44000,
    size: "30 ml",
    form: "dropper",
    tint: "#6f8f6a",
    category: "serums",
    also: ["korean-skincare", "acne-care"],
    collections: ["new-arrivals"],
    skinTypes: ["sensitive", "oily", "combination", "normal", "dry"],
    concerns: ["acne", "post-acne-marks", "sensitivity", "dark-spots", "dullness"],
    rating: 4.8,
    reviewCount: 41,
    texture: "Light, slightly milky serum",
    short:
      "Ten per cent azelaic acid with hyaluronic acid: the one active that treats acne and post-acne marks at the same time, buffered so it does not sting on reactive skin.",
    benefits: [
      "10% azelaic acid is strong enough to work on papules and old marks, and gentler than the retinoids you would otherwise reach for",
      "Hyaluronic acid and panthenol sit in the same bottle, so the usual azelaic tingle does not turn into dryness",
      "Targets the two things acne leaves behind — active spots and the brown marks after them",
      "Safe in pregnancy and safe alongside sunscreen, which is unusual for a resurfacing active"
    ],
    ingredients: [
      { name: "Azelaic acid 10%", role: "Antibacterial and anti-inflammatory in the pore, and slows the pigment left by old spots" },
      { name: "Hyaluronic acid", role: "Keeps the serum hydrating rather than drying" },
      { name: "Panthenol (provitamin B5)", role: "Calms the sting and supports healing" },
      { name: "Allantoin", role: "Soothes irritation and softens the skin's surface" }
    ],
    directions:
      "Three to four drops on clean skin, morning or evening — start with evenings only for the first two weeks. Follow with moisturiser, and with sunscreen every morning, because the marks will not fade if the sun keeps re-darkening them.",
    reviews: [
      { who: "Aline U.", city: "Nyarugenge, Kigali", rating: 5, date: "March 2026", text: "My jawline spots settled in about three weeks and the marks are fading now. It tingles for a minute, then nothing." },
      { who: "Jean-Bosco M.", city: "Nyamirambo, Kigali", rating: 4.5, date: "February 2026", text: "Better than the 10% azelaic I used before — this one does not dry the corners of my mouth." }
    ],
    faqs: [
      { q: "Can I use it with niacinamide or vitamin C?", a: "Yes, both. Azelaic acid layers well with niacinamide and with vitamin C in the morning. Introduce it slowly and keep the rest of the routine boring for a fortnight." },
      { q: "Why does it tingle?", a: "Azelaic acid at 10% nearly always tingles for the first minute or two, especially on damp skin. Apply to dry skin and use less if it is more than a tingle." }
    ]
  },
  {
    id: "anua-heartleaf-quercetinol-pore-cleansing-foam",
    photos: ["assets/img/anua-cleansing-foam.jpg"],
    name: "Heartleaf Quercetinol Pore Deep Cleansing Foam",
    brand: "Anua",
    brandId: "anua",
    price: 28000,
    size: "150 ml",
    form: "tube",
    tint: "#6f8f6a",
    category: "cleansers",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination", "normal", "sensitive"],
    concerns: ["large-pores", "oiliness", "acne"],
    rating: 4.7,
    reviewCount: 34,
    texture: "Dense cream foam",
    short:
      "A heartleaf foam with a gentle dose of BHA that gets into the pores around the nose without leaving the rest of the face tight.",
    benefits: [
      "Heartleaf extract is there to calm the redness that comes with cleansing congested skin",
      "BHA loosens the oil and dead cells packed into visible pores, which is what makes them look smaller",
      "Foams into a dense lather from a small amount, so 150 ml lasts months",
      "Lowers the chance of that stripped, squeaky feeling that pushes oily skin to produce more"
    ],
    ingredients: [
      { name: "Heartleaf (Houttuynia cordata) extract", role: "Calms redness and irritation" },
      { name: "Salicylic acid (BHA)", role: "Clears oil and dead cells out of the pore" },
      { name: "Quercetinol", role: "Anua's pore-focused antioxidant complex" },
      { name: "Glycerin", role: "Keeps the foam from drying the skin out as it cleans" }
    ],
    directions:
      "Squeeze a small amount into wet hands, work up a lather, massage over the face for twenty to thirty seconds — concentrating on the nose and chin — and rinse with lukewarm water. Use morning and evening.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 5, date: "February 2026", text: "The pores on my nose look cleaner after a week. It foams beautifully and does not sting my eyes." },
      { who: "Samuel T.", city: "Rubavu", rating: 4, date: "January 2026", text: "A little goes far. In the dry season I use it once a day, because twice leaves my cheeks dry." }
    ],
    faqs: [
      { q: "Will it remove sunscreen?", a: "It will shift most daily sunscreens, but if you wear a water-resistant SPF or heavy makeup, an oil cleanser first is kinder to the skin than lathering twice." },
      { q: "Is it for acne or just for pores?", a: "Both, at the mild end. It is a pore-focused daily cleanser; if you have inflamed acne, add a leave-on treatment rather than a stronger wash." }
    ]
  },

  /* ────────────────────────────────────────────────────────────── COSRX */
  {
    id: "cosrx-advanced-snail-92-all-in-one-cream",
    photos: ["assets/img/cosrx-advanced-snail-92-all-in-one-cream.jpg"],
    name: "Advanced Snail 92 All In One Cream",
    brand: "COSRX",
    brandId: "cosrx",
    price: 34000,
    size: "100 g",
    form: "jar",
    tint: "#9aa7b3",
    category: "moisturizers",
    also: ["korean-skincare"],
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["dry", "normal", "combination", "sensitive", "oily"],
    concerns: ["dryness", "post-acne-marks", "sensitivity", "dullness"],
    rating: 4.8,
    reviewCount: 57,
    texture: "Stretchy snail-mucin gel",
    short:
      "92% snail secretion filtrate in a gel cream that repairs and hydrates without a drop of added fragrance — the K-beauty answer to a barrier that needs feeding, not stripping.",
    benefits: [
      "92% snail mucin, which is rich in glycoproteins and hyaluronic acid, holds water in the skin far longer than glycerin alone",
      "Noticeably helps the healing of post-acne marks and the flaking from retinoids or acids",
      "No added fragrance or essential oil, so nothing in it is likely to react",
      "One jar covers the morning and evening moisturiser step, and the texture suits oily skin in heat as well as dry skin",
      "The 100 g jar lasts around three months at twice a day"
    ],
    ingredients: [
      { name: "Snail secretion filtrate 92%", role: "Repairs, hydrates and supports the healing of marks" },
      { name: "Betaine", role: "Humectant that keeps the skin comfortable" },
      { name: "Sodium hyaluronate", role: "Draws and holds water in the upper layers" },
      { name: "Allantoin", role: "Soothes and softens irritated skin" }
    ],
    directions:
      "Take a small amount on clean skin morning and evening and pat it in rather than rubbing — it is tacky until it settles. Layer it under a cream if your skin is very dry, or use it alone in warm weather.",
    reviews: [
      { who: "Marie-Claire N.", city: "Kiyovu, Kigali", rating: 5, date: "March 2026", text: "It healed the flaking from my retinoid in four days. Sticky for the first minute, then your skin just feels plump." },
      { who: "Ivan S.", city: "Kigali", rating: 4.5, date: "December 2025", text: "I did not believe the texture on the first night. Six weeks later my skin is calmer and the marks from last year are lighter." }
    ],
    faqs: [
      { q: "Is it sticky?", a: "Yes, while wet — that is the mucin. Pat it in and give it a minute; the tack disappears. If you hate the feeling, use it at night only." },
      { q: "Is it safe for eczema or very reactive skin?", a: "It is fragrance-free and has a short ingredient list, so many reactive skins get on with it. Patch test on the inner arm for two nights first anyway." }
    ]
  },
  {
    id: "cosrx-hyaluronic-acid-intensive-cream",
    photos: ["assets/img/cosrx-hyaluronic-acid-intensive-cream.jpg"],
    name: "Hyaluronic Acid Intensive Cream",
    brand: "COSRX",
    brandId: "cosrx",
    price: 32000,
    size: "100 g",
    form: "jar",
    tint: "#9aa7b3",
    category: "moisturizers",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "sensitive", "combination"],
    concerns: ["dryness", "sensitivity", "dullness"],
    rating: 4.6,
    reviewCount: 31,
    texture: "Rich but light cream",
    short:
      "Hyaluronic acid in a cream that behaves like a drink of water: it plumps dehydrated skin on contact and keeps it there through an air-conditioned night.",
    benefits: [
      "Targets dehydration specifically — the tightness and fine crepey lines that show up even in oily skin",
      "Layers over serums without pilling, so it works as the sealing step of a longer routine",
      "Comfortable enough for dry skin in the dry season, light enough that combination skin can wear it daily",
      "Fragrance-free, which keeps the ingredient list short and the reaction risk low"
    ],
    ingredients: [
      { name: "Hyaluronic acid", role: "Attracts and holds water in the upper layers of the skin" },
      { name: "Sodium hyaluronate", role: "A smaller molecule that carries hydration deeper" },
      { name: "Panthenol (provitamin B5)", role: "Calms and supports the barrier while it hydrates" },
      { name: "Glycerin", role: "Pulls water into the skin and holds it there" }
    ],
    directions:
      "Apply to slightly damp skin morning and evening, after serum. On very dry skin, seal it with a drop of face oil at night. In the morning follow with sunscreen.",
    reviews: [
      { who: "Gloria M.", city: "Gikondo, Kigali", rating: 5, date: "February 2026", text: "My skin drinks it. The tight feeling after washing is gone by the time I finish getting dressed." },
      { who: "Thierry B.", city: "Musanze", rating: 4, date: "January 2026", text: "In Musanze cold it is perfect at night. In the day I use something lighter." }
    ],
    faqs: [
      { q: "Hyaluronic acid cream or snail cream?", a: "Choose this if dehydration is the problem — tightness, dullness, fine lines. Choose the snail cream if your skin is healing, flaking or reacting, or if you want a fragrance-free all-rounder." },
      { q: "Do I need to apply it to damp skin?", a: "Yes, it works better. Hyaluronic acid holds water; if there is none on the surface to hold, it can leave the skin feeling tighter." }
    ]
  },

  /* ──────────────────────────────────────────────────────────── Medicube */
  {
    id: "medicube-zero-pore-pad",
    photos: ["assets/img/medicube-zero-pore-pads.jpg"],
    name: "Zero Pore Pad",
    brand: "Medicube",
    brandId: "medicube",
    price: 36000,
    size: "70 pads / 155 g",
    form: "jar",
    tint: "#c9a2b4",
    category: "toners",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination", "normal"],
    concerns: ["large-pores", "oiliness", "dullness", "acne"],
    rating: 4.7,
    reviewCount: 36,
    texture: "Soaked exfoliating toner pads",
    short:
      "Seventy presoaked pads with AHA and BHA: a swipe of exfoliation and a swipe of hydration in one step, which is the whole reason toner pads took over Korean shelves.",
    benefits: [
      "AHA lifts the dead surface cells that make skin look grey; BHA follows into the pore to clear the oil",
      "Panthenol, allantoin and sodium hyaluronate are in the same liquid, so the exfoliation does not leave the skin tight",
      "The textured side buffs, the smooth side hydrates — one pad, two jobs, no cotton wool and no guessing at the dose",
      "Seventy pads means an even, measured amount every time, which is how you avoid over-exfoliating"
    ],
    ingredients: [
      { name: "AHA (alpha hydroxy acids)", role: "Dissolve dead cells on the surface for a smoother finish" },
      { name: "BHA (salicylic acid)", role: "Clears oil and congestion from inside the pore" },
      { name: "Panthenol and allantoin", role: "Calm the skin and buffer the acids" },
      { name: "Sodium hyaluronate", role: "Puts water back immediately after exfoliating" }
    ],
    directions:
      "After cleansing, swipe the textured side across the face once, avoiding the eye area, then turn the pad over and pat the smooth side in. Use in the evening, three or four nights a week at first. Sunscreen every morning is not optional.",
    reviews: [
      { who: "Yvonne H.", city: "Nyarutarama, Kigali", rating: 5, date: "March 2026", text: "The blackheads on my nose and the little bumps on my forehead went quiet in two weeks. No sting at all." },
      { who: "Didier M.", city: "Kigali", rating: 4.5, date: "February 2026", text: "Easy to dose, which is why I like it. I use one pad three nights a week and my skin has never looked smoother." }
    ],
    faqs: [
      { q: "Can I use one every night?", a: "Start three to four nights a week and see. Daily AHA and BHA suits some oily skins and is too much for others; dryness or stinging means pull back." },
      { q: "Do these replace a toner and an exfoliant?", a: "They replace both for most people. Do not stack them with a separate glycolic or salicylic acid in the same routine." }
    ]
  },
  {
    id: "medicube-zero-pore-blackhead-cleansing-oil",
    photos: ["assets/img/medicube-zero-pore-blackhead-deep-cleansing-oil.jpg"],
    name: "Zero Pore Blackhead Deep Cleansing Oil",
    brand: "Medicube",
    brandId: "medicube",
    price: 38000,
    size: "205 ml",
    form: "pump",
    tint: "#c9a2b4",
    category: "cleansers",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination", "normal", "dry"],
    concerns: ["large-pores", "oiliness", "acne"],
    rating: 4.6,
    reviewCount: 27,
    texture: "Light cleansing oil",
    short:
      "A soybean-oil cleanser that dissolves sunscreen, sebum and the grit packed into blackheads, then rinses clean — the first step of the double cleanse done properly.",
    benefits: [
      "Oil dissolves oil: it lifts the sebum plugs behind blackheads in a way no water-based cleanser can",
      "Takes off sunscreen and long-wear makeup completely, so the second cleanse is cleaning skin rather than residue",
      "Niacinamide at 1% works on the pore and the oil while the cleansing is happening",
      "Emulsifies fully with water, so it rinses without the film that puts people off cleansing oils"
    ],
    ingredients: [
      { name: "Soybean oil", role: "The base that dissolves sunscreen, sebum and makeup" },
      { name: "Niacinamide 1%", role: "Refines pores and regulates oil over time" },
      { name: "Emulsifiers", role: "Let the oil turn milky and rinse away with water" },
      { name: "Plant-derived oils", role: "Keep the skin comfortable rather than stripped" }
    ],
    directions:
      "On dry skin, with dry hands, massage two pumps over the face for thirty seconds — longer on the nose — then add a little water to emulsify until it turns milky and rinse. Follow with a water-based cleanser. Use in the evening.",
    reviews: [
      { who: "Aurore K.", city: "Kibagabaga, Kigali", rating: 5, date: "February 2026", text: "Grit comes out of my nose when I massage it. I did not know that was possible without a spa." },
      { who: "Patrick N.", city: "Huye", rating: 4, date: "January 2026", text: "Rinses cleanly and does not break me out. It is an extra step, but my sunscreen comes off properly now." }
    ],
    faqs: [
      { q: "Will an oil cleanser make my oily skin worse?", a: "No — oil cleansers remove oil, and because it rinses away completely it does not leave the residue that a cream cleanser can. Oily skin usually has the most to gain, because it has the most sunscreen and sebum to shift." },
      { q: "Do I still need a second cleanser?", a: "Yes. The oil takes off the oil-soluble layer; a water-based cleanser takes off what is left. That is the double cleanse." }
    ]
  },
  {
    id: "medicube-collagen-night-wrapping-mask",
    photos: ["assets/img/medicube-collagen-night-wrapping-mask.jpg"],
    name: "Collagen Night Wrapping Mask",
    brand: "Medicube",
    brandId: "medicube",
    price: 42000,
    size: "35 ml",
    form: "jar",
    tint: "#d98a9c",
    category: "moisturizers",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dryness", "fine-lines", "dullness", "sensitivity"],
    rating: 4.7,
    reviewCount: 22,
    texture: "Thick, film-forming gel balm",
    short:
      "A leave-on collagen mask that sets into a light film overnight, so the water you put on at ten o'clock is still there at six.",
    benefits: [
      "The wrapping film slows water loss across the night, which is when the skin loses the most moisture",
      "Collagen extract and peptides support firmness and the look of fine lines over weeks, not overnight",
      "Wakes up dehydrated, over-treated skin — the tightening after acids or a long flight",
      "You can sleep in it, so it does not depend on you finding twenty free minutes"
    ],
    ingredients: [
      { name: "Collagen extract", role: "Conditions and supports the look of firmness" },
      { name: "Peptides", role: "Support the skin's own collagen and elasticity" },
      { name: "Hyaluronic acid", role: "Holds water under the film all night" },
      { name: "Film-forming polymers", role: "Create the wrap that keeps water in until morning" }
    ],
    directions:
      "As the last step at night, after moisturiser, apply a thin layer over the face and leave it on until morning. Two or three nights a week is enough; use it more often after sun, acids or a long flight. Rinse with lukewarm water in the morning.",
    reviews: [
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "I use it the night after my acid pads and wake up looking like I did not. The film is thin, not sticky." },
      { who: "Eric M.", city: "Kigali", rating: 4, date: "February 2026", text: "First night I used too much and it felt like a mask. A thin layer is the trick." }
    ],
    faqs: [
      { q: "Is this a sheet mask?", a: "No. It is a jar of gel you apply like a last-step cream and sleep in. Sheet masks are the twenty-minute version of the same idea." },
      { q: "Can I use it on top of retinol?", a: "Yes, it is one of the better things to put over a retinoid — apply the retinol, wait, then this. It reduces the flaking without diluting the active." }
    ]
  },
  {
    id: "medicube-txa-niacinamide-capsule-cream",
    photos: ["assets/img/medicube-txa-niacinamide-capsule-cream.jpg"],
    name: "TXA Niacinamide Capsule Cream",
    brand: "Medicube",
    brandId: "medicube",
    price: 48000,
    size: "55 g",
    form: "jar",
    tint: "#c9a2b4",
    category: "moisturizers",
    also: ["korean-skincare", "hyperpigmentation"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "combination", "oily", "dry", "sensitive"],
    concerns: ["dark-spots", "post-acne-marks", "hyperpigmentation", "dullness"],
    rating: 4.8,
    reviewCount: 24,
    texture: "Gel cream with visible capsules",
    short:
      "Tranexamic acid and 5% niacinamide in a gel cream with burst-on-contact capsules: a brightening moisturiser for marks that have stopped responding to everything else.",
    benefits: [
      "Tranexamic acid is the ingredient that finally moves melasma and stubborn post-acne marks, and it does it without irritation",
      "5% niacinamide works the same problem from the other side — tone, redness and the barrier at once",
      "The capsules burst as you apply, so the brightening actives arrive fresh rather than having sat dissolved in the base",
      "Gentle enough for daily use, unlike hydroquinone, and safe to layer under sunscreen every morning"
    ],
    ingredients: [
      { name: "Tranexamic acid (TXA)", role: "Interrupts the pigment signalling that keeps dark marks from fading" },
      { name: "Niacinamide 5%", role: "Evens tone, calms redness and strengthens the barrier" },
      { name: "Vitamin E capsules", role: "Antioxidant support, released as the cream is worked in" },
      { name: "Squalane", role: "Keeps the cream comfortable without making it heavy" }
    ],
    directions:
      "Apply morning and evening to clean skin, pressing the capsules in until they disappear. Follow with sunscreen every morning — a brightening cream without daily SPF is money spent re-fading the same mark.",
    reviews: [
      { who: "Josiane B.", city: "Nyarugenge, Kigali", rating: 5, date: "March 2026", text: "The marks on my cheekbones from two years ago are actually lighter. I use it morning and night and I never skip sunscreen." },
      { who: "Sandrine M.", city: "Kacyiru, Kigali", rating: 4.5, date: "February 2026", text: "No stinging, no peeling, just slow even progress. I noticed at six weeks in a photo, not before." }
    ],
    faqs: [
      { q: "How is this different from the Anua azelaic serum?", a: "Azelaic acid treats active acne and the marks it leaves. Tranexamic acid is aimed squarely at pigmentation — melasma, sun marks, old acne marks that have gone brown. If your problem is spots, use azelaic; if it is colour, use this." },
      { q: "Can I use both?", a: "Yes. Azelaic in the morning, this at night, is a sensible pairing. Introduce them two weeks apart." }
    ]
  },
  {
    id: "medicube-deep-vita-c-capsule-cream",
    photos: ["assets/img/medicube-vitamin-c-cream.jpg"],
    name: "Deep Vita C Capsule Cream",
    brand: "Medicube",
    brandId: "medicube",
    price: 46000,
    size: "55 g",
    form: "jar",
    tint: "#e0a35c",
    category: "moisturizers",
    also: ["korean-skincare", "hyperpigmentation"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "combination", "oily", "dry"],
    concerns: ["dullness", "dark-spots", "hyperpigmentation", "post-acne-marks"],
    rating: 4.7,
    reviewCount: 19,
    texture: "Cream with vitamin capsules",
    short:
      "Vitamin C in a stabilised cream rather than a serum: 50% vitamin water, vitamin C derivatives and 5% niacinamide, for skin that wants the glow without the sting of a 15% ascorbic serum.",
    benefits: [
      "Gives you vitamin C at a strength most skins tolerate daily — the derivative is gentler than pure ascorbic acid and far more stable in a warm room",
      "5% niacinamide alongside it brightens and calms at the same time",
      "A cream, so it doubles as your moisturiser: one step for glow and hydration instead of a serum plus a cream",
      "The capsules keep the vitamin C away from light and air until you press them in, which is the whole problem with vitamin C in a dropper"
    ],
    ingredients: [
      { name: "Vitamin water 50%", role: "The hydrating base that carries the actives" },
      { name: "Vitamin C derivatives", role: "Brighten tone and defend against the day's oxidation" },
      { name: "Niacinamide 5%", role: "Evens tone and supports the barrier" },
      { name: "Vitamin E capsules", role: "Stabilise the vitamin C and add antioxidant cover" }
    ],
    directions:
      "Apply in the morning to clean skin as your moisturising step, pressing the capsules in. Follow with sunscreen. If your skin is sensitive, start with evenings only for a week.",
    reviews: [
      { who: "Aline M.", city: "Kibagabaga, Kigali", rating: 5, date: "March 2026", text: "My face looks less tired in photos. It also does not turn orange or smell like metal, which is why I stopped buying vitamin C serums." },
      { who: "Thierry B.", city: "Musanze", rating: 4.5, date: "January 2026", text: "Nice texture, no sting at all. I use it in the day under the CeraVe SPF and it layers fine." }
    ],
    faqs: [
      { q: "Vitamin C serum or this cream?", a: "A 10-15% ascorbic serum is stronger and faster if your skin tolerates it, and it is the better choice for established pigmentation. This cream is for daily use without irritation, and for anyone who found serums too stingy or too unstable in the heat." },
      { q: "Can I use it with the TXA cream?", a: "Yes — vitamin C in the morning, TXA at night. Both want you to wear sunscreen every day." }
    ]
  },

  /* ───────────────────────────────────────────────────────────── PanOxyl */
  {
    id: "panoxyl-10-acne-foaming-wash",
    photos: ["assets/img/panoxyl-10-acne-foaming-wash.jpg"],
    name: "Acne Foaming Wash 10%",
    brand: "PanOxyl",
    brandId: "panoxyl",
    price: 26000,
    size: "156 g",
    form: "tube",
    tint: "#1f6fb2",
    category: "cleansers",
    also: ["acne-care"],
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["oily", "combination", "normal"],
    concerns: ["acne", "oiliness", "large-pores"],
    rating: 4.6,
    reviewCount: 33,
    texture: "Foaming wash",
    short:
      "Maximum-strength 10% benzoyl peroxide wash for face, chest and back — the treatment dermatologists start with when over-the-counter washes have already failed.",
    benefits: [
      "10% benzoyl peroxide kills the bacteria behind inflammatory acne, which salicylic acid and tea tree do not",
      "Strong enough for body acne — chest, shoulders and back, where a leave-on cream is impractical",
      "Rinses off, so it is better tolerated than a 10% leave-on gel that sits on the skin all day",
      "A short contact time of one to two minutes is all it needs to work"
    ],
    ingredients: [
      { name: "Benzoyl peroxide 10%", role: "Kills the acne bacteria and reduces inflammation in the pore" },
      { name: "Glycerin", role: "Keeps the wash from drying the skin out completely" },
      { name: "Cleansing surfactants", role: "Lift oil and dead cells so the peroxide reaches the pore" },
      { name: "Soothing agents", role: "Buffer the drying effect benzoyl peroxide is known for" }
    ],
    directions:
      "Wet the area, apply a thin layer, leave it for one to two minutes, then rinse thoroughly and pat dry. Use once a day to start, working up to twice if your skin tolerates it. It bleaches fabric — use a white towel and a white pillowcase while you are on it.",
    reviews: [
      { who: "Patrick H.", city: "Nyarugenge, Kigali", rating: 5, date: "February 2026", text: "The only thing that cleared my back. Two weeks of using it in the shower and the spots stopped coming back." },
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4, date: "January 2026", text: "Works, but it dried my chin badly at first. Using it once a day and moisturising after sorted that." }
    ],
    faqs: [
      { q: "Can I use it with salicylic acid or retinol?", a: "Not in the same routine at first. Benzoyl peroxide deactivates some retinoids, and stacking it with salicylic acid on the same evening is how people end up with a raw face. Alternate: this in the morning, retinol at night." },
      { q: "Will it bleach my clothes?", a: "Yes — benzoyl peroxide bleaches fabric on contact. Use white towels and pillowcases, and rinse properly. That is also why it is better as a wash than a leave-on gel." }
    ]
  },

  /* ───────────────────────────────────────────────────────────────── Olay */
  {
    id: "olay-vitamin-c-brightening-body-lotion",
    photos: ["assets/img/olay-brightening-body-lotion-vitamin-c-b3.jpg"],
    name: "Vitamin C Brightening Body Lotion",
    brand: "Olay",
    brandId: "olay",
    price: 30000,
    size: "502 ml",
    form: "pump",
    tint: "#c6a664",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["body-dryness", "dullness", "dark-spots"],
    rating: 4.6,
    reviewCount: 28,
    texture: "Light, fast-absorbing lotion",
    short:
      "Vitamin C and niacinamide in a half-litre of body lotion that absorbs in under a minute — for the arms and legs that never get the same attention as the face.",
    benefits: [
      "Vitamin C and B3 (niacinamide) work on the dullness and unevenness that show up on arms, knees and elbows",
      "24-hour moisture claim is generous, but the pump size means you can afford to be generous back",
      "Absorbs fast enough to dress straight after, which is the only reason a body lotion gets used daily",
      "Half a litre at this price makes it realistic for the whole family, not just the person who reads skincare labels"
    ],
    ingredients: [
      { name: "Vitamin C", role: "Brightens and evens the tone of dull body skin" },
      { name: "Niacinamide (vitamin B3)", role: "Supports the barrier and evens tone" },
      { name: "Glycerin", role: "Holds water in the skin for the day" },
      { name: "Petrolatum and emollients", role: "Seal the water in, which is what stops ashiness" }
    ],
    directions:
      "Apply after a shower, while the skin is still slightly damp, and give it a minute before dressing. Once a day is the realistic minimum; twice in the dry season.",
    reviews: [
      { who: "Gloria M.", city: "Gikondo, Kigali", rating: 5, date: "March 2026", text: "The ashy look on my shins is gone. It sinks in fast so I do not sit around waiting for it to dry." },
      { who: "Aimable N.", city: "Rwamagana", rating: 4.5, date: "January 2026", text: "Big bottle, works, does not smell like perfume. Good for the price." }
    ],
    faqs: [
      { q: "Will it fade the dark knuckles and knees?", a: "Partly, over months, and mostly by keeping the skin hydrated and protected rather than by bleaching anything. Add sunscreen on exposed limbs if you want pigment to actually stay away." },
      { q: "Can I use it on my face?", a: "It is formulated for the body — the fragrance and richness are more than the face needs. Use the Olay face range or the CeraVe lotions instead." }
    ]
  },
  {
    id: "olay-dark-spot-correcting-body-lotion",
    photos: ["assets/img/olay-dark-spot-correcting-body-lotion.jpg"],
    name: "Dark Spot Correcting Body Lotion",
    brand: "Olay",
    brandId: "olay",
    price: 34000,
    size: "502 ml",
    form: "pump",
    tint: "#c6a664",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["dark-spots", "hyperpigmentation", "body-dryness", "dullness"],
    rating: 4.7,
    reviewCount: 25,
    texture: "Lotion with a light exfoliating finish",
    short:
      "AHA, vitamin C and niacinamide in a body lotion aimed at the dark patches that sun, waxing and old bites leave on the body — not the face.",
    benefits: [
      "AHA lifts the discoloured surface cells that make a patch look set in, while vitamin C and niacinamide work underneath",
      "For the marks body skin actually gets: ingrown hairs, shaving shadow, sun patches and old insect bites",
      "Exfoliates gradually rather than scrubbing, so there is nothing to overdo",
      "The half-litre pump and a price that makes daily use on arms and legs realistic"
    ],
    ingredients: [
      { name: "AHA (alpha hydroxy acid)", role: "Lifts the discoloured dead cells from the surface of the skin" },
      { name: "Vitamin C", role: "Brightens and defends against further pigment" },
      { name: "Niacinamide", role: "Evens tone and supports the barrier" },
      { name: "Glycerin", role: "Hydrates, so the exfoliating acid does not leave the skin tight" }
    ],
    directions:
      "Apply once a day to the affected areas after a shower, and be consistent for at least four weeks — the pack says four weeks to fade stubborn spots and that is realistic. Use sunscreen on exposed skin, or the sun will undo it.",
    reviews: [
      { who: "Yvette A.", city: "Kicukiro, Kigali", rating: 5, date: "February 2026", text: "The dark patches on my knees from kneeling a lot are fading. Six weeks in, I can see the difference in daylight." },
      { who: "Diane U.", city: "Nyarugenge, Kigali", rating: 4, date: "December 2025", text: "Good on the marks from shaving under my arms. Slow — but the bottle is big enough to be patient with." }
    ],
    faqs: [
      { q: "Can I use it on my face?", a: "No. It is a body formula with an exfoliating acid in it, and the face needs something lighter. Use the face serums for facial pigmentation." },
      { q: "Will it make me lighter overall?", a: "It does not change your natural skin tone. It fades patches that are darker than your own skin, which is a different thing." }
    ]
  },

  /* ───────────────────────────────────────────────────────────── Dr Teal's */
  {
    id: "dr-teals-body-lotion-citrus",
    photos: ["assets/img/dr-teals-body-lotion-citrus.jpg"],
    name: "Body Lotion with Citrus Essential Oils",
    brand: "Dr Teal's",
    brandId: "dr-teals",
    price: 22000,
    size: "532 ml",
    form: "bottle",
    tint: "#d98a2b",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["body-dryness", "dullness"],
    rating: 4.6,
    reviewCount: 21,
    texture: "Rich, creamy lotion",
    short:
      "Cocoa butter, shea butter and vitamin E with citrus essential oils: a proper body lotion for dry legs, in the half-litre size that means you stop rationing it.",
    benefits: [
      "Shea and cocoa butter are the two that actually hold moisture in dry, ashy skin through a whole day",
      "Vitamin E supports the skin while it repairs, which matters after sun or shaving",
      "Citrus essential oils give it a real scent — that is either the point for you or the reason to choose the fragrance-free option instead",
      "A 532 ml bottle lasts weeks even when used on arms, legs and feet"
    ],
    ingredients: [
      { name: "Shea butter", role: "Seals moisture into dry skin and softens it" },
      { name: "Cocoa butter", role: "Rich occlusive for rough knees, elbows and heels" },
      { name: "Vitamin E", role: "Antioxidant support, and helps the butters stay stable" },
      { name: "Citrus essential oils", role: "The scent, and the reason it feels like a morning lotion" }
    ],
    directions:
      "Massage into the body after a shower while the skin is still damp, paying attention to the shins, elbows and heels. Reapply to hands through the day. Not for the face, and patch test if you know citrus oils irritate your skin.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "February 2026", text: "Smells like a holiday but actually works. My legs stopped itching after a week of using it daily." },
      { who: "Samuel T.", city: "Rubavu", rating: 4, date: "January 2026", text: "The scent is strong on the first ten minutes. Rich lotion, good price for the size." }
    ],
    faqs: [
      { q: "Is citrus safe in the sun?", a: "Some citrus oils are photosensitising, so use it on covered skin or keep sun exposure in mind. On arms and legs that are already dry, the emollients are what you are buying." },
      { q: "Can I use it on my face?", a: "No — the essential oils and butters are body-grade. Keep it below the jaw." }
    ]
  },
  {
    id: "dr-teals-vitamin-c-body-wash",
    photos: ["assets/img/dr-teals-vitamin-c-body-wash.jpg"],
    name: "Glow & Radiance Vitamin C Body Wash",
    brand: "Dr Teal's",
    brandId: "dr-teals",
    price: 24000,
    size: "710 ml",
    form: "bottle",
    tint: "#e0a35c",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["body-dryness", "dullness"],
    rating: 4.5,
    reviewCount: 17,
    texture: "Creamy gel wash",
    short:
      "Vitamin C and citrus oils with shea butter, aloe vera and the Dr Teal's Epsom salt system, in a body wash big enough to keep in the shower for months.",
    benefits: [
      "Cleanses without the tight feeling a cheap shower gel leaves, thanks to shea butter and aloe vera in the base",
      "The Epsom salt system is what Dr Teal's is built on — it softens the water and the skin rather than just stripping it",
      "A 710 ml bottle that lathers well means it lasts considerably longer than a supermarket gel half the price per millilitre",
      "Leaves the skin ready for the body lotion instead of fighting it"
    ],
    ingredients: [
      { name: "Vitamin C", role: "Antioxidant support for dull, tired-looking skin" },
      { name: "Epsom salt (magnesium sulfate)", role: "Softens the skin and the water it is washed in" },
      { name: "Shea butter and aloe vera", role: "Keep the skin conditioned while it is being washed" },
      { name: "Citrus essential oils", role: "The uplifting scent the line is known for" }
    ],
    directions:
      "Lather over the body with a cloth or hands, rinse, and follow with body lotion on damp skin. For a soak, a splash in a warm bath does the same job the Epsom salts are there for.",
    reviews: [
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 5, date: "March 2026", text: "My skin does not feel scaly after a shower any more, and the bottle is enormous." },
      { who: "Fabrice K.", city: "Rwamagana", rating: 4, date: "February 2026", text: "Good wash, strong citrus scent. I follow it with the matching lotion." }
    ],
    faqs: [
      { q: "Is this a lotion or a wash?", a: "A body wash — it lathers and rinses off. The lotion is the bottle next to it in the same range; the two are meant to be used together." },
      { q: "Is it safe for sensitive skin?", a: "The citrus essential oils are the thing to watch. If you react to fragrance in body products, keep to the fragrance-free washes instead." }
    ]
  },
  {
    id: "dr-teals-shea-sugar-scrub-citrus",
    photos: ["assets/img/dr-teals-citrus-sugar-scrub.jpg"],
    name: "Shea Sugar Scrub — Citrus",
    brand: "Dr Teal's",
    brandId: "dr-teals",
    price: 20000,
    size: "538 g",
    form: "tub",
    tint: "#e0a35c",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "oily", "combination"],
    concerns: ["body-dryness", "dullness"],
    rating: 4.7,
    reviewCount: 20,
    texture: "Sugar scrub in shea butter",
    short:
      "Sugar, shea butter, orange oil and avocado oil in a tub: the scrub that leaves skin soft rather than raw, because the oil is buffering the sugar.",
    benefits: [
      "Sugar dissolves as you work it in, so it exfoliates and then stops — salt scrubs keep going and take the skin with them",
      "Shea butter and avocado oil stay behind on the skin after rinsing, which is why you can skip the lotion afterwards",
      "Transforms rough knees, elbows and heels in one shower",
      "Preps skin for shaving or self-tan better than any wash"
    ],
    ingredients: [
      { name: "Sugar", role: "Exfoliates and dissolves, so it cannot over-scrub" },
      { name: "Shea butter", role: "Leaves a conditioning layer behind after rinsing" },
      { name: "Avocado oil", role: "Softens and feeds dry skin" },
      { name: "Orange and citrus oils", role: "The scent, and a bright start to the day" }
    ],
    directions:
      "On wet skin in the shower, scoop out a handful and massage in circles over the legs, arms and any rough patches, then rinse. Once or twice a week is plenty. Not for the face, and not on broken or freshly shaved skin.",
    reviews: [
      { who: "Marie-Claire N.", city: "Kiyovu, Kigali", rating: 5, date: "February 2026", text: "My legs have never been this smooth. I use it before shaving and I have not had a bump since." },
      { who: "Aimable N.", city: "Rwamagana", rating: 4.5, date: "January 2026", text: "It is oily in the tub, which is the point — you do not need lotion after. Rinse the shower floor or it gets slippery." }
    ],
    faqs: [
      { q: "How often should I use it?", a: "Once or twice a week. More than that and you are exfoliating skin that has not finished recovering." },
      { q: "Will it help with dark knees and elbows?", a: "It helps by removing the rough, thickened surface that makes those areas look darker. For actual pigment, the Olay dark spot body lotion does more." }
    ]
  },

  /* ────────────────────────────────────────────────────────────── Pro Lab */
  {
    id: "prolab-kojic-dipalmitate",
    photos: ["assets/img/prolab-kojic-dipalmitate.jpg"],
    name: "Kojic Dipalmitate + HA Body Lotion",
    brand: "Pro Lab",
    brandId: "pro-lab",
    price: 18000,
    size: "500 ml",
    form: "pump",
    tint: "#7a6f9a",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["dark-spots", "hyperpigmentation", "body-dryness", "dullness"],
    rating: 4.4,
    reviewCount: 16,
    texture: "Light lotion",
    short:
      "Kojic dipalmitate and hyaluronic acid in a half-litre pump: a brightening body lotion for dark patches, knuckles and knees, at a price that allows daily use.",
    benefits: [
      "Kojic dipalmitate is a gentler, more stable relative of kojic acid — it targets the dark patches body skin collects without the sting",
      "Hyaluronic acid in the same bottle keeps the skin hydrated, which is half of what makes a patch look dark in the first place",
      "500 ml with a pump, so a family can use it every day without it becoming expensive",
      "Absorbs without a greasy film, which is what makes it wearable in the heat"
    ],
    ingredients: [
      { name: "Kojic dipalmitate", role: "Slows the pigment production behind dark patches" },
      { name: "Hyaluronic acid", role: "Hydrates and plumps dry body skin" },
      { name: "Glycerin", role: "Draws water into the skin and holds it" },
      { name: "Vitamin E", role: "Antioxidant support and keeps the formula stable" }
    ],
    directions:
      "Apply once or twice a day to the areas that are darker than the rest of your skin, and use sunscreen on any exposed skin — pigment will not fade if the sun keeps returning. Give it eight weeks, not eight days.",
    reviews: [
      { who: "Yvonne H.", city: "Nyarutarama, Kigali", rating: 4.5, date: "February 2026", text: "I use it on my knuckles and the patches on my arms. Two months in, they are closer to my own colour." },
      { who: "Eric M.", city: "Kigali", rating: 4, date: "January 2026", text: "Cheap enough to use properly every day, which is what actually made the difference for me." }
    ],
    faqs: [
      { q: "Does it bleach the skin?", a: "No. It slows the pigment your skin makes in patches that are already darker, and it does not change your natural tone. Anyone selling you a product that does is selling you something else." },
      { q: "Can I use it on my face?", a: "Use a face product on your face. This is a 500 ml body formula; it is too rich and the actives are dosed for the body." }
    ]
  },
  {
    id: "prolab-ceramide-barrier",
    photos: ["assets/img/prolab-ceramide-barrier.jpg"],
    name: "Skin Barrier Repair Ceramide Body Lotion",
    brand: "Pro Lab",
    brandId: "pro-lab",
    price: 18000,
    size: "500 ml",
    form: "pump",
    tint: "#c6a664",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "sensitive", "normal", "combination"],
    concerns: ["body-dryness", "sensitivity"],
    rating: 4.5,
    reviewCount: 14,
    texture: "Creamy lotion",
    short:
      "Ceramides in a half-litre body lotion for skin that is dry because its barrier is broken, not because it needs more oil.",
    benefits: [
      "Ceramides are the lipids the skin is made of — replacing them is what makes dryness stop coming back",
      "For the itch and flaking on shins and forearms that no amount of petroleum jelly seems to fix",
      "Fragrance-free enough to use on skin that reacts to scented lotions",
      "Long-lasting hydration claimed by the pack, and ceramides are the reason a claim like that holds up"
    ],
    ingredients: [
      { name: "Ceramides", role: "Rebuild the barrier that keeps water in the skin" },
      { name: "Shea butter", role: "Seals moisture into dry, rough skin" },
      { name: "Glycerin", role: "Draws water into the upper layers" },
      { name: "Cholesterol and fatty acids", role: "Complete the barrier lipid mix ceramides need to work properly" }
    ],
    directions:
      "Apply generously after a shower on damp skin, morning and night if the skin is very dry. In the dry season, use it twice a day and keep showers short and lukewarm.",
    reviews: [
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "My shins used to itch every night. Two weeks of this and it stopped." },
      { who: "Gloria M.", city: "Gikondo, Kigali", rating: 4, date: "December 2025", text: "Thick but not greasy. I bought one for my mother as well." }
    ],
    faqs: [
      { q: "Ceramide lotion or just a rich butter?", a: "A butter seals water in; ceramides rebuild what holds the water. If dryness keeps returning after you moisturise, you want ceramides." },
      { q: "Is it safe on eczema?", a: "Ceramide lotions are what dermatologists usually recommend alongside eczema treatment. It is not a substitute for prescribed cream on a flare." }
    ]
  },
  {
    id: "prolab-alpha-arbutin-niacinamide",
    photos: ["assets/img/prolab-alpha-arbutin-niacinamide.jpg"],
    name: "Alpha Arbutin + Niacinamide Brightening Lotion",
    brand: "Pro Lab",
    brandId: "pro-lab",
    price: 18000,
    size: "500 ml",
    form: "pump",
    tint: "#b5674e",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["dark-spots", "hyperpigmentation", "dullness", "body-dryness"],
    rating: 4.4,
    reviewCount: 13,
    texture: "Light, fast-absorbing lotion",
    short:
      "Alpha arbutin and niacinamide together: the two most reliable non-hydroquinone brighteners, in a body lotion you can use on your whole body every day.",
    benefits: [
      "Alpha arbutin quietly blocks the enzyme that makes pigment, without the irritation kojic acid can cause",
      "Niacinamide in the same lotion evens tone and supports the barrier while it works",
      "For the marks that come from waxing, shaving and bites — the everyday pigmentation body skin actually gets",
      "Half a litre means you can apply it properly, and consistency is what makes arbutin work"
    ],
    ingredients: [
      { name: "Alpha arbutin", role: "Slows pigment production and fades existing dark patches" },
      { name: "Niacinamide", role: "Evens tone and strengthens the barrier" },
      { name: "Glycerin", role: "Hydrates the skin so the actives do not dry it" },
      { name: "Vitamin E", role: "Antioxidant support for skin exposed to the sun" }
    ],
    directions:
      "Apply twice a day to the affected areas for at least eight weeks, and use sunscreen on any skin the sun reaches. Arbutin is slow and steady by nature — stopping at three weeks is why most people say it does not work.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4.5, date: "February 2026", text: "The dark marks from shaving under my arms are noticeably lighter after two months." },
      { who: "Josiane B.", city: "Nyarugenge, Kigali", rating: 4, date: "January 2026", text: "No irritation at all, which is more than I can say for the strong creams I tried before." }
    ],
    faqs: [
      { q: "Alpha arbutin or kojic acid?", a: "Alpha arbutin is gentler and suits sensitive or reactive skin; kojic is faster on stubborn patches but more likely to sting. The two Pro Lab bottles can be alternated if you want both." },
      { q: "Do I need sunscreen with it?", a: "Yes. Any brightening active without daily sun protection is a losing battle on Rwandan sun." }
    ]
  },
  /* ───────────────────────────────────────────────────────────── K-Secret */
  {
    id: "k-secret-seoul-1988-retinal-serum",
    photos: ["assets/img/k-secret-seoul-1988-black-ginseng-serum.jpg"],
    name: "Seoul 1988 Serum — Retinal Liposome 2% + Black Ginseng",
    brand: "K-Secret",
    brandId: "k-secret",
    price: 46000,
    size: "30 ml",
    form: "dropper",
    tint: "#d16a9c",
    category: "serums",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["fine-lines", "dullness", "dark-spots", "large-pores", "post-acne-marks"],
    rating: 4.8,
    reviewCount: 23,
    texture: "Light, silky serum",
    short:
      "Two per cent encapsulated retinal with 58% fermented black ginseng: the strength of a prescription retinoid approach, buffered into a liposome so it does not take your barrier with it.",
    benefits: [
      "Retinal works faster than retinol — one conversion step from the form your skin actually uses",
      "Encapsulated in a liposome, so it releases slowly through the night instead of all at once on the surface",
      "58% black ginseng brings antioxidant and brightening support, which is why the same bottle also improves tone",
      "Refines texture and visible pores over eight to twelve weeks — the change people mean when they say 'glass skin'"
    ],
    ingredients: [
      { name: "Retinal (retinaldehyde) liposome 2%", role: "Speeds up cell turnover and smooths fine lines with less irritation" },
      { name: "Black ginseng extract 58%", role: "Antioxidant and brightening support for tired, uneven skin" },
      { name: "Niacinamide", role: "Evens tone and calms the redness retinal can cause" },
      { name: "Peptides and bakuchiol", role: "Support firmness and add a gentler retinol-like effect" }
    ],
    directions:
      "At night only: three drops on clean, dry skin, then moisturiser. Start twice a week for two weeks, then every other night. Sunscreen every single morning is compulsory. Do not use it with strong acids on the same night, and not while pregnant or breastfeeding.",
    reviews: [
      { who: "Sandrine M.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "I have used 1% retinol for years and this is a different league. My forehead lines are softer and there was no peeling at all." },
      { who: "Ivan S.", city: "Kigali", rating: 4.5, date: "February 2026", text: "I started twice a week as the bottle says and had no reaction. My skin is smoother and the marks on my cheeks are lighter." }
    ],
    faqs: [
      { q: "Retinal or retinol — what is the difference?", a: "Retinal is one step closer to the retinoic acid your skin uses, so it acts faster than retinol at the same percentage, with similar irritation if it is not encapsulated. This one is encapsulated, which is why 2% is usable at home." },
      { q: "Can I use it with the Medicube acid pads?", a: "Not on the same night. Alternate them — pads one night, this the next — and if your skin stings at all, drop to twice a week until it settles." }
    ]
  },
  {
    id: "k-secret-seoul-1988-eye-cream-retinal",
    photos: ["assets/img/k-secret-seoul-1988-eye-cream-retinal.jpg"],
    name: "Seoul 1988 Eye Cream — Retinal Liposome 4% + Fermented Bean",
    brand: "K-Secret",
    brandId: "k-secret",
    price: 38000,
    size: "30 ml",
    form: "tube",
    tint: "#d16a9c",
    category: "moisturizers",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "sensitive"],
    concerns: ["fine-lines", "dryness", "dullness"],
    rating: 4.6,
    reviewCount: 18,
    texture: "Rich but light eye cream",
    short:
      "A 4% retinal liposome eye cream with fermented bean extract, for the crepey texture and fine lines the rest of your routine is not aimed at.",
    benefits: [
      "The eye area has thinner skin than the face, so it needs retinal at a lower exposure — this releases it slowly from a liposome",
      "Fermented bean extract conditions the thin skin that creases first and shows dehydration most",
      "Takes on crow's feet and the fine lines that makeup settles into by mid-afternoon",
      "30 ml is a genuinely large eye cream, so you can use it properly twice a day"
    ],
    ingredients: [
      { name: "Retinal liposome 4%", role: "Smooths fine lines and firms the thin skin around the eye" },
      { name: "Fermented soybean extract", role: "Conditions and supports the barrier in dehydrated skin" },
      { name: "Niacinamide", role: "Evens the darkness that shadows the eye area" },
      { name: "Panthenol", role: "Calms and buffers the retinal" }
    ],
    directions:
      "Pat a small amount around the orbital bone — not on the eyelid itself — morning and evening as the last step. Start at night only for the first fortnight. If it stings, buffer it with eye cream first and this on top.",
    reviews: [
      { who: "Clarisse U.", city: "Nyarutarama, Kigali", rating: 5, date: "February 2026", text: "The crow's feet when I smile are softer after six weeks. It does not sting and it does not migrate into my eyes." },
      { who: "Yvette A.", city: "Kicukiro, Kigali", rating: 4, date: "January 2026", text: "Good texture, absorbs, and my concealer sits better. Slow to show on the lines themselves." }
    ],
    faqs: [
      { q: "Can I put the face retinal serum on my eyes instead?", a: "You can, carefully — but the eyelid skin is thinner and the serum is dosed for the face. A dedicated eye cream is the safer route, and this one is still a retinal." },
      { q: "Will it help with dark circles?", a: "Partly — the niacinamide helps with pigment and the retinal with texture. Circles caused by the shape of your eye, or by poor sleep, are not a cream problem." }
    ]
  },

  /* ───────────────────────────────────────────────────────────── SKIN1004 */
  {
    id: "skin1004-madagascar-centella-ampoule",
    photos: ["assets/img/skin1004-madagascar-centella-ampoule.jpg"],
    name: "Madagascar Centella Ampoule",
    brand: "SKIN1004",
    brandId: "skin1004",
    price: 38000,
    size: "55 ml",
    form: "dropper",
    tint: "#6f8f6a",
    category: "serums",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["sensitive", "oily", "dry", "combination", "normal"],
    concerns: ["sensitivity", "acne", "dryness", "post-acne-marks"],
    rating: 4.8,
    reviewCount: 39,
    texture: "Watery, faintly herbal ampoule",
    short:
      "The plainest bottle on the shelf: centella asiatica extract from Madagascar, and almost nothing else — for skin that needs calming rather than another active.",
    benefits: [
      "Centella asiatica is the ingredient K-beauty uses for redness, irritation and skin that is healing from acne or acids",
      "A single-ingredient ampoule, so there is very little in it to react to — the safest first serum for reactive skin",
      "Layers under anything: sunscreen, acids, retinoids, makeup",
      "55 ml is an unusually large ampoule, at a watery texture you will actually get through"
    ],
    ingredients: [
      { name: "Centella asiatica extract", role: "Calms redness, itching and irritation, and supports healing" },
      { name: "Madecassoside (from centella)", role: "The fraction of centella with the strongest soothing effect" },
      { name: "Asiaticoside", role: "Supports skin repair and the look of old marks" },
      { name: "Water-based, fragrance-free base", role: "Nothing added that reactive skin could object to" }
    ],
    directions:
      "Three to five drops on clean skin, morning and evening, before serums or moisturiser. Layer it more generously when your skin is irritated — after sun, after acids, or when a reaction is starting. Pat it in, do not rub.",
    reviews: [
      { who: "Diane U.", city: "Nyarugenge, Kigali", rating: 5, date: "March 2026", text: "I overdid the acids and my cheeks were burning. Three days of this and it stopped. I keep it in the fridge now." },
      { who: "Patrick N.", city: "Huye", rating: 4.5, date: "February 2026", text: "Watery, no smell, no sting — it just makes my skin less angry. Paired with the snail cream it is the whole routine." }
    ],
    faqs: [
      { q: "Is there any active in it?", a: "Centella itself is the active. There is no acid, no retinol and no fragrance, which is exactly why it is the sensible first serum for skin that has reacted badly to something else." },
      { q: "Will it help with acne on its own?", a: "It calms the inflammation that acne leaves, but it does not kill the bacteria in the pore. For active acne, pair it with a benzoyl peroxide or azelaic acid product and use this to reduce the irritation they cause." }
    ]
  },
  {
    id: "skin1004-tone-brightening-capsule-ampoule",
    photos: ["assets/img/skin1004-madagascar-centella-tone-brightening-capsule-ampoule.jpg"],
    name: "Madagascar Centella Tone Brightening Capsule Ampoule",
    brand: "SKIN1004",
    brandId: "skin1004",
    price: 44000,
    size: "100 ml",
    form: "dropper",
    tint: "#d9c07a",
    category: "serums",
    also: ["korean-skincare", "hyperpigmentation"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily", "sensitive"],
    concerns: ["dark-spots", "hyperpigmentation", "dullness", "post-acne-marks", "sensitivity"],
    rating: 4.7,
    reviewCount: 30,
    texture: "Clear ampoule with visible capsules",
    short:
      "The centella ampoule with brightening in it: niacinamide and a vitamin C derivative carried in capsules, for dark marks on skin that has already proved it reacts to strong lighteners.",
    benefits: [
      "Tone correction that does not start with a stinging serum — centella is the base rather than an afterthought",
      "Niacinamide and a vitamin C derivative work on marks and overall dullness at once",
      "The capsules hold the brightening actives until you press them into the skin",
      "100 ml is more than twice a normal ampoule, so it lasts around three months at twice a day"
    ],
    ingredients: [
      { name: "Centella asiatica extract", role: "Calms and supports skin that is healing from marks" },
      { name: "Niacinamide", role: "Evens tone and reduces the darkness of old spots" },
      { name: "Vitamin C derivative capsules", role: "Brighten the overall tone without the sting of pure ascorbic acid" },
      { name: "Madecassoside", role: "The soothing fraction of centella, in the base" }
    ],
    directions:
      "Apply three to four drops morning and evening after cleansing, pressing the capsules in as you go. Follow with moisturiser and, every morning, sunscreen — brightening without SPF does not work in Rwanda.",
    reviews: [
      { who: "Aline M.", city: "Kibagabaga, Kigali", rating: 5, date: "March 2026", text: "My skin is calmer and brighter at the same time, which I did not think was possible from one bottle." },
      { who: "Emmanuel R.", city: "Musanze", rating: 4.5, date: "January 2026", text: "No sting at all. The marks on my jaw took two months, but my overall skin tone evened out in three weeks." }
    ],
    faqs: [
      { q: "Red ampoule or this one?", a: "The plain centella ampoule is for calming and nothing else. This adds brightening, which is what you want if your concern is marks or dullness rather than reactivity. If your skin is currently irritated, calm it first with the plain one." },
      { q: "Can I use it with the retinal serum?", a: "Yes, at different times of day: this in the morning, retinal at night. Both require sunscreen in the morning." }
    ]
  },

  /* ────────────────────────────────────────────────────────────── Celimax */
  {
    id: "celimax-vita-a-retinal-shot-booster",
    photos: ["assets/img/celimax-retinal-shot-tightening-booster.jpg"],
    name: "The Vita A Retinal Shot Tightening Booster",
    brand: "Celimax",
    brandId: "celimax",
    price: 43000,
    size: "20 ml",
    form: "dropper",
    tint: "#c26b7d",
    category: "serums",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["fine-lines", "large-pores", "dullness", "dark-spots"],
    rating: 4.7,
    reviewCount: 17,
    texture: "Light milky booster",
    short:
      "0.1% liposomised retinal with 3% Matrixyl 3000 and 1% panthenol — a booster for firmness and pore size, dosed so you can use it without a recovery period.",
    benefits: [
      "0.1% retinal is serious but not reckless: enough to actually change texture, buffered by 1% panthenol so it does not peel your face",
      "3% Matrixyl 3000 is a peptide complex with real evidence behind it for firmness and fine lines",
      "A-Shot delivery works the retinal into the pore lining rather than leaving it sitting on the surface",
      "Smaller pores and tighter texture are usually the first things people notice, before lines move at all"
    ],
    ingredients: [
      { name: "Retinal 0.1% (liposomised)", role: "Speeds up cell turnover for smoother texture and firmer skin" },
      { name: "Matrixyl 3000 peptide complex 3%", role: "Supports collagen and the look of firmness" },
      { name: "Panthenol 1%", role: "Calms and cushions the retinal" },
      { name: "A-Shot delivery system", role: "Carries the actives into the pore and deeper into the skin" }
    ],
    directions:
      "At night, three drops on clean dry skin, then moisturiser. Two to three nights a week to start, then build up. Sunscreen every morning. Not during pregnancy or breastfeeding.",
    reviews: [
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 5, date: "February 2026", text: "My pores on the nose look tighter and my skin is smoother. No peeling at all, which I expected after retinol." },
      { who: "Thierry B.", city: "Musanze", rating: 4, date: "January 2026", text: "Very good on texture. I use it every third night and the snail cream on the others." }
    ],
    faqs: [
      { q: "Retinal booster or a retinol cream?", a: "A booster gives you the active without the filler. If your skin is dry and you want one step, a retinol cream does both jobs. If you already have a moisturiser you like, this is the cleaner way to add retinal." },
      { q: "Why is the bottle only 20 ml?", a: "Because retinal is used in drops, not scoops — three drops a night at two or three nights a week means 20 ml is around two months." }
    ]
  },

  /* ────────────────────────────────────────────────────────────── Arencia */
  {
    id: "arencia-vitamin-c-booster-shot",
    photos: ["assets/img/arencia-vitamin-c-booster-shot.jpg"],
    name: "Vitamin C Booster Shot",
    brand: "Arencia",
    brandId: "arencia",
    price: 39000,
    size: "30 ml",
    form: "dropper",
    tint: "#e29a3c",
    category: "serums",
    also: ["korean-skincare", "hyperpigmentation"],
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily", "sensitive"],
    concerns: ["dullness", "dark-spots", "hyperpigmentation", "post-acne-marks"],
    rating: 4.6,
    reviewCount: 15,
    texture: "Gel serum, no alcohol",
    short:
      "A 5% vitamin C complex with glutathione and niacinamide in a gel serum — brightening you can use every morning, from a formula that will not oxidise on you in the heat.",
    benefits: [
      "Stacks several forms of vitamin C rather than one high dose of pure ascorbic acid, so the brightening is steady and the sting is minimal",
      "Glutathione is the co-ingredient that makes vitamin C work better, and it helps with blemishes at the same time",
      "Alcohol-free and fragrance-free, so it does not dry reactive skin the way many vitamin C serums do",
      "Gel texture layers under sunscreen without pilling — the reason most vitamin C routines collapse in a hot climate"
    ],
    ingredients: [
      { name: "Vitamin C complex (5%) — ascorbic acid and derivatives", role: "Brightens tone, fades marks and defends against daily oxidation" },
      { name: "Glutathione", role: "Brightens and works with vitamin C on pigmentation" },
      { name: "Niacinamide", role: "Evens tone and supports the barrier" },
      { name: "Panthenol and allantoin", role: "Keep the serum comfortable rather than drying" }
    ],
    directions:
      "Three drops in the morning on clean skin, before moisturiser and sunscreen. If it is your first vitamin C, use it every other morning for a week. Keep the bottle closed and away from the sun — that is what keeps vitamin C from turning brown.",
    reviews: [
      { who: "Gloria M.", city: "Gikondo, Kigali", rating: 5, date: "March 2026", text: "It has not gone brown in the bottle like my last one did. My skin looks brighter and it never stings." },
      { who: "Olivier N.", city: "Huye", rating: 4, date: "February 2026", text: "Mild, pleasant, no orange smell. It took about six weeks to see the difference on my cheeks." }
    ],
    faqs: [
      { q: "Is 5% strong enough?", a: "5% is lower than the 15-20% serums people boast about, but several forms of vitamin C together at 5% deliver what most people can actually keep using daily. Consistency beats a percentage you can only tolerate twice a week." },
      { q: "Can I use it with the Anua azelaic serum?", a: "Yes — vitamin C in the morning, azelaic acid in the evening is a well-matched pair for marks. Introduce them a fortnight apart." }
    ]
  },

  /* ──────────────────────────────────────── Advanced Korean Skin (body) */
  {
    id: "advanced-korean-skin-bright-dewy",
    photos: ["assets/img/advanced-korean-skin-bright-dewy.jpg"],
    name: "Lightening & Barrier Repair Body Lotion",
    brand: "Advanced Korean Skin",
    brandId: "advanced-korean-skin",
    price: 19000,
    size: "500 ml",
    form: "pump",
    tint: "#d9b23b",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["body-dryness", "hyperpigmentation", "dark-spots", "dullness"],
    rating: 4.4,
    reviewCount: 12,
    texture: "Light, silky lotion",
    short:
      "The two-job lotion of the range: alpha-arbutin and niacinamide for the tone, ceramide NP and panthenol for the barrier that keeps it.",
    benefits: [
      "Alpha-arbutin and niacinamide are the pair to use on body pigmentation — knuckles, knees and the marks left by old bites and shaving",
      "Ceramide NP and panthenol repair the barrier at the same time, which matters because dry skin looks dark-skinned and uneven on top of being dry",
      "Light enough to apply straight out of the shower and dress in under a minute",
      "Paraben-free, cruelty-free and vegan, in a 500 ml pump that makes twice-daily use realistic"
    ],
    ingredients: [
      { name: "Alpha-arbutin", role: "Fades the look of dark marks and evens the tone" },
      { name: "Niacinamide", role: "Evens tone and supports the barrier" },
      { name: "Ceramide NP", role: "Restores the lipids dry skin is missing" },
      { name: "Panthenol", role: "Calms and holds moisture in" }
    ],
    directions:
      "Apply over the body after a shower while the skin is still slightly damp, twice a day. Give the tone four to eight weeks of consistency, and take a photograph on day one so you can actually see it moving.",
    reviews: [
      { who: "Yvonne H.", city: "Nyarutarama, Kigali", rating: 4.5, date: "February 2026", text: "It makes my shoulders look glossy in a good way and it dries fast enough to put clothes on." },
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 4, date: "January 2026", text: "Light and pleasant. In the dry season I follow it with a butter on my legs." }
    ],
    faqs: [
      { q: "Will it lighten my skin tone?", a: "No, and it should not be sold as if it would. Alpha-arbutin and niacinamide even out dark marks and uneven patches; your natural tone is what is left when the marks fade." },
      { q: "Which of the three should I choose?", a: "This one for marks, knuckles and uneven tone, Bright & Moisture if your skin is mostly dry, Bright & Smooth if it is rough or bumpy in texture." }
    ]
  },
  {
    id: "advanced-korean-skin-bright-moisture",
    photos: ["assets/img/advanced-korean-skin-bright-moisture.jpg"],
    name: "Bright & Moisture Body Lotion",
    brand: "Advanced Korean Skin",
    brandId: "advanced-korean-skin",
    price: 19000,
    size: "500 ml",
    form: "pump",
    tint: "#c9c3b8",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "sensitive"],
    concerns: ["body-dryness", "sensitivity", "dullness"],
    rating: 4.5,
    reviewCount: 14,
    texture: "Rich, creamy lotion",
    short:
      "The middle of the three and the one most people should start with: a creamy body lotion that holds moisture through a dry-season day without a greasy film.",
    benefits: [
      "Rich enough for shins and forearms that stay rough no matter how much lotion you use",
      "Absorbs fully, so you are not leaving marks on the bedsheets",
      "Paraben-free, cruelty-free and vegan, as printed on the bottle",
      "Half a litre with a pump means the whole family can use it after a shower"
    ],
    ingredients: [
      { name: "Shea butter", role: "Locks moisture into dry, rough skin" },
      { name: "Glycerin", role: "Attracts water into the upper layers of the skin" },
      { name: "Panthenol", role: "Calms tightness and supports the skin's barrier" },
      { name: "Vitamin E", role: "Antioxidant support for skin in the sun" }
    ],
    directions:
      "Apply generously after every shower, on damp skin, concentrating on shins, elbows and heels. Twice a day in the dry season if the skin still feels tight.",
    reviews: [
      { who: "Clarisse U.", city: "Nyarutarama, Kigali", rating: 5, date: "March 2026", text: "My legs stopped itching within a week. This is the one I keep buying." },
      { who: "Aimable N.", city: "Rwamagana", rating: 4.5, date: "February 2026", text: "Rich but it soaks in. Good value for 500 ml." }
    ],
    faqs: [
      { q: "Can I use it on my face?", a: "It is a body lotion; the face wants something lighter. Keep it below the jaw." },
      { q: "Will it be too heavy in the hot season?", a: "It absorbs cleanly, so most people use it year round. If you want something lighter for daytime, that is the Lightening & Barrier Repair." }
    ]
  },

  /* ─────────────────────────────────────────────────────── Anua (new) */
  {
    id: "anua-zero-cast-sunscreen",
    photos: ["assets/img/anua-zero-cast-sunscreen.jpg"],
    name: "Zero-Cast Moisturizing Finish Sunscreen SPF 50+",
    brand: "Anua",
    brandId: "anua",
    price: 32000,
    size: "50 ml",
    form: "tube",
    tint: "#e08a3c",
    category: "sunscreens",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["dark-spots", "dullness", "sensitivity"],
    rating: 4.8,
    reviewCount: 29,
    texture: "Soft cream that dries down without a cast",
    short:
      "SPF 50+ PA++++ in a moisturising cream that leaves nothing behind on the skin — for the people who stopped wearing sunscreen because of the white film.",
    benefits: [
      "Zero-cast: it finishes on the skin the colour it started in, which is the whole point of the name and the reason it works on deeper skin tones",
      "SPF 50+ PA++++ is the level Kigali actually needs — the PA rating is the one that covers ageing and pigmentation, not just sunburn",
      "It sits comfortably as the last step of a routine, so the sunscreen is a cream you want to apply rather than a step you skip",
      "Layers under makeup without pilling if you give it a minute to set"
    ],
    ingredients: [
      { name: "Broad-spectrum UV filters (SPF 50+ / PA+++)", role: "Block UVB and the UVA that drives pigmentation" },
      { name: "Hyaluronic acid", role: "Holds water in the skin so the finish is moisturising, not tight" },
      { name: "Centella asiatica", role: "Calms the skin while it is in the sun" },
      { name: "Glycerin", role: "Keeps the cream comfortable over a full day" }
    ],
    directions:
      "Apply two finger-lengths to the face and neck as the last step of your morning routine, fifteen minutes before you go out. Reapply every two to three hours outdoors. Sunscreen is the one product where the amount matters as much as the number on the tube.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 5, date: "March 2026", text: "Finally one that does not turn me grey. It feels like a moisturiser and my makeup sits on it fine." },
      { who: "Yvette M.", city: "Musanze", rating: 4.5, date: "February 2026", text: "No cast, no sting in my eyes on the moto. I use it every morning now." }
    ],
    faqs: [
      { q: "Is SPF 50+ overkill for a normal day?", a: "No. Rwanda sits high and close to the equator, and UVA comes through cloud and window glass. A daily 50+ is the standard advice here, and the PA++++ rating matters more than the SPF for dark spots." },
      { q: "Will it make oily skin worse?", a: "The finish is moisturising rather than matte, so very oily skin may prefer a gel-cream sunscreen. Combination skin generally gets on well with it." }
    ]
  },
  {
    id: "anua-pdrn-hyaluron-capsule-100-serum",
    photos: ["assets/img/anua-pdrn-hyaluron-capsule-100-serum.jpg"],
    name: "PDRN + Hyaluron Capsule 100 Serum",
    brand: "Anua",
    brandId: "anua",
    price: 42000,
    size: "30 ml",
    form: "dropper",
    tint: "#2f8f86",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dryness", "dullness", "fine-lines"],
    rating: 4.7,
    reviewCount: 24,
    texture: "Light watery serum with capsule beads",
    short:
      "Anua's PDRN serum: the repair-and-plump side of K-beauty, in a watery serum that sinks in before your moisturiser.",
    benefits: [
      "PDRN is the repair ingredient the Korean clinic shelves are built on — this is the at-home version, at a strength that suits daily use",
      "The hyaluronic acid plumps dehydration lines within minutes, which is what makes the skin look rested rather than tired",
      "The capsule beads break as you press them in, so the serum glides rather than drags on reactive skin",
      "Light enough to layer under a moisturiser and a sunscreen without the routine turning heavy"
    ],
    ingredients: [
      { name: "PDRN (salmon DNA fragment)", role: "Supports the skin's own repair and recovery" },
      { name: "Hyaluronic acid", role: "Pulls water into the upper layers for immediate plumpness" },
      { name: "Niacinamide", role: "Evens tone and calms redness over weeks" },
      { name: "Panthenol", role: "Soothes and holds moisture in a stressed barrier" }
    ],
    directions:
      "Two or three drops onto clean, slightly damp skin morning and evening, pressed in rather than rubbed, then follow with moisturiser. Give it four weeks — repair ingredients are a routine, not a rescue.",
    reviews: [
      { who: "Clarisse U.", city: "Nyarutarama, Kigali", rating: 5, date: "March 2026", text: "My skin looks less tired after about three weeks. It layers under everything and never pills." },
      { who: "Olivier N.", city: "Huye", rating: 4.5, date: "February 2026", text: "Watery, no stickiness, and the dry patches around my nose settled down." }
    ],
    faqs: [
      { q: "What is PDRN, in plain words?", a: "A fragment of salmon DNA used in Korean skin clinics to support repair. In a serum it is a supporting ingredient over a routine, not a single-use treatment — expect softness and a better-looking barrier rather than a dramatic change." },
      { q: "Can I use it with retinol?", a: "Yes. Apply this first, let it dry, then the retinol. On the nights your skin stings, skip the retinol and keep this." }
    ]
  },

  /* ──────────────────────────────────────────────────────── SKIN1004 */
  {
    id: "skin1004-hyalu-cica-water-fit-sun-serum",
    photos: ["assets/img/skin1004-hyalu-cica-water-fit-sun-serum.jpg"],
    name: "Hyalu-Cica Water-Fit Sun Serum SPF 50+",
    brand: "SKIN1004",
    brandId: "skin1004",
    price: 30000,
    size: "50 ml",
    form: "tube",
    tint: "#4e9fd1",
    category: "sunscreens",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["dark-spots", "sensitivity", "dryness"],
    rating: 4.9,
    reviewCount: 41,
    texture: "Watery serum that disappears into the skin",
    short:
      "Centella and hyaluronic acid under SPF 50+ PA++++ — a sunscreen with the texture of a serum, which is why it is the one people actually finish.",
    benefits: [
      "A serum texture rather than a cream, so it goes on after a full routine without the face feeling coated",
      "Centella from Madagascar calms skin that reacts to sunscreen, which is the most common reason people give up on SPF",
      "SPF 50+ PA++++ broad-spectrum cover for a full day in Kigali sun",
      "No white cast and no pilling under makeup — two finger-lengths and it is done"
    ],
    ingredients: [
      { name: "Centella asiatica extract", role: "Calms redness and supports a reactive barrier" },
      { name: "Hyaluronic acid", role: "Keeps the serum hydrating rather than drying on the skin" },
      { name: "Broad-spectrum UV filters (SPF 50+ / PA+++)", role: "Protection against burning and against pigmentation" },
      { name: "Panthenol", role: "Soothes skin that stings easily" }
    ],
    directions:
      "As the last step of the morning routine, on face, ears and neck. Two finger-lengths for the face alone; reapply every two to three hours if you are outside. In the car or on a moto, the neck and hands are the parts people forget.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 5, date: "March 2026", text: "It is the only sunscreen I have ever finished. It feels like nothing on the skin." },
      { who: "Aimable N.", city: "Rwamagana", rating: 5, date: "February 2026", text: "My skin used to sting with sunscreen. This one does not, and no white cast at all." }
    ],
    faqs: [
      { q: "Does it work for oily skin?", a: "Yes — the watery finish suits oily and combination skin better than a cream sunscreen. If you get very shiny by midday, a light powder over it is enough." },
      { q: "Do I still need a moisturiser under it?", a: "If your skin is dry, yes. If it is oily or you live in a humid room, the serum texture is hydrating enough on its own." }
    ]
  },

  /* ─────────────────────────────────────────────────────────────── EOS */
  {
    id: "eos-shea-better-beach-waves",
    photos: ["assets/img/eos-shea-better-beach-waves.jpg"],
    name: "Shea Better 24H Moisture Body Lotion — Beach Waves",
    brand: "EOS",
    brandId: "eos",
    price: 19000,
    size: "473 ml",
    form: "bottle",
    tint: "#e8c33c",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["body-dryness"],
    rating: 4.7,
    reviewCount: 23,
    texture: "Whipped cream lotion that absorbs fast",
    short:
      "Shea butter and seven oils in the pastel bottle everyone recognises — a light, absorbent body lotion that smells like a beach and lasts through the day.",
    benefits: [
      "Shea butter plus seven nourishing oils and butters is the combination that keeps dry legs comfortable for a full 24 hours",
      "Absorbs quickly enough to put clothes on two minutes later, which is why it gets used every day and the other bottles do not",
      "Made with natural shea and suitable for sensitive skin, as printed on the bottle",
      "A 473 ml bottle that lasts weeks, at a price that makes using it generously the normal thing to do"
    ],
    ingredients: [
      { name: "Shea butter", role: "Seals moisture into the skin and softens it" },
      { name: "Seven oils and butters", role: "Replenish what washing and sun take out of the skin" },
      { name: "Glycerin", role: "Pulls water into the surface layers" },
      { name: "Vitamin E", role: "Antioxidant support and keeps the oils stable" }
    ],
    directions:
      "Smooth over the body after a shower while the skin is still slightly damp, which is when a lotion holds the most water in. Reapply to shins and hands through the day if they dry out.",
    reviews: [
      { who: "Sandrine U.", city: "Gisozi, Kigali", rating: 5, date: "March 2026", text: "Smells amazing and my skin drinks it. I bought a second bottle for my sister." },
      { who: "Fiona M.", city: "Kigali", rating: 4.5, date: "February 2026", text: "Light, not greasy, and the scent stays for hours. The bottle is bigger than I expected." }
    ],
    faqs: [
      { q: "Is the scent strong?", a: "It is a perfumed lotion, so yes — the scent is part of what people buy it for. If you want unscented, take the CeraVe or the Bioderma Atoderm instead." },
      { q: "Can I use it on my face?", a: "Keep it to the body. Facial skin is thinner and the fragrance is chosen for the body." }
    ]
  },
  {
    id: "eos-shea-better-creme-de-pistachio",
    photos: ["assets/img/eos-shea-better-creme-de-pistachio.jpg"],
    name: "Shea Better 24H Moisture Body Lotion — Crème de Pistachio",
    brand: "EOS",
    brandId: "eos",
    price: 19000,
    size: "473 ml",
    form: "bottle",
    tint: "#a8d5c8",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["body-dryness"],
    rating: 4.6,
    reviewCount: 18,
    texture: "Whipped cream lotion that absorbs fast",
    short:
      "The pistachio one: sweet, nutty and warm, on the same shea-and-seven-oils base as the rest of the Shea Better line.",
    benefits: [
      "Same 24-hour shea formula as the rest of the line, in the softest of the scents",
      "Absorbs without a film, so it works under clothes and in the evening after a shower",
      "Shea butter and seven oils and butters keep dry knees and elbows comfortable rather than just softening the top layer",
      "473 ml means it is a daily habit rather than a treat you ration"
    ],
    ingredients: [
      { name: "Shea butter", role: "Locks moisture into dry skin" },
      { name: "Seven oils and butters", role: "Nourish and soften the skin over the day" },
      { name: "Glycerin", role: "Holds water in the upper layers" },
      { name: "Vitamin E", role: "Antioxidant support for skin that has been in the sun" }
    ],
    directions:
      "Apply to damp skin after showering, working it into the shins, elbows and heels. It layers well under sunscreen on exposed arms and legs.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "The smell is the best of the four. Warm and not too sweet, and my legs stopped feeling tight." },
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 4, date: "January 2026", text: "Lovely texture. The scent is strong on the first few minutes then settles." }
    ],
    faqs: [
      { q: "Are the EOS lotions all the same formula?", a: "The base is the same — shea butter and seven oils — and only the fragrance changes. Choose on the scent you will not get tired of." },
      { q: "Will it help very dry, ashy skin?", a: "It moisturises well, but for cracked heels and true ashiness the richer Bioderma Atoderm or the Vaseline Gluta-Hya serum works harder." }
    ]
  },
  {
    id: "eos-shea-better-fresh-cozy",
    photos: ["assets/img/eos-shea-better-fresh-cozy.jpg"],
    name: "Shea Better 24H Moisture Body Lotion — Fresh + Cozy",
    brand: "EOS",
    brandId: "eos",
    price: 19000,
    size: "473 ml",
    form: "bottle",
    tint: "#e8a7bd",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["body-dryness"],
    rating: 4.6,
    reviewCount: 16,
    texture: "Whipped cream lotion that absorbs fast",
    short:
      "Clean laundry and soft musk over shea butter and seven oils — the everyday unisex one in the Shea Better range.",
    benefits: [
      "24 hours of moisture from shea butter, without the thick layer most rich lotions leave behind",
      "The lightest scent in the range, so it does not fight with a perfume",
      "Suitable for sensitive skin, as printed on the bottle",
      "Absorbs fast enough for a morning routine that has no extra minute in it"
    ],
    ingredients: [
      { name: "Shea butter", role: "Conditions and seals in moisture" },
      { name: "Seven oils and butters", role: "Replenish the skin's lipids after washing" },
      { name: "Glycerin", role: "Attracts water to the skin surface" },
      { name: "Vitamin E", role: "Antioxidant support and formula stability" }
    ],
    directions:
      "Use after every shower on damp skin, and again on hands through the day. For a stronger treatment on heels, layer it under the Vaseline Cocoa Radiant oil at night.",
    reviews: [
      { who: "Samuel T.", city: "Rubavu", rating: 4.5, date: "February 2026", text: "I wanted something light that did not smell of flowers. This one is that." },
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 4.5, date: "March 2026", text: "Soft, clean scent and it soaks in straight away. Good size for the price." }
    ],
    faqs: [
      { q: "Is it a men's lotion?", a: "It is not gendered — the scent is a soft fresh one that most people read as neutral. The formula is the same as the rest of the line." },
      { q: "How long does a bottle last?", a: "Used daily on arms and legs, about four to six weeks. Twice a day, three." }
    ]
  },
  {
    id: "eos-shea-better-vanilla-cashmere",
    photos: ["assets/img/eos-shea-better-vanilla-cashmere.jpg"],
    name: "Shea Better 24H Moisture Body Lotion — Vanilla Cashmere",
    brand: "EOS",
    brandId: "eos",
    price: 19000,
    size: "473 ml",
    form: "bottle",
    tint: "#c9b7e0",
    category: "body-care",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["body-dryness"],
    rating: 4.9,
    reviewCount: 37,
    texture: "Whipped cream lotion that absorbs fast",
    short:
      "The famous one: warm vanilla and cashmere musk over a shea butter base, in the lavender bottle that keeps selling out.",
    benefits: [
      "The scent people buy the whole range for — vanilla, warm and soft rather than sugary",
      "Shea butter and seven oils give 24-hour moisture without a heavy finish",
      "Absorbs straight in, so it works on the way out of the door as well as after a bath",
      "Suitable for sensitive skin and made with natural shea, as printed on the bottle"
    ],
    ingredients: [
      { name: "Shea butter", role: "Seals moisture in and softens rough patches" },
      { name: "Seven oils and butters", role: "Restore what washing strips out of the skin" },
      { name: "Glycerin", role: "Keeps the skin hydrated through the day" },
      { name: "Vitamin E", role: "Antioxidant support" }
    ],
    directions:
      "Massage into damp skin after showering, paying attention to shins, elbows and the backs of the arms. Reapply to hands and wrists before bed if you want the scent to linger.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "I get asked what perfume I wear. It is this. Skin stays soft all day too." },
      { who: "Sandrine U.", city: "Gisozi, Kigali", rating: 5, date: "February 2026", text: "Worth the hype. The vanilla is warm, not sickly, and the lotion is not heavy." }
    ],
    faqs: [
      { q: "Is the fragrance too strong for sensitive skin?", a: "The bottle says suitable for sensitive skin, but a perfumed lotion is a perfumed lotion. If your skin reacts to fragrance, choose the unscented CeraVe or Bioderma instead." },
      { q: "Does it layer under sunscreen?", a: "Yes, and it is worth doing on exposed legs and arms. Give it a minute before the sunscreen." }
    ]
  },
  {
    id: "eos-shea-better-pink-champagne",
    photos: ["assets/img/eos-shea-better-pink-champagne.jpg"],
    name: "Shea Better 24H Moisture Body Lotion — Pink Champagne",
    brand: "EOS",
    brandId: "eos",
    price: 19000,
    size: "473 ml",
    form: "bottle",
    tint: "#f0c6c6",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["body-dryness"],
    rating: 4.5,
    reviewCount: 14,
    texture: "Whipped cream lotion that absorbs fast",
    short:
      "Fruity, sparkling and pink: the same shea butter and seven-oil formula, with the scent for people who want the lotion to be the fun part.",
    benefits: [
      "Shea butter base gives 24-hour moisture, so the scent is not the only thing it does",
      "Light and fast-absorbing, which matters in Kigali heat",
      "A bottle that looks good on the shelf and gets used because of it",
      "Suitable for sensitive skin, as printed on the bottle"
    ],
    ingredients: [
      { name: "Shea butter", role: "Softens and seals moisture into the skin" },
      { name: "Seven oils and butters", role: "Nourish dry skin after washing" },
      { name: "Glycerin", role: "Holds water in the upper layers" },
      { name: "Vitamin E", role: "Antioxidant support and stability" }
    ],
    directions:
      "Apply after a shower to damp skin, and again on hands and arms before going out. Keep it below the jaw.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4.5, date: "March 2026", text: "It smells like a celebration and it actually moisturises. My daughter keeps borrowing it." },
      { who: "Clarisse U.", city: "Nyarutarama, Kigali", rating: 4, date: "February 2026", text: "Pleasant and light. I prefer the vanilla, but the texture is just as good." }
    ],
    faqs: [
      { q: "How does it differ from the Vanilla Cashmere?", a: "Only the scent. The base — shea butter and seven oils — is the same across the line." },
      { q: "Is it a good gift?", a: "It is the one people are happiest to be given, yes. The bottle is the reason." }
    ]
  },

  /* ────────────────────────────────────────────────────────── Vaseline */
  {
    id: "vaseline-healthy-bright-daily-brightening-lotion",
    photos: ["assets/img/vaseline-healthy-bright-daily-brightening-lotion.jpg"],
    name: "Healthy Bright Daily Brightening Even Tone Lotion",
    brand: "Vaseline",
    brandId: "vaseline",
    price: 17000,
    size: "600 ml",
    form: "pump",
    tint: "#e8a0b4",
    category: "body-care",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["body-dryness", "dark-spots", "hyperpigmentation", "dullness"],
    rating: 4.7,
    reviewCount: 52,
    texture: "Light lotion with a soft finish",
    short:
      "Niacinamide and Vaseline jelly in a 600 ml pump bottle: the body lotion for dark knuckles, uneven legs and a tone that never quite evens out.",
    benefits: [
      "Niacinamide (vitamin B3) is the ingredient that actually shifts body pigmentation over weeks of daily use",
      "Vaseline jelly in the base holds moisture in, which is why dry, ashy legs stop looking grey rather than just feeling better",
      "The formula carries sunscreens, so the daily walk does not undo the evening-out you paid for",
      "600 ml with a pump: the whole body, twice a day, without rationing"
    ],
    ingredients: [
      { name: "Niacinamide (vitamin B3)", role: "Evens tone and fades the look of dark marks over weeks" },
      { name: "Vaseline jelly (petrolatum)", role: "Seals moisture in better than almost anything else" },
      { name: "Glycerin", role: "Draws water into the skin" },
      { name: "Sunscreens", role: "Limit the new pigmentation that daylight causes" }
    ],
    directions:
      "Use on the whole body after showering, twice a day if you can, on damp skin. Knuckles, knees and elbows take the most. Pigmentation on the body takes eight to twelve weeks of consistency — take a photo on day one so you can see it working.",
    reviews: [
      { who: "Aimable N.", city: "Rwamagana", rating: 5, date: "March 2026", text: "My knees and knuckles are noticeably lighter after two months. I use it every night without fail." },
      { who: "Fiona M.", city: "Kigali", rating: 4.5, date: "February 2026", text: "The big pump bottle is the reason I stick with it. Legs look even now." }
    ],
    faqs: [
      { q: "How long before I see a difference?", a: "On the body, eight to twelve weeks of twice-daily use for pigmentation, faster for the dry, grey look of dehydrated skin — that improves within a week." },
      { q: "Does it make skin lighter permanently?", a: "No, and it should not be sold as if it does. Niacinamide evens the tone by calming pigment production and supporting the barrier; stop using it and your natural tone is what returns." }
    ]
  },
  {
    id: "vaseline-gluta-hya-serum-burst-uv-flawless-bright",
    photos: ["assets/img/vaseline-gluta-hya-serum-burst-uv-flawless-bright.jpg"],
    name: "Gluta-Hya Serum Burst UV Lotion — Flawless Bright",
    brand: "Vaseline",
    brandId: "vaseline",
    price: 9000,
    size: "130 ml",
    form: "tube",
    tint: "#f2b8c6",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["dark-spots", "hyperpigmentation", "body-dryness"],
    rating: 4.6,
    reviewCount: 31,
    texture: "Serum-in-lotion that bursts to water",
    short:
      "GlutaGlow, hyaluron and pro-retinol in a serum lotion that sinks in instantly and carries sunscreens — for the arms and neck you forget about.",
    benefits: [
      "The serum-in-lotion texture disappears into the skin, so it is comfortable on a hot day and under clothes",
      "GlutaGlow and pro-retinol work on the dark spots and marks that body lotion usually ignores",
      "Hyaluronic acid and Vaseline jelly keep the skin hydrated while the actives work",
      "It carries UV protection, which is what stops new marks forming on arms and neck"
    ],
    ingredients: [
      { name: "GlutaGlow (glutathione complex)", role: "Works on uneven tone and dullness" },
      { name: "Pro-retinol", role: "Speeds up the surface renewal that fades marks" },
      { name: "Hyaluronic acid", role: "Hydrates the surface layers" },
      { name: "Sunscreens", role: "Limit the daylight that keeps pigmentation in place" }
    ],
    directions:
      "Apply to arms, neck and any area you are working on, morning and evening. If you are using it during the day, the sunscreen in it is a help but not a substitute for a proper SPF on the face.",
    reviews: [
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 5, date: "March 2026", text: "My elbows and the marks on my arms faded a lot over two months. It also smells lovely." },
      { who: "Olivier N.", city: "Huye", rating: 4, date: "February 2026", text: "Absorbs instantly and the tube fits in a bag. I wish it came in a bigger size." }
    ],
    faqs: [
      { q: "Can I use it on my face?", a: "It is a body product. The face has its own sunscreen and actives, and the fragrance here is chosen for the body." },
      { q: "Is the pro-retinol strong?", a: "At body-lotion strength it is mild, but if you have not used retinoids before, start once a day and stop if the skin flakes." }
    ]
  },
  {
    id: "vaseline-gluta-hya-dewy-radiance-serum-in-lotion",
    photos: ["assets/img/vaseline-gluta-hya-dewy-radiance-serum-in-lotion.jpg"],
    name: "Gluta-Hya Dewy Radiance Serum-in-Lotion",
    brand: "Vaseline",
    brandId: "vaseline",
    price: 12000,
    size: "200 ml",
    form: "tube",
    tint: "#f0d29a",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["dullness", "body-dryness", "dark-spots"],
    rating: 4.5,
    reviewCount: 22,
    texture: "Watery serum lotion, non-sticky",
    short:
      "GlutaGlow with hyaluronic acid and niacinamide in a non-sticky serum lotion — the glow one, for dull skin with no shine to it.",
    benefits: [
      "Delivers the glow rather than the gloss: it finishes matte-ish and non-sticky, which is rare in a brightening lotion",
      "Hyaluronic acid plumps dehydrated skin so it reflects light instead of looking tired",
      "Niacinamide keeps working on uneven tone alongside the glutathione",
      "200 ml in a tube that goes in a bag for the office or the gym"
    ],
    ingredients: [
      { name: "GlutaGlow (glutathione complex)", role: "Supports brighter, more even-looking skin" },
      { name: "Hyaluronic acid", role: "Hydrates and gives the surface that lit-from-within look" },
      { name: "Niacinamide", role: "Evens tone and supports the barrier" },
      { name: "Vaseline jelly (petrolatum)", role: "Holds the moisture in place" }
    ],
    directions:
      "Apply after a shower, morning and night, on damp skin. Layer under sunscreen on exposed arms and legs during the day — the glow is worth keeping, and so is the tone you have worked for.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 4.5, date: "March 2026", text: "My arms look much less dull and it is genuinely not sticky, which I did not expect." },
      { who: "Samuel T.", city: "Rubavu", rating: 4.5, date: "January 2026", text: "Light, absorbs fast, no shine on clothes. Good everyday lotion." }
    ],
    faqs: [
      { q: "What is the difference from the Flawless Bright?", a: "Flawless Bright is the one aimed at dark spots and marks, with pro-retinol and sunscreen in it. This is the hydration-and-glow one. They layer fine if you want both." },
      { q: "Will it make my skin oily?", a: "No. It is the least sticky of the Vaseline serum lotions, which is why people use it in the day." }
    ]
  },
  {
    id: "vaseline-cocoa-radiant-body-oil",
    photos: ["assets/img/vaseline-cocoa-radiant-body-oil.jpg"],
    name: "Cocoa Radiant Body Oil",
    brand: "Vaseline",
    brandId: "vaseline",
    price: 15000,
    size: "200 ml",
    form: "bottle",
    tint: "#c98a4b",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination"],
    concerns: ["body-dryness", "dullness"],
    rating: 4.6,
    reviewCount: 19,
    texture: "Gel oil that turns silky",
    short:
      "A gel oil with pure cocoa butter that gives dry skin the shine a lotion cannot — for legs, shoulders and anywhere the light should catch.",
    benefits: [
      "Gel oil rather than a straight oil: it glides on without the greasy drip and leaves a sheen instead of a film",
      "100% pure cocoa butter is what makes dry, dull skin look healthy rather than just moisturised",
      "A few drops go a long way, so 200 ml lasts through a season",
      "The evening step that makes a body lotion work harder — oil over lotion is the standard order on very dry skin"
    ],
    ingredients: [
      { name: "Cocoa butter", role: "Rich occlusive that softens dry, rough skin" },
      { name: "Mineral and plant oils", role: "Give the glide and the sheen" },
      { name: "Vitamin E", role: "Antioxidant support" },
      { name: "Fragrance (cocoa butter scent)", role: "The warm cocoa scent the line is known for" }
    ],
    directions:
      "Warm a few drops between the palms and smooth over the body after a shower, or over body lotion at night on very dry legs and heels. Not for the face; rinse the soles of the feet before walking on tiles.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "February 2026", text: "My legs glow. I use it on top of lotion at night and the ashiness is gone." },
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4, date: "January 2026", text: "Lovely sheen, warm smell. Use less than you think or it takes a while to settle." }
    ],
    faqs: [
      { q: "Is it greasy?", a: "It is an oil, so it needs a few minutes. Use four or five drops and it settles to a sheen rather than a grease." },
      { q: "Oil or lotion first?", a: "Lotion first on damp skin, oil over the top to seal it — that order is what makes either one last the night." }
    ]
  },

  /* ────────────────────────────────────────────────────── The Ordinary */
  {
    id: "the-ordinary-hyaluronic-acid-2-b5",
    photos: ["assets/img/the-ordinary-hyaluronic-acid-2-b5.jpg"],
    name: "Hyaluronic Acid 2% + B5",
    brand: "The Ordinary",
    brandId: "the-ordinary",
    price: 18000,
    size: "30 ml",
    form: "dropper",
    tint: "#c9b48a",
    category: "serums",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["dryness", "fine-lines", "dullness"],
    rating: 4.7,
    reviewCount: 63,
    texture: "Light serum, slightly tacky as it dries",
    short:
      "Three molecular weights of hyaluronic acid and vitamin B5 in water — the simplest way to put water back into skin that feels tight by noon.",
    benefits: [
      "Hyaluronic acid at three molecular weights hydrates the surface and a little below it, which is why it plumps rather than just wets the skin",
      "Vitamin B5 (panthenol) supports the barrier while it hydrates, so the water stays where it was put",
      "Sits under anything: moisturiser, sunscreen, makeup, morning or night",
      "30 ml at this price is the cheapest step in a routine that actually does something"
    ],
    ingredients: [
      { name: "Hyaluronic acid (three molecular weights)", role: "Holds water in the upper layers of the skin" },
      { name: "Vitamin B5 (panthenol)", role: "Supports the barrier and calms tightness" },
      { name: "Water-based, oil-free base", role: "Layers under anything without pilling" }
    ],
    directions:
      "Apply two or three drops to damp skin after cleansing, before moisturiser, morning and evening. On its own in a dry room it can draw water the wrong way, so always seal it with a moisturiser.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "My skin stopped feeling tight by lunchtime. It is cheap and it just works." },
      { who: "Patrick H.", city: "Nyarugenge, Kigali", rating: 4.5, date: "February 2026", text: "Slightly sticky for a minute, then it is gone. I use it under the CeraVe lotion." }
    ],
    faqs: [
      { q: "Is it a moisturiser?", a: "No. It is water held in place — it needs a moisturiser on top to seal it, or it will evaporate and take your skin's water with it." }
    ]
  },
  {
    id: "the-ordinary-retinol-0-2-in-squalane",
    photos: ["assets/img/the-ordinary-retinol-0-2-in-squalane.jpg"],
    name: "Retinol 0.2% in Squalane",
    brand: "The Ordinary",
    brandId: "the-ordinary",
    price: 19000,
    size: "30 ml",
    form: "dropper",
    tint: "#b08a5a",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["fine-lines", "large-pores", "dark-spots", "dullness"],
    rating: 4.6,
    reviewCount: 41,
    texture: "Light oil, no water at all",
    short:
      "A water-free 0.2% retinol in squalane — the gentlest way into retinoids, for texture, pores and the first fine lines.",
    benefits: [
      "0.2% is a starting strength: enough to change turnover, mild enough that most people do not peel",
      "Squalane carries the retinol and replaces the lipids retinol makes the skin shed faster",
      "Water-free, so the retinol stays stable instead of degrading in the bottle",
      "The first step before a 0.5% or a retinal — and the one to come back to if the stronger ones sting"
    ],
    ingredients: [
      { name: "Retinol 0.2%", role: "Speeds up cell turnover for smoother texture and fewer visible lines" },
      { name: "Squalane", role: "A skin-identical oil that cushions the retinol and holds moisture in" },
      { name: "Caprylic/capric triglyceride", role: "Light carrier that spreads the retinol evenly" }
    ],
    directions:
      "At night only: three or four drops on clean dry skin, then moisturiser. Start twice a week for two weeks, then every other night. Sunscreen every morning without exception. Not in pregnancy or while breastfeeding.",
    reviews: [
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "No peeling at all and my skin is visibly smoother after six weeks. The oil texture suits my dry skin." },
      { who: "Samuel T.", city: "Rubavu", rating: 4, date: "January 2026", text: "I had a little flaking in week two and it settled. Go slowly and it is fine." }
    ],
    faqs: [
      { q: "Can I use it with the salicylic acid?", a: "Not on the same night at first. Alternate them, and keep sunscreen in the morning." }
    ]
  },
  {
    id: "the-ordinary-salicylic-acid-2-solution",
    photos: ["assets/img/the-ordinary-salicylic-acid-2-solution.jpg"],
    name: "Salicylic Acid 2% Solution",
    brand: "The Ordinary",
    brandId: "the-ordinary",
    price: 17000,
    size: "30 ml",
    form: "dropper",
    tint: "#a8c0d8",
    category: "acne-care",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["oily", "combination", "normal"],
    concerns: ["acne", "large-pores", "oiliness", "post-acne-marks"],
    rating: 4.6,
    reviewCount: 57,
    texture: "Watery solution, thin as water",
    short:
      "2% salicylic acid in a water base — the leave-on version of the acid that clears blackheads from inside the pore.",
    benefits: [
      "Salicylic acid is oil-soluble, so it gets into the pore lining where blackheads actually form",
      "A leave-on solution does what a salicylic wash cannot: it stays on the skin long enough to work",
      "Clears congestion on the nose, chin and forehead without scrubbing at it",
      "Cheap enough to use consistently, which is the only thing that makes an acid work"
    ],
    ingredients: [
      { name: "Salicylic acid 2%", role: "Exfoliates inside the pore and reduces blackheads and congestion" },
      { name: "Witch hazel and other water-based carriers", role: "Thin, fast-drying base that does not sit greasy" },
      { name: "pH-balanced vehicle", role: "Keeps the acid active without being harsh" }
    ],
    directions:
      "Once a day at most, on clean dry skin, on the areas that actually need it — nose, chin, forehead. Let it dry, then moisturiser. Sunscreen every morning. Do not use it on the same night as retinol while you are starting out.",
    reviews: [
      { who: "Sandrine B.", city: "Muhanga", rating: 5, date: "March 2026", text: "The blackheads on my nose went down in three weeks. It does dry my chin, so I only use it there every other night." },
      { who: "Kevin M.", city: "Nyamirambo, Kigali", rating: 4, date: "February 2026", text: "Works, but respect it. I overdid it in the first week and had to stop for three days." }
    ],
    faqs: [
      { q: "Does it sting?", a: "It can tingle for a minute, especially on broken skin. If it burns rather than tingles, wash it off and use it every second night instead." }
    ]
  },

  /* ──────────────────────────────────────────────────────── Anua (new) */
  {
    id: "anua-pdrn-hyaluron-100-moisturizing-cream",
    photos: ["assets/img/anua-pdrn-hyaluron-100-moisturizing-cream.jpg"],
    name: "PDRN + Hyaluronic Acid 100 Moisturizing Cream",
    brand: "Anua",
    brandId: "anua",
    price: 38000,
    size: "50 ml",
    form: "tube",
    tint: "#5fb8b0",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dryness", "fine-lines", "dullness", "sensitivity"],
    rating: 4.7,
    reviewCount: 26,
    texture: "Cream that melts in without a film",
    short:
      "The cream half of Anua's PDRN pair: repair and hydration in a texture light enough for a Kigali morning.",
    benefits: [
      "PDRN supports the skin's repair, which is what you want under a sunscreen all day rather than a bare barrier",
      "Hyaluronic acid and panthenol mean the repair happens on hydrated skin, which is the only state it happens in",
      "Finishes without a film, so it sits under sunscreen and makeup without rolling",
      "Layers with the PDRN serum for a full repair routine, or stands alone on the nights you want one step"
    ],
    ingredients: [
      { name: "PDRN (salmon DNA fragment)", role: "Supports the skin's own repair processes" },
      { name: "Hyaluronic acid", role: "Holds water in the upper layers so the cream reads as comfort, not weight" },
      { name: "Panthenol", role: "Soothes and holds moisture in a stressed barrier" },
      { name: "Ceramide support", role: "Tops up the lipids a barrier loses in the dry season" }
    ],
    directions:
      "Morning and evening as the last step before sunscreen. A pea-sized amount covers the face and neck; more is not better with this one.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 5, date: "March 2026", text: "Light but it really holds. No film under my sunscreen and my cheeks are less tight." },
      { who: "Olivier N.", city: "Huye", rating: 4.5, date: "February 2026", text: "I use it with the serum at night. Combo skin, no breakouts from it." }
    ],
    faqs: [
      { q: "Is it enough on its own at night?", a: "For normal and combination skin, yes. Very dry skin will want an oil or a richer cream on top in the dry season." }
    ]
  },
  {
    id: "anua-pdrn-hyaluron-capsule-mist",
    photos: ["assets/img/anua-pdrn-hyaluron-capsule-mist.jpg"],
    name: "PDRN + Hyaluron Hydrating Capsule Mist",
    brand: "Anua",
    brandId: "anua",
    price: 34000,
    size: "100 ml",
    form: "bottle",
    tint: "#7fd0c8",
    category: "toners",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dryness", "dullness", "sensitivity"],
    rating: 4.6,
    reviewCount: 19,
    texture: "Fine mist, dries without stickiness",
    short:
      "A hydrating mist with PDRN and hyaluronic acid to put water back into the skin between steps, under makeup, or after a day in the sun.",
    benefits: [
      "A fine, even mist — it sets rather than settles into droplets that drag your makeup",
      "Hyaluronic acid and PDRN hydrate and support repair in the same pass, which is what a mist usually skips",
      "Useful as a first step on damp skin before serum, and again in the afternoon over makeup",
      "100 ml fits in a bag, which is the only reason a mist gets used twice a day"
    ],
    ingredients: [
      { name: "PDRN (salmon DNA fragment)", role: "Supports repair and recovery" },
      { name: "Hyaluronic acid", role: "Holds water in the skin's surface layers" },
      { name: "Panthenol", role: "Calms and softens" }
    ],
    directions:
      "Spritz 20 cm from the face, eyes closed, before serum in the morning and again whenever skin feels tight. Follow with moisturiser in the first use; over makeup it is a top-up, not a step.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 5, date: "March 2026", text: "The mist is genuinely fine, not a wet slap. I keep it in my bag for the afternoon." },
      { who: "Fiona M.", city: "Kigali", rating: 4, date: "February 2026", text: "Nice over makeup without wrecking it. Slight scent, which I do not mind." }
    ],
    faqs: [
      { q: "Can a mist replace a toner?", a: "It can replace a watery hydrating toner, yes. It cannot replace a treatment toner with acids or niacinamide." }
    ]
  },

  /* ──────────────────────────────────────────────────────── Arencia */
  {
    id: "arencia-txa-booster-shot-serum",
    photos: ["assets/img/arencia-txa-booster-shot-serum.jpg"],
    name: "TXA Booster Shot Serum 5% Tranexamic Acid",
    brand: "Arencia",
    brandId: "arencia",
    price: 42000,
    size: "30 ml",
    form: "dropper",
    tint: "#e07a9a",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily", "sensitive"],
    concerns: ["dark-spots", "hyperpigmentation", "post-acne-marks", "dullness"],
    rating: 4.8,
    reviewCount: 33,
    texture: "Light watery serum",
    short:
      "5% tranexamic acid with peptides: the acid that works on stubborn marks and redness without the sting of the vitamin C serums.",
    benefits: [
      "Tranexamic acid is the ingredient dermatologists reach for on melasma and stubborn post-acne marks, and 5% is a real dose",
      "It does not sting or tingle, which is why it suits skin that cannot tolerate vitamin C",
      "Peptides support the skin while the marks fade, so the improvement is not just surface-level",
      "Layers under sunscreen every morning — and sunscreen is what stops the marks coming back"
    ],
    ingredients: [
      { name: "Tranexamic acid 5%", role: "Interrupts the pigmentation pathway behind stubborn marks and redness" },
      { name: "Peptide complex", role: "Supports firmness and the skin's repair" },
      { name: "Niacinamide", role: "Evens tone alongside the TXA" },
      { name: "Hyaluronic acid", role: "Keeps the serum hydrating rather than drying" }
    ],
    directions:
      "Two or three drops morning and evening on the marks and the whole face, before moisturiser. Give it eight weeks — pigmentation is a slow argument. Sunscreen every morning or the marks will simply re-form.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 5, date: "March 2026", text: "The marks on my cheeks have faded more in two months than with anything else I tried. And no stinging." },
      { who: "Yvette M.", city: "Musanze", rating: 4.5, date: "February 2026", text: "Gentle and it layers well. I use it with the vitamin C shot in the morning." }
    ],
    faqs: [
      { q: "TXA or vitamin C?", a: "TXA for marks and redness, especially if vitamin C stings you. Vitamin C for dullness and overall brightness. They layer fine if you want both." }
    ]
  },

  /* ──────────────────────────────────────────────────────── Bioderma */
  {
    id: "bioderma-sebium-gel-moussant",
    photos: ["assets/img/bioderma-sebium-gel-moussant.jpg"],
    name: "Sébium Gel Moussant Purifying Cleansing Gel",
    brand: "Bioderma",
    brandId: "bioderma",
    price: 30000,
    size: "500 ml",
    form: "pump",
    tint: "#2e6fa8",
    category: "cleansers",
    also: ["acne-care"],
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination"],
    concerns: ["oiliness", "acne", "large-pores"],
    rating: 4.7,
    reviewCount: 44,
    texture: "Clear gel that foams lightly",
    short:
      "Bioderma's cleansing gel for combination to oily skin: it clears oil and shines without the tight, squeaky finish that makes skin produce more.",
    benefits: [
      "The half-litre pump is the size that makes a proper cleanser affordable enough to use twice a day",
      "Formulated at the skin's pH, so it does not strip the barrier the way soap-based gels do",
      "Dermatologically tested and designed for combination to oily skin that also reacts — the awkward combination",
      "Works as the first step in an acne routine without fighting the actives that come after it"
    ],
    ingredients: [
      { name: "Zinc gluconate", role: "Helps regulate sebum and keeps the finish clean" },
      { name: "Copper sulfate", role: "Purifies and supports the skin's balance" },
      { name: "Gentle foaming surfactants", role: "Lift oil without stripping the barrier" },
      { name: "Bioderma's physiological pH base", role: "Respects the skin's own acidity" }
    ],
    directions:
      "Lather in wet hands, massage over the face for thirty seconds, rinse. Morning and evening. Follow with moisturiser — oily skin still needs one, just a light one.",
    reviews: [
      { who: "Patrick H.", city: "Nyarugenge, Kigali", rating: 5, date: "March 2026", text: "The big bottle lasts months and my face is not shiny by mid-morning. No tight feeling at all." },
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 4.5, date: "January 2026", text: "Good for my oily T-zone and it does not leave residue." }
    ],
    faqs: [
      { q: "Is it the same as the Sébium H2O micellar water?", a: "No — the H2O is a no-rinse micellar water for makeup and the morning, and this is a foaming gel for a proper wash. Many people keep both." }
    ]
  },

  /* ───────────────────────────────────────────────── Beauty of Joseon */
  {
    id: "beauty-of-joseon-relief-sun-aqua-fresh",
    photos: ["assets/img/beauty-of-joseon-relief-sun-aqua-fresh.jpg"],
    name: "Relief Sun Aqua-fresh Rice + B5 SPF 50+",
    brand: "Beauty of Joseon",
    brandId: "beauty-of-joseon",
    price: 28000,
    size: "50 ml",
    form: "tube",
    tint: "#7fb0d8",
    category: "sunscreens",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["oily", "combination", "normal", "sensitive"],
    concerns: ["dark-spots", "oiliness", "sensitivity"],
    rating: 4.8,
    reviewCount: 39,
    texture: "Watery, weightless cream",
    short:
      "The lighter sibling of the famous Relief Sun: rice extract and vitamin B5 under SPF 50+ PA++++, in a texture that disappears on oily and combination skin.",
    benefits: [
      "Aqua-fresh rather than creamy, which is what makes it wearable in Kigali heat and under makeup",
      "No white cast, no greasy film, no pilling — the three reasons people stop wearing sunscreen",
      "Rice extract and panthenol soothe while the filters do the work, so skin that reacts to sunscreen can often wear this one",
      "SPF 50+ PA++++ every day is the single most effective anti-pigmentation step in any routine"
    ],
    ingredients: [
      { name: "Broad-spectrum UV filters (SPF 50+ / PA+++)", role: "Protection against burning and against pigmentation" },
      { name: "Rice extract", role: "Soothes and brightens over time" },
      { name: "Vitamin B5 (panthenol)", role: "Calms and holds moisture in" },
      { name: "Hyaluronic acid", role: "Keeps the finish hydrating rather than tight" }
    ],
    directions:
      "Two finger-lengths on face, ears and neck every morning as the last step. Reapply every two to three hours if you are outside. On a moto or in a car, remember the neck and the backs of the hands.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 5, date: "March 2026", text: "So light I forget I am wearing it, and my makeup goes on over it without pilling." },
      { who: "Samuel T.", city: "Rubavu", rating: 4.5, date: "February 2026", text: "My oily forehead usually shines with sunscreen. This one does not." }
    ],
    faqs: [
      { q: "Relief Sun or Aqua-fresh?", a: "The original Relief Sun is creamier and suits dry skin; this one is lighter and suits oily and combination skin. Same protection." }
    ]
  },

  /* ───────────────────────────────────────────────────────────── AXIS-Y */
  {
    id: "axis-y-dark-spot-correcting-glow-serum",
    photos: ["assets/img/axis-y-dark-spot-correcting-glow-serum.jpg"],
    name: "Dark Spot Correcting Glow Serum",
    brand: "AXIS-Y",
    brandId: "axis-y",
    price: 34000,
    size: "50 ml",
    form: "tube",
    tint: "#7fb871",
    category: "serums",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["normal", "dry", "combination", "oily", "sensitive"],
    concerns: ["dark-spots", "hyperpigmentation", "post-acne-marks", "dullness"],
    rating: 4.8,
    reviewCount: 47,
    texture: "Light gel serum",
    short:
      "5% niacinamide in AXIS-Y's 6+1+1 formula: the serum for marks, uneven tone and the dullness that comes with them.",
    benefits: [
      "5% niacinamide is the dose with evidence behind it for marks and tone — not a token sprinkle",
      "Calendula and squalane keep it comfortable, so it does not sting the way vitamin C serums can",
      "Light gel that layers under sunscreen in the morning without any pilling",
      "50 ml, not 30 — it lasts long enough for pigmentation, which is an eight-to-twelve-week job"
    ],
    ingredients: [
      { name: "Niacinamide 5%", role: "Evens tone and fades the look of dark marks" },
      { name: "Calendula extract", role: "Calms redness around the marks" },
      { name: "Squalane", role: "Keeps the serum from drying the skin as it works" },
      { name: "Hippophae rhamnoides (sea buckthorn) water", role: "Antioxidant support for dull skin" }
    ],
    directions:
      "Apply a pea-sized amount morning and evening before moisturiser, on the marks and the whole face. Sunscreen in the morning is not optional — without it the marks re-form faster than the serum fades them.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 5, date: "March 2026", text: "Three months and the marks from old breakouts are much lighter. It is also the only serum that never stings me." },
      { who: "Kevin M.", city: "Nyamirambo, Kigali", rating: 4.5, date: "February 2026", text: "Light, absorbs fast, no pilling under sunscreen. My skin looks more even overall." }
    ],
    faqs: [
      { q: "Can I use it with vitamin C?", a: "Yes — in the morning with vitamin C and sunscreen, or alternate them. If your skin is sensitive, keep one in the morning and the other at night." }
    ]
  },
  {
    id: "axis-y-dark-spot-correcting-glow-toner",
    photos: ["assets/img/axis-y-dark-spot-correcting-glow-toner.jpg"],
    name: "Dark Spot Correcting Glow Toner",
    brand: "AXIS-Y",
    brandId: "axis-y",
    price: 30000,
    size: "125 ml",
    form: "bottle",
    tint: "#a8c98f",
    category: "toners",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily", "sensitive"],
    concerns: ["dark-spots", "hyperpigmentation", "dullness", "dryness"],
    rating: 4.6,
    reviewCount: 28,
    texture: "Watery hydrating toner",
    short:
      "The toner step for the same job as the serum: willow bark, niacinamide and hyaluronic acid to prepare skin and start evening out the tone.",
    benefits: [
      "Willow bark brings a gentle salicin exfoliation that helps marks fade without the sting of a glycolic toner",
      "Hyaluronic acid in the base means it hydrates while it works, so the toner is not a drying step",
      "125 ml is generous for a toner and the pump dispenses in drops rather than floods the cotton pad",
      "Pairs with the serum and cream in the same line, so the whole routine points one way"
    ],
    ingredients: [
      { name: "Salix alba (willow) bark extract", role: "Gentle exfoliation that helps the surface shed marks" },
      { name: "Niacinamide", role: "Evens tone and calms redness" },
      { name: "Hyaluronic acid", role: "Hydrates the layers below the surface" },
      { name: "Centella asiatica", role: "Soothes skin that reacts easily" }
    ],
    directions:
      "After cleansing, dispense a few drops into damp palms and press over the face, or onto a cotton pad and sweep. Follow with serum and moisturiser. Morning and evening.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "My skin drinks it. It is hydrating rather than that tight feeling some toners leave." },
      { who: "Thierry B.", city: "Musanze", rating: 4, date: "February 2026", text: "Use it with the serum and the glow is real. Not a fast fix, but steady." }
    ],
    faqs: [
      { q: "Is it an exfoliating toner?", a: "Mildly — willow bark, not an acid. It is safe to use daily; if you are on a strong AHA or a retinol, cut it to once a day." }
    ]
  },
  {
    id: "axis-y-dark-spot-correcting-glow-cream",
    photos: ["assets/img/axis-y-dark-spot-correcting-glow-cream.jpg"],
    name: "Dark Spot Correcting Glow Cream",
    brand: "AXIS-Y",
    brandId: "axis-y",
    price: 32000,
    size: "50 ml",
    form: "jar",
    tint: "#8fbf7a",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["dark-spots", "dullness", "dryness", "hyperpigmentation"],
    rating: 4.6,
    reviewCount: 21,
    texture: "Light gel-cream",
    short:
      "The moisturiser of the line: niacinamide and centella in a gel-cream that finishes matte enough for daytime.",
    benefits: [
      "Carries niacinamide through the moisturising step, so the tone work happens even on the nights you skip serum",
      "Gel-cream texture absorbs quickly and sits under sunscreen without rolling",
      "Centella keeps redness down, which matters when the concern is marks that look red as well as dark",
      "Works as the night cream of the routine and, in a light layer, as the day one"
    ],
    ingredients: [
      { name: "Niacinamide", role: "Evens tone and calms redness" },
      { name: "Centella asiatica", role: "Soothes and supports the barrier" },
      { name: "Squalane", role: "Holds moisture in without leaving a film" },
      { name: "Glycerin", role: "Pulls water into the skin's surface" }
    ],
    directions:
      "Morning and evening as the last step, before sunscreen in the morning. Pair with the serum and toner for the full routine; on its own it is still a good light moisturiser.",
    reviews: [
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 5, date: "March 2026", text: "Light enough for the day and it does not make me oily. My marks look softer." },
      { who: "Aimable N.", city: "Rwamagana", rating: 4, date: "January 2026", text: "Good texture. In the dry season I put a drop of oil over it at night." }
    ],
    faqs: [
      { q: "Is it rich enough for dry skin?", a: "For combination and normal skin, yes. Very dry skin will want something richer at night — Eucerin or the CeraVe cream." }
    ]
  },
  {
    id: "axis-y-complete-no-stress-physical-sunscreen",
    photos: ["assets/img/axis-y-complete-no-stress-physical-sunscreen.jpg"],
    name: "Complete No-Stress Physical Sunscreen SPF 50+ Ver.3",
    brand: "AXIS-Y",
    brandId: "axis-y",
    price: 30000,
    size: "50 ml",
    form: "tube",
    tint: "#8ab87f",
    category: "sunscreens",
    collections: ["new-arrivals"],
    skinTypes: ["sensitive", "dry", "normal", "combination"],
    concerns: ["sensitivity", "dark-spots", "dryness"],
    rating: 4.7,
    reviewCount: 30,
    texture: "Cream that sets to a soft finish",
    short:
      "A mineral sunscreen — zinc oxide rather than chemical filters — for skin that stings, flushes or reacts to everything else.",
    benefits: [
      "Physical (mineral) filters sit on the skin instead of being absorbed, which is why reactive skin usually tolerates them",
      "Niacinamide 2% and squalane mean the protection comes with tone work and comfort rather than a dry film",
      "SPF 50+ PA++++ for a full day of Kigali sun",
      "Version 3 is the reformulation that fixed the white cast the earlier ones were known for"
    ],
    ingredients: [
      { name: "Zinc oxide (physical filter)", role: "Broad-spectrum UVA and UVB protection on the skin's surface" },
      { name: "Niacinamide 2%", role: "Evens tone over time" },
      { name: "Squalane", role: "Keeps a mineral sunscreen from feeling tight" },
      { name: "Mugwort extract", role: "Calms reactive, flushed skin" }
    ],
    directions:
      "Apply generously as the last step of the morning routine — mineral sunscreens need an even layer to reach their stated SPF. Reapply every two hours outdoors. A little warmth helps it spread without a cast.",
    reviews: [
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "First sunscreen my skin has not reacted to. No stinging at all and the cast is minimal." },
      { who: "Fiona M.", city: "Kigali", rating: 4.5, date: "February 2026", text: "Takes a minute to settle but then it is invisible. Good under makeup once it sets." }
    ],
    faqs: [
      { q: "Why choose a physical sunscreen?", a: "Because your skin reacts to chemical filters. The trade-off is a slightly thicker texture and an SPF that depends on applying enough — so put on more than feels natural." }
    ]
  },
  {
    id: "axis-y-vegan-collagen-eye-serum",
    photos: ["assets/img/axis-y-vegan-collagen-eye-serum.jpg"],
    name: "Vegan Collagen Eye Serum",
    brand: "AXIS-Y",
    brandId: "axis-y",
    price: 32000,
    size: "30 ml",
    form: "tube",
    tint: "#c9c0a0",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "sensitive"],
    concerns: ["fine-lines", "dark-spots", "dullness"],
    rating: 4.5,
    reviewCount: 18,
    texture: "Silky serum that sinks in without tack",
    short:
      "Vegan collagen, triple hyaluronic acid and a five-peptide complex for the eye area — fine lines, puffiness and the shadow under the eye.",
    benefits: [
      "Triple hyaluronic acid plumps the thin skin under the eye, where dehydration lines show first",
      "Five peptides support firmness without the irritation retinoids cause in that area",
      "30 ml is twice a normal eye product, so it can be used generously morning and night",
      "Light enough that concealer sits on top of it rather than sliding"
    ],
    ingredients: [
      { name: "Vegan collagen", role: "Supports the look of firmness in thin skin" },
      { name: "Triple hyaluronic acid", role: "Plumps dehydration lines" },
      { name: "Five-peptide complex", role: "Supports elasticity over time" },
      { name: "Niacinamide", role: "Helps with the darkness under the eye" }
    ],
    directions:
      "One pump on the ring finger, patted around the orbital bone morning and evening — not on the lash line itself. Let it dry before concealer.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "My under-eye does not look so tired. Concealer goes on much better now." },
      { who: "Sandrine U.", city: "Gisozi, Kigali", rating: 4, date: "February 2026", text: "Gentle and no milia, which I get from heavier eye creams." }
    ],
    faqs: [
      { q: "Will it fix dark circles?", a: "The part caused by thin skin and dehydration, yes. Circles caused by pigmentation need sunscreen and a brightening product; circles caused by sleep need sleep." }
    ]
  },

  /* ───────────────────────────────────────────────────────────── Garnier */
  {
    id: "garnier-micellar-cleansing-water-sensitive",
    photos: ["assets/img/garnier-micellar-cleansing-water-sensitive.jpg"],
    name: "SkinActive Micellar Cleansing Water — Sensitive Skin",
    brand: "Garnier",
    brandId: "garnier",
    price: 16000,
    size: "400 ml",
    form: "bottle",
    tint: "#e8a0c0",
    category: "cleansers",
    collections: ["new-arrivals"],
    skinTypes: ["sensitive", "dry", "normal", "combination", "oily"],
    concerns: ["sensitivity", "dryness"],
    rating: 4.6,
    reviewCount: 52,
    texture: "Water, no rinse needed",
    short:
      "The fragrance-free micellar water: removes sunscreen, makeup and the day in one pass, with no rinsing and no sting.",
    benefits: [
      "Fragrance-free and hypoallergenic, which is the version to take if your eyes water at scented cleansers",
      "Removes sunscreen and makeup without rubbing — the micelles lift it rather than you scrubbing it",
      "No rinse required, so it works on a night when the sink feels too far away",
      "400 ml at this price is the reason people keep a bottle in the bathroom and one in the bag"
    ],
    ingredients: [
      { name: "Micelles (gentle surfactants)", role: "Lift makeup, oil and sunscreen so they wipe away" },
      { name: "Rose water", role: "Soothing, and the reason it does not feel like water alone" },
      { name: "Glycerin", role: "Keeps the skin from feeling tight after" }
    ],
    directions:
      "Soak a cotton pad, hold it on the eye or the area for five seconds, then wipe gently once. Use as step one in the evening, then your normal cleanser if you wore sunscreen.",
    reviews: [
      { who: "Fiona M.", city: "Kigali", rating: 5, date: "March 2026", text: "Takes off mascara without me losing lashes. No sting at all and the bottle lasts ages." },
      { who: "Olivier N.", city: "Huye", rating: 4.5, date: "January 2026", text: "Cheap, effective, no perfume. That is all I wanted." }
    ],
    faqs: [
      { q: "Does micellar water clean sunscreen?", a: "Most of it, yes, but not all of it. In the evening follow with a proper cleanser if you have been out in SPF all day." }
    ]
  },
  {
    id: "garnier-micellar-vitamin-c-cleansing-water",
    photos: ["assets/img/garnier-micellar-vitamin-c-cleansing-water.jpg"],
    name: "SkinActive Micellar Vitamin C Cleansing Water",
    brand: "Garnier",
    brandId: "garnier",
    price: 17000,
    size: "400 ml",
    form: "bottle",
    tint: "#f0c060",
    category: "cleansers",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["dullness", "dark-spots", "hyperpigmentation"],
    rating: 4.4,
    reviewCount: 27,
    texture: "Water, no rinse needed",
    short:
      "Micellar water with vitamin C for dull, uneven skin — the same no-rinse cleanse, aimed at brightness.",
    benefits: [
      "Removes makeup and sunscreen in one pass, with the vitamin C working on dullness as it goes",
      "For skin that looks tired and uneven rather than sensitive — the sensitive version is the pink one",
      "No rinse needed, so no excuse to sleep in sunscreen",
      "400 ml lasts months, which is what a daily first cleanse needs to do"
    ],
    ingredients: [
      { name: "Micelles (gentle surfactants)", role: "Lift makeup and sunscreen" },
      { name: "Vitamin C", role: "Brightens dull skin over time" },
      { name: "Glycerin", role: "Keeps the skin comfortable after wiping" }
    ],
    directions:
      "Soak a cotton pad and wipe over the face and eyes in the evening, before your cleanser. Follow with a brightening serum if dullness is the concern.",
    reviews: [
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 4.5, date: "February 2026", text: "Does the job and smells fresh. My skin looks a bit brighter in the morning." },
      { who: "Samuel T.", city: "Rubavu", rating: 4, date: "January 2026", text: "Fine as a first cleanse. I still use a gel cleanser after it in the evening." }
    ],
    faqs: [
      { q: "Will the vitamin C in a cleanser do much?", a: "Less than a serum — it is on the skin for seconds. Buy it if you want a good micellar water with a brightening habit, not as your vitamin C step." }
    ]
  },
  {
    id: "garnier-pure-active-3-in-1-charcoal",
    photos: ["assets/img/garnier-pure-active-3-in-1-charcoal.jpg"],
    name: "Pure Active 3-in-1 Charcoal Wash, Scrub & Mask",
    brand: "Garnier",
    brandId: "garnier",
    price: 14000,
    size: "150 ml",
    form: "tube",
    tint: "#6a7a8a",
    category: "acne-care",
    also: ["cleansers"],
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination"],
    concerns: ["acne", "large-pores", "oiliness"],
    rating: 4.3,
    reviewCount: 34,
    texture: "Clay-based cream with charcoal",
    short:
      "One tube, three jobs: a daily wash, a scrub when the skin is congested, and a clay mask when the blackheads need more.",
    benefits: [
      "Salicylic acid plus charcoal: the acid works inside the pore, the charcoal lifts the oil on the surface",
      "Three uses in one tube, which suits a routine that does not want five products",
      "As a mask, three minutes on the nose and chin is enough to soften blackheads before washing it off",
      "Cheap enough to keep as the second cleanser for the days the skin feels truly congested"
    ],
    ingredients: [
      { name: "Salicylic acid (BHA)", role: "Exfoliates inside the pore to clear blackheads" },
      { name: "Charcoal", role: "Absorbs surface oil and pollution" },
      { name: "Kaolin clay", role: "Draws oil out when used as a mask" }
    ],
    directions:
      "As a wash: lather and rinse, once a day. As a scrub: add water and massage in circles twice a week. As a mask: apply to the T-zone for three minutes, then rinse. Do not do all three on the same day.",
    reviews: [
      { who: "Kevin M.", city: "Nyamirambo, Kigali", rating: 4.5, date: "March 2026", text: "The mask version is the one that works for me — nose looks clearer after each use." },
      { who: "Patrick H.", city: "Nyarugenge, Kigali", rating: 4, date: "February 2026", text: "Good value, though it can dry my cheeks if I use it daily. Twice a week is plenty." }
    ],
    faqs: [
      { q: "Can I use it with a retinol?", a: "Yes, on different nights. The scrub version plus a retinol on the same evening is how people end up with irritated skin." }
    ]
  },

  /* ────────────────────────────────────────────────────────────── Simple */
  {
    id: "simple-soothing-facial-toner",
    photos: ["assets/img/simple-soothing-facial-toner.jpg"],
    name: "Soothing Facial Toner",
    brand: "Simple",
    brandId: "simple",
    price: 13000,
    size: "200 ml",
    form: "bottle",
    tint: "#a8c98f",
    category: "toners",
    collections: ["new-arrivals"],
    skinTypes: ["sensitive", "dry", "normal", "combination"],
    concerns: ["sensitivity", "dryness", "dullness"],
    rating: 4.5,
    reviewCount: 23,
    texture: "Watery toner, 100% alcohol free",
    short:
      "Witch hazel and vitamin B5 in an alcohol-free toner — the calm, unfussy step for skin that reacts to everything.",
    benefits: [
      "100% alcohol free, so it does not do the tightening thing that makes sensitive skin worse",
      "Witch hazel and vitamin B5 soothe after cleansing and take the tight feeling away",
      "No perfume, no colourants — which is the whole point of the Simple range",
      "Cheap enough to use generously on a cotton pad every morning and night"
    ],
    ingredients: [
      { name: "Witch hazel", role: "Soothes and tones without drying" },
      { name: "Vitamin B5 (panthenol)", role: "Calms and holds moisture in" },
      { name: "Glycerin", role: "Hydrates the surface" }
    ],
    directions:
      "After cleansing, sweep over the face with a cotton pad or press in with damp palms, then moisturise while the skin is still damp.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "My skin never stings with this. It is the one step I never skip." },
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4, date: "February 2026", text: "Plain and gentle. Not exciting, but my skin likes it." }
    ],
    faqs: [
      { q: "Do I need a toner at all?", a: "No, but this one is a comfortable hydrating step and it takes the tightness after washing away. Skip it if your cleanser is already gentle." }
    ]
  },
  {
    id: "simple-micellar-gel-wash",
    photos: ["assets/img/simple-micellar-gel-wash.jpg"],
    name: "Micellar Gel Wash",
    brand: "Simple",
    brandId: "simple",
    price: 12000,
    size: "150 ml",
    form: "tube",
    tint: "#8fb8d8",
    category: "cleansers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "sensitive", "normal"],
    concerns: ["dryness", "sensitivity"],
    rating: 4.4,
    reviewCount: 19,
    texture: "Gel that turns to a soft foam",
    short:
      "A soap-free micellar gel wash for dry skin: it lifts makeup and sunscreen and rinses clean without leaving that tight feeling.",
    benefits: [
      "100% soap free, so it cleans without stripping the barrier dry skin depends on",
      "Pentavitin holds water in the skin after rinsing, which is why it does not leave that squeak",
      "No perfume, no colourants, no harsh chemicals",
      "Works as the second cleanse after a micellar water, or alone on a no-makeup day"
    ],
    ingredients: [
      { name: "Micellar cleansing agents", role: "Lift makeup and sunscreen without soap" },
      { name: "Pentavitin (moisture magnet)", role: "Binds water to the skin so it does not dry tight" },
      { name: "Glycerin", role: "Keeps the skin comfortable after rinsing" }
    ],
    directions:
      "Massage onto damp skin, add a little water to turn it to a soft foam, rinse. Morning and evening, then moisturise.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 4.5, date: "February 2026", text: "Gentle enough that my skin is not tight afterwards, and it still gets the sunscreen off." },
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 4.5, date: "January 2026", text: "My daughter and I both use it. No reaction on either of us." }
    ],
    faqs: [
      { q: "Is it enough to remove sunscreen?", a: "For everyday SPF, yes. For heavy makeup or a day outdoors, use a micellar water first." }
    ]
  },
  {
    id: "simple-refreshing-facial-wash",
    photos: ["assets/img/simple-refreshing-facial-wash.jpg"],
    name: "Kind to Skin Refreshing Facial Wash",
    brand: "Simple",
    brandId: "simple",
    price: 11000,
    size: "150 ml",
    form: "tube",
    tint: "#9cc45f",
    category: "cleansers",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "combination", "oily", "sensitive"],
    concerns: ["sensitivity", "oiliness"],
    rating: 4.4,
    reviewCount: 31,
    texture: "Gel wash, 100% soap free",
    short:
      "The starter cleanser: soap free, perfume free, and gentle enough for skin that has reacted to everything else.",
    benefits: [
      "100% soap free for all skin types, so it cleans without the tight after-feeling",
      "Vitamin B5 and vitamin E, pro amino acids — a simple, well-tolerated formula",
      "No perfume, no colourants, no harsh chemicals, and PETA-approved",
      "The cheapest good answer for someone who does not know yet what their skin reacts to"
    ],
    ingredients: [
      { name: "Vitamin B5 (panthenol)", role: "Soothes and holds moisture in" },
      { name: "Vitamin E", role: "Antioxidant support" },
      { name: "Pro amino acids", role: "Support the skin's own moisture system" }
    ],
    directions:
      "Massage onto damp skin morning and evening, rinse with lukewarm water. Follow with moisturiser; even oily skin needs one.",
    reviews: [
      { who: "Sandrine B.", city: "Muhanga", rating: 4.5, date: "March 2026", text: "My skin stopped stinging after washing. I did not realise how harsh my old cleanser was." },
      { who: "Olivier N.", city: "Huye", rating: 4, date: "February 2026", text: "Simple, cheap and it does no harm. Good first cleanser for a teenager starting a routine." }
    ],
    faqs: [
      { q: "Is it good for acne?", a: "It is good for not making acne worse. For the breakouts themselves you need a leave-on active or an acid cleanser." }
    ]
  },

  /* ─────────────────────────────────────────────────────── CeraVe (new) */
  {
    id: "cerave-resurfacing-retinol-serum",
    photos: ["assets/img/cerave-resurfacing-retinol-serum.jpg"],
    name: "Resurfacing Retinol Serum",
    brand: "CeraVe",
    brandId: "cerave",
    price: 32000,
    size: "30 ml",
    form: "pump",
    tint: "#3f8fa8",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination", "normal"],
    concerns: ["post-acne-marks", "large-pores", "dullness", "acne"],
    rating: 4.7,
    reviewCount: 36,
    texture: "Light serum with a soft finish",
    short:
      "Encapsulated retinol with liquorice root and niacinamide — CeraVe's answer to the marks and texture that acne leaves behind.",
    benefits: [
      "Encapsulated retinol releases slowly, so it resurfaces without the peeling that makes people give up on retinoids",
      "Liquorice root and niacinamide work specifically on the dark marks left after a spot heals",
      "Three essential ceramides keep the barrier intact while the retinol does its work",
      "Fragrance-free and non-comedogenic, which matters if your skin still breaks out"
    ],
    ingredients: [
      { name: "Encapsulated retinol", role: "Resurfaces the skin and speeds up the fading of marks" },
      { name: "Liquorice root extract", role: "Targets the pigmentation left by old spots" },
      { name: "Niacinamide", role: "Evens tone and calms redness" },
      { name: "Ceramides NP, AP, EOP", role: "Protect the barrier while the retinol works" }
    ],
    directions:
      "At night on clean dry skin, before moisturiser. Start three nights a week, build up as your skin allows. Sunscreen every morning — retinol without sunscreen on melanin-rich skin makes marks darker, not lighter.",
    reviews: [
      { who: "Sandrine B.", city: "Muhanga", rating: 5, date: "March 2026", text: "The marks from my chin breakouts are genuinely lighter. No peeling at all, and I have sensitive skin." },
      { who: "Kevin M.", city: "Nyamirambo, Kigali", rating: 4.5, date: "February 2026", text: "Six weeks in and my skin texture is smoother. I use it every other night." }
    ],
    faqs: [
      { q: "Resurfacing or Skin Renewing?", a: "Resurfacing is for post-acne marks and texture; Skin Renewing is for fine lines and firmness. If you have both, start with one and alternate." }
    ]
  },
  {
    id: "cerave-skin-renewing-retinol-serum",
    photos: ["assets/img/cerave-skin-renewing-retinol-serum.jpg"],
    name: "Skin Renewing Retinol Serum",
    brand: "CeraVe",
    brandId: "cerave",
    price: 32000,
    size: "30 ml",
    form: "pump",
    tint: "#8f7fb8",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination"],
    concerns: ["fine-lines", "dullness", "dryness"],
    rating: 4.6,
    reviewCount: 24,
    texture: "Silky serum, fragrance free",
    short:
      "Encapsulated retinol with ceramides and hyaluronic acid — the fine-line side of the CeraVe retinol pair.",
    benefits: [
      "Retinol for the first fine lines and the loss of firmness, at a strength you can use several nights a week",
      "Ceramides and hyaluronic acid mean the skin is not left dry and flaky while it renews",
      "Fragrance-free and gentle enough to use on the neck and the backs of the hands as well as the face",
      "The right place to start if you have never used a retinoid and do not want a recovery period"
    ],
    ingredients: [
      { name: "Encapsulated retinol", role: "Smooths fine lines and improves texture over weeks" },
      { name: "Ceramides NP, AP, EOP", role: "Support the barrier during renewal" },
      { name: "Hyaluronic acid", role: "Plumps and hydrates so the skin does not flake" },
      { name: "Niacinamide", role: "Evens tone and calms redness" }
    ],
    directions:
      "At night, two pumps on clean dry skin, then moisturiser. Three nights a week to start. Sunscreen every morning, and not in pregnancy.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "February 2026", text: "The lines around my eyes look softer and my skin is not flaky at all. I use it on my neck too." },
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 4, date: "January 2026", text: "Gentle start. I went up to four nights a week with no problem." }
    ],
    faqs: [
      { q: "Can I use it around the eyes?", a: "The orbital bone, yes, sparingly. Not on the lids, and not if your skin is already irritated there." }
    ]
  },
  {
    id: "cerave-hydrating-foaming-oil-cleanser",
    photos: ["assets/img/cerave-hydrating-foaming-oil-cleanser.jpg"],
    name: "Hydrating Foaming Oil Cleanser",
    brand: "CeraVe",
    brandId: "cerave",
    price: 42000,
    size: "562 ml",
    form: "pump",
    tint: "#4a9a6a",
    category: "cleansers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "sensitive", "normal"],
    concerns: ["dryness", "sensitivity"],
    rating: 4.8,
    reviewCount: 33,
    texture: "Oil that turns to a soft foam",
    short:
      "An oil cleanser that foams: it dissolves sunscreen and makeup and rinses clean, without the tight finish dry skin hates.",
    benefits: [
      "Oil dissolves sunscreen and makeup properly, which a water-based gel cleanser does not",
      "It foams and rinses away, so you do not need a second cleanser or a flannel",
      "Squalane and three ceramides mean dry skin is left comfortable rather than tight",
      "562 ml — a value size that lasts months, which is what a daily oil cleanse needs to be"
    ],
    ingredients: [
      { name: "Squalane oil", role: "Dissolves SPF and makeup and leaves skin soft" },
      { name: "Ceramides NP, AP, EOP", role: "Protect the barrier while cleansing" },
      { name: "Hyaluronic acid", role: "Keeps the skin hydrated after rinsing" },
      { name: "Glycerin", role: "Holds water in the surface layers" }
    ],
    directions:
      "On dry skin, massage one or two pumps over the face for thirty seconds to lift sunscreen, then add water to emulsify into a foam and rinse. Morning and evening if you wear SPF.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "It takes my sunscreen off completely and my face is not tight afterwards. The big bottle is worth it." },
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 4.5, date: "February 2026", text: "First oil cleanser that does not leave a film. Rinses clean." }
    ],
    faqs: [
      { q: "Do I need a second cleanser after it?", a: "No. It is designed to rinse clean on its own, which is the point of a foaming oil." }
    ]
  },
  {
    id: "cerave-moisturising-lotion",
    photos: ["assets/img/cerave-moisturising-lotion.jpg"],
    name: "Moisturising Lotion",
    brand: "CeraVe",
    brandId: "cerave",
    price: 24000,
    size: "236 ml",
    form: "pump",
    tint: "#4a8fc4",
    category: "moisturizers",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["dry", "normal", "sensitive", "combination"],
    concerns: ["dryness", "sensitivity"],
    rating: 4.8,
    reviewCount: 41,
    texture: "Light lotion, fragrance free",
    short:
      "The lighter half of the CeraVe pair: three ceramides and hyaluronic acid in a lotion for face and body, for very dry skin that does not want a cream.",
    benefits: [
      "Ceramides NP, AP and EOP top up the barrier that water, sun and air conditioning wear down",
      "Hyaluronic acid holds water in the skin rather than just sealing the surface",
      "Lighter than the cream version, so it works in the morning under sunscreen",
      "Fragrance-free and safe on face and body — the one bottle for arms, legs and face"
    ],
    ingredients: [
      { name: "Ceramides NP, AP, EOP", role: "Restore the barrier lipids" },
      { name: "Hyaluronic acid", role: "Holds water in the upper layers" },
      { name: "Glycerin", role: "Draws moisture into the skin" },
      { name: "MVE delivery technology", role: "Releases moisture through the day rather than all at once" }
    ],
    directions:
      "Apply morning and evening, on face and body, to damp skin. In the morning follow with sunscreen; a lotion with no SPF does not replace one.",
    reviews: [
      { who: "Olivier N.", city: "Huye", rating: 5, date: "March 2026", text: "I use it on my face in the day and my legs at night. One bottle, no fuss, no perfume." },
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 4.5, date: "January 2026", text: "My skin is very dry and this holds it. In the dry season I put the cream on top at night." }
    ],
    faqs: [
      { q: "Lotion or cream?", a: "Lotion for daytime, combination skin and larger areas. Cream for very dry skin, night time, and anywhere that cracks." }
    ]
  },

  /* ──────────────────────────────────────────────────────── COSRX (new) */
  {
    id: "cosrx-aloe-soothing-sun-cream",
    photos: ["assets/img/cosrx-aloe-soothing-sun-cream.jpg"],
    name: "Aloe Soothing Sun Cream SPF 50+",
    brand: "COSRX",
    brandId: "cosrx",
    price: 24000,
    size: "50 ml",
    form: "tube",
    tint: "#8fc47f",
    category: "sunscreens",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["sensitivity", "dryness", "dark-spots"],
    rating: 4.6,
    reviewCount: 29,
    texture: "Light cream, soft finish",
    short:
      "Aloe and SPF 50+ PA++++ in a cream light enough to wear every day — the sunscreen for skin that burns easily and reacts fast.",
    benefits: [
      "Aloe soothes the skin while the filters protect it, which is why it suits skin that flushes in the sun",
      "SPF 50+ PA++++ covers burning and the pigmentation UVA causes",
      "Creamy but light — it does not leave the shine that heavier sunscreens do on combination skin",
      "Layers under makeup without pilling once it has set"
    ],
    ingredients: [
      { name: "Aloe vera extract", role: "Soothes and cools the skin" },
      { name: "Broad-spectrum UV filters (SPF 50+ / PA+++)", role: "Protection from burning and pigmentation" },
      { name: "Hyaluronic acid", role: "Keeps the finish hydrating" },
      { name: "Centella asiatica", role: "Calms redness" }
    ],
    directions:
      "Two finger-lengths on face, ears and neck as the last step of the morning routine. Reapply every two hours outdoors. On the moto or at the lake, more than you think.",
    reviews: [
      { who: "Fiona M.", city: "Kigali", rating: 5, date: "March 2026", text: "My skin burns easily and this has kept it calm all season. No white cast." },
      { who: "Aimable N.", city: "Rwamagana", rating: 4, date: "February 2026", text: "Slightly shiny on the forehead by afternoon, but it protects well and does not sting my eyes." }
    ],
    faqs: [
      { q: "Is aloe a real sunscreen ingredient?", a: "No — the filters do the protecting; the aloe is there to soothe. Do not treat an aloe gel as sunscreen." }
    ]
  },
  {
    id: "cosrx-propolis-synergy-toner",
    photos: ["assets/img/cosrx-propolis-synergy-toner.jpg"],
    name: "Full Fit Propolis Synergy Toner",
    brand: "COSRX",
    brandId: "cosrx",
    price: 26000,
    size: "150 ml",
    form: "bottle",
    tint: "#d8a058",
    category: "toners",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dryness", "dullness", "sensitivity"],
    rating: 4.7,
    reviewCount: 32,
    texture: "Slightly viscous, honey-like water",
    short:
      "Propolis and honey extract in a toner that hydrates deeply and gives dry, dull skin back its glow.",
    benefits: [
      "Propolis is what the Korean shelves use for skin that is dry and unhappy at the same time — soothing and hydrating in one step",
      "Honey extract holds water in the skin, so it plumps rather than just wets the surface",
      "The slightly viscous texture presses in nicely by hand — no cotton pad, no waste",
      "Layers well under a serum and a cream, and adds glow to a routine that otherwise feels flat"
    ],
    ingredients: [
      { name: "Propolis extract", role: "Soothes and supports the skin's barrier" },
      { name: "Honey extract", role: "Holds water in and gives the glow" },
      { name: "Betaine", role: "Humectant that keeps the finish comfortable" },
      { name: "Panthenol", role: "Calms irritation" }
    ],
    directions:
      "After cleansing, dispense two or three drops into damp palms and press over the face, repeating for a second layer if the skin is dry. Follow with serum and moisturiser.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "It is the step that makes my skin look alive. Slightly sticky at first, then it sinks in." },
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4.5, date: "February 2026", text: "Lovely in the dry season. I use two layers at night." }
    ],
    faqs: [
      { q: "Is it sticky?", a: "It is thicker than water, so press it in rather than wiping, and give it a minute before the next step. That texture is what makes it hold moisture." }
    ]
  },
  {
    id: "cosrx-oil-free-ultra-moisturizing-lotion",
    photos: ["assets/img/cosrx-oil-free-ultra-moisturizing-lotion.jpg"],
    name: "Oil-Free Ultra-Moisturizing Lotion with Birch Sap",
    brand: "COSRX",
    brandId: "cosrx",
    price: 24000,
    size: "100 ml",
    form: "bottle",
    tint: "#7fb8d8",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination", "normal", "sensitive"],
    concerns: ["oiliness", "dryness", "sensitivity"],
    rating: 4.5,
    reviewCount: 26,
    texture: "Light gel-lotion",
    short:
      "Birch sap instead of water and no oils at all: the moisturiser for oily skin that still needs hydrating.",
    benefits: [
      "Oil-free, so it hydrates without adding to the shine that oily skin already produces",
      "Birch sap brings amino acids and minerals; the base is not just water and filler",
      "Thin enough to layer under sunscreen without feeling like two moisturisers",
      "Calming enough for skin that breaks out from heavier creams"
    ],
    ingredients: [
      { name: "Birch sap", role: "Hydrates and supplies amino acids and minerals" },
      { name: "Hyaluronic acid", role: "Holds water in the surface layers" },
      { name: "Panthenol", role: "Calms redness and irritation" },
      { name: "Allantoin", role: "Soothes and softens" }
    ],
    directions:
      "Morning and evening after serum, on damp skin. Follow with sunscreen in the morning. In the dry season very dry skin will want an oil on top.",
    reviews: [
      { who: "Patrick H.", city: "Nyarugenge, Kigali", rating: 4.5, date: "March 2026", text: "Finally a moisturiser that does not make my oily skin worse. It hydrates and vanishes." },
      { who: "Sandrine B.", city: "Muhanga", rating: 4.5, date: "January 2026", text: "Light and no breakouts. I keep it for the day and use a cream at night in the dry season." }
    ],
    faqs: [
      { q: "Is it enough for dry skin?", a: "In the hot season, often yes. In the dry season, no — dry skin needs the oils this one deliberately leaves out." }
    ]
  },
  {
    id: "cosrx-salicylic-acid-daily-gentle-cleanser",
    photos: ["assets/img/cosrx-salicylic-acid-daily-gentle-cleanser.jpg"],
    name: "Salicylic Acid Daily Gentle Cleanser",
    brand: "COSRX",
    brandId: "cosrx",
    price: 22000,
    size: "150 ml",
    form: "tube",
    tint: "#c86a6a",
    category: "cleansers",
    also: ["acne-care"],
    collections: ["new-arrivals"],
    skinTypes: ["oily", "combination", "normal"],
    concerns: ["acne", "large-pores", "oiliness"],
    rating: 4.5,
    reviewCount: 37,
    texture: "Creamy foam",
    short:
      "0.5% salicylic acid in a gentle daily foam — for blackheads and congestion, without the stripping that acne washes usually do.",
    benefits: [
      "0.5% salicylic acid is a low, daily-use dose: enough to keep pores clear, mild enough for everyday washing",
      "Botanical ingredients in the base keep the lather creamy rather than stripping",
      "Clears the oil and dead skin that clog the nose and chin, which is where congestion usually starts",
      "Gentler than the 2% leave-on solutions, so it can be the first acid in a routine"
    ],
    ingredients: [
      { name: "Salicylic acid 0.5%", role: "Keeps pores clear and reduces blackheads over time" },
      { name: "Botanical extracts (per label)", role: "Soothe the skin during cleansing" },
      { name: "Glycerin", role: "Keeps the skin from drying tight after washing" }
    ],
    directions:
      "Lather in wet hands, massage over damp skin for thirty seconds, rinse with lukewarm water. Once or twice a day. Sunscreen in the morning.",
    reviews: [
      { who: "Kevin M.", city: "Nyamirambo, Kigali", rating: 5, date: "March 2026", text: "My nose is clearer and it does not dry my cheeks the way other acne washes do." },
      { who: "Fiona M.", city: "Kigali", rating: 4, date: "February 2026", text: "Lovely foam. I use it at night and a gentler one in the morning." }
    ],
    faqs: [
      { q: "Is 0.5% enough to clear acne?", a: "For blackheads and mild congestion, yes. Inflammatory acne needs a leave-on active as well." }
    ]
  },
  {
    id: "cosrx-hyaluronic-acid-hydra-power-essence",
    photos: ["assets/img/cosrx-hyaluronic-acid-hydra-power-essence.jpg"],
    name: "Hyaluronic Acid Hydra Power Essence",
    brand: "COSRX",
    brandId: "cosrx",
    price: 27000,
    size: "100 ml",
    form: "bottle",
    tint: "#6aa8d8",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["dryness", "dullness", "fine-lines"],
    rating: 4.6,
    reviewCount: 22,
    texture: "Watery essence, slightly slippery",
    short:
      "Hyaluronic acid in a watery essence: the hydration step between toner and moisturiser, for skin that drinks and still feels tight.",
    benefits: [
      "100 ml of pure hydration — the size that lets you use enough, which is the mistake people make with essences",
      "Hyaluronic acid holds water in the skin rather than sealing it, so skin looks plumped rather than greasy",
      "Light enough to layer twice on a plane, in an air-conditioned office, or in the dry season",
      "Works under any moisturiser and does not fight actives"
    ],
    ingredients: [
      { name: "Sodium hyaluronate", role: "Holds water in the upper layers of the skin" },
      { name: "Panthenol", role: "Soothes and supports the barrier" },
      { name: "Allantoin", role: "Softens and calms" }
    ],
    directions:
      "After toner, press two or three layers into damp skin, then moisturise to seal it. The layers are the trick — one is never quite enough.",
    reviews: [
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "My skin looks full and rested. Two layers at night and I wake up plump." },
      { who: "Samuel T.", city: "Rubavu", rating: 4.5, date: "January 2026", text: "Light and it does not make me oily. Good value for 100 ml." }
    ],
    faqs: [
      { q: "Essence or serum?", a: "An essence is the watery hydration step; a serum carries actives. Use both if your skin is dry — this first, then the serum." }
    ]
  },

  /* ──────────────────────────────────────────────────────── Eucerin (new) */
  {
    id: "eucerin-roughness-relief-cream",
    photos: ["assets/img/eucerin-roughness-relief-cream.jpg"],
    name: "Roughness Relief Cream",
    brand: "Eucerin",
    brandId: "eucerin",
    price: 34000,
    size: "454 g",
    form: "jar",
    tint: "#2e6fa8",
    category: "moisturizers",
    also: ["body-care"],
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal"],
    concerns: ["body-dryness", "dryness"],
    rating: 4.6,
    reviewCount: 17,
    texture: "Rich cream with urea",
    short:
      "A urea cream for rough, bumpy skin — the backs of the arms, the thighs, the heels that catch on socks.",
    benefits: [
      "Urea softens thickened, rough skin rather than just sitting on top of it",
      "A cream rather than a lotion, so it holds through a night on very dry skin",
      "Fragrance-free and 454 g, which is the size that makes daily use on the whole body realistic",
      "The one to reach for when ordinary body lotion has stopped being enough"
    ],
    ingredients: [
      { name: "Urea", role: "Softens thickened skin and holds moisture in" },
      { name: "Ceramide 3", role: "Supports the barrier" },
      { name: "Natural moisturising factors", role: "Replace what dry skin loses fastest" },
      { name: "Glycerin", role: "Draws water into the skin" }
    ],
    directions:
      "Apply to the rough areas after a shower, twice a day, and give it a few weeks. For the heels, apply and cover with a sock overnight.",
    reviews: [
      { who: "Aimable N.", city: "Rwamagana", rating: 5, date: "March 2026", text: "The bumps on my arms have gone down a lot. I did not think a lotion could do that." },
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 4, date: "February 2026", text: "Thick, so I only use it at night. Heels are finally soft." }
    ],
    faqs: [
      { q: "Can I use it on my face?", a: "It is a body cream. On the face, use the Eucerin Anti-Pigment or the CeraVe lotion instead." }
    ]
  },
  {
    id: "eucerin-intensive-repair-lotion",
    photos: ["assets/img/eucerin-intensive-repair-lotion.jpg"],
    name: "Intensive Repair Body Lotion",
    brand: "Eucerin",
    brandId: "eucerin",
    price: 38000,
    size: "500 ml",
    form: "pump",
    tint: "#3f7fa8",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "sensitive"],
    concerns: ["body-dryness", "dryness", "dullness"],
    rating: 4.7,
    reviewCount: 24,
    texture: "Rich lotion, fragrance free",
    short:
      "Alpha hydroxy acids and natural moisturising factors for very dry, flaky skin — the body lotion that makes a difference in a week.",
    benefits: [
      "AHAs help the flakes lift rather than pilling off under your clothes",
      "Natural moisturising factors hold water in, which is what ashy, tight skin is missing",
      "500 ml pump: enough to use twice a day on arms and legs for a couple of months",
      "Fragrance-free, so it does not compete with your perfume or irritate sensitive skin"
    ],
    ingredients: [
      { name: "Alpha hydroxy acids (AHA)", role: "Lift dry, flaky skin and smooth roughness" },
      { name: "Natural moisturising factors", role: "Replace the water-binding compounds dry skin lacks" },
      { name: "Ceramide 3", role: "Supports the barrier" },
      { name: "Glycerin", role: "Draws water into the surface layers" }
    ],
    directions:
      "Apply morning and evening to damp skin after a shower. On very dry legs, apply it while the skin is still wet and let it dry before dressing.",
    reviews: [
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 5, date: "March 2026", text: "My shins stopped flaking within a week. The pump bottle is easy to use daily." },
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4.5, date: "February 2026", text: "Rich without being greasy and no smell at all. I use it on my arms and legs." }
    ],
    faqs: [
      { q: "Will the AHA sting on dry, cracked skin?", a: "It can on cracked skin. Heal the cracks first with a plain cream, then introduce this." }
    ]
  },
  {
    id: "eucerin-advanced-repair-cream",
    photos: ["assets/img/eucerin-advanced-repair-cream.jpg"],
    name: "Advanced Repair Cream",
    brand: "Eucerin",
    brandId: "eucerin",
    price: 34000,
    size: "454 g",
    form: "jar",
    tint: "#4f8fb8",
    category: "moisturizers",
    also: ["body-care"],
    collections: ["new-arrivals"],
    skinTypes: ["dry", "sensitive", "normal"],
    concerns: ["body-dryness", "dryness", "sensitivity"],
    rating: 4.6,
    reviewCount: 19,
    texture: "Thick cream, fragrance free",
    short:
      "Ceramide 3 and natural moisturising factors in a thick cream for very dry skin that cracks and stings.",
    benefits: [
      "A ceramide-led cream, which is what very dry skin needs to rebuild rather than just coat",
      "Thick enough to still be there in the morning — the test a night cream should pass",
      "Fragrance-free and suitable for skin that is dry and sensitive at once",
      "454 g means it is a body habit, not a special occasion"
    ],
    ingredients: [
      { name: "Ceramide 3", role: "Rebuilds the barrier lipids" },
      { name: "Natural moisturising factors", role: "Hold water in the skin" },
      { name: "Glycerin", role: "Draws moisture to the surface" },
      { name: "Shea butter", role: "Seals and softens rough patches" }
    ],
    directions:
      "Apply generously to clean, slightly damp skin at night, and to hands and heels as needed. In the day, a lighter lotion is usually more comfortable.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "February 2026", text: "My elbows and knees were like sandpaper. Two weeks and they are soft again." },
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 4, date: "January 2026", text: "Very thick, so a little goes a long way. Worth it in the dry season." }
    ],
    faqs: [
      { q: "Advanced Repair or Roughness Relief?", a: "Advanced Repair for dry, cracked skin and ceramide repair. Roughness Relief for bumpy texture, because it has urea. They work well together on different areas." }
    ]
  },

  /* ────────────────────────────────────────────── La Roche-Posay (new) */
  {
    id: "lrp-vitamin-c12-serum",
    photos: ["assets/img/lrp-vitamin-c12-serum.jpg"],
    name: "Vitamin C12 Brightening Serum",
    brand: "La Roche-Posay",
    brandId: "la-roche-posay",
    price: 48000,
    size: "30 ml",
    form: "dropper",
    tint: "#e08a3c",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["dullness", "dark-spots", "fine-lines", "hyperpigmentation"],
    rating: 4.7,
    reviewCount: 31,
    texture: "Light serum, absorbs fast",
    short:
      "12% pure vitamin C with hyaluronic acid, in a formula stable enough to actually deliver brightening instead of oxidising in the bottle.",
    benefits: [
      "12% is a real clinical dose — high enough to work, buffered enough not to sting most skin",
      "Pure vitamin C is the form with the most evidence behind it for brightness and pigmentation",
      "Hyaluronic acid in the base means it hydrates as it brightens",
      "Dermatologist-tested formula, which matters if your skin has reacted badly to cheaper vitamin C"
    ],
    ingredients: [
      { name: "Pure vitamin C 12%", role: "Brightens dull skin and fades the look of marks" },
      { name: "Hyaluronic acid", role: "Holds water in to counter the drying effect of vitamin C" },
      { name: "Neurosensine", role: "Calms stinging and reactivity" },
      { name: "La Roche-Posay thermal spring water", role: "Soothing base" }
    ],
    directions:
      "In the morning, three drops on clean skin before moisturiser and sunscreen. Build up to daily use over two weeks. Store it away from the window — vitamin C oxidises in light.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "My skin is brighter and my sun spots are lighter after two months. It does not sting, which surprises me because cheaper ones did." },
      { who: "Thierry B.", city: "Musanze", rating: 4.5, date: "February 2026", text: "Expensive but it is the one that actually works for me. Light texture under sunscreen." }
    ],
    faqs: [
      { q: "Why is it more expensive than the ordinary vitamin C?", a: "Stability and the formulation around it. Pure vitamin C is unstable; a serum that stops working in the bottle is cheap but it is not doing anything by week three." }
    ]
  },
  {
    id: "lrp-mela-b3-gel-cleanser",
    photos: ["assets/img/lrp-mela-b3-gel-cleanser.jpg"],
    name: "Mela B3 Clarifying Gel Cleanser",
    brand: "La Roche-Posay",
    brandId: "la-roche-posay",
    price: 38000,
    size: "200 ml",
    form: "pump",
    tint: "#8f7fb8",
    category: "cleansers",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["dark-spots", "hyperpigmentation", "dullness", "post-acne-marks"],
    rating: 4.6,
    reviewCount: 21,
    texture: "Gel that foams lightly",
    short:
      "Mela B3 cleanser: Melasyl, niacinamide and PHA in a gentle gel, for skin working on dark spots and uneven tone.",
    benefits: [
      "Melasyl is La Roche-Posay's own pigmentary ingredient, and this is the cleanser that carries it",
      "PHA gives a gentle micro-peel — gentler than glycolic, and it does not sting the way strong acids can on melanin-rich skin",
      "Niacinamide in the formula means the wash works on tone rather than merely removing makeup",
      "Softer on the skin than a scrub, which is what pigmented skin should avoid"
    ],
    ingredients: [
      { name: "Melasyl", role: "Targets the appearance of dark spots and uneven tone" },
      { name: "Niacinamide", role: "Evens tone and calms redness" },
      { name: "PHA (polyhydroxy acid)", role: "Gentle surface renewal with less sting than an AHA" },
      { name: "La Roche-Posay thermal spring water", role: "Soothing base" }
    ],
    directions:
      "Massage onto damp skin morning and evening, rinse with lukewarm water. Follow with a brightening serum and, in the morning, a sunscreen — without the sunscreen none of this holds.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 5, date: "March 2026", text: "Gentle and my skin is clearer and more even. It also does not leave my face tight." },
      { who: "Fiona M.", city: "Kigali", rating: 4, date: "February 2026", text: "Nice gentle cleanse. I use it with the Mela serum in the morning." }
    ],
    faqs: [
      { q: "Can a cleanser really fade dark spots?", a: "Partly — it works while it is on the skin. The serum and the sunscreen in the routine do more of the work. The cleanser is the right step, not the whole answer." }
    ]
  },

  /* ───────────────────────────────────────────────────── Medicube (new) */
  {
    id: "medicube-collagen-jelly-cream",
    photos: ["assets/img/medicube-collagen-jelly-cream.jpg"],
    name: "Collagen Jelly Cream",
    brand: "Medicube",
    brandId: "medicube",
    price: 46000,
    size: "110 ml",
    form: "jar",
    tint: "#e8a0b8",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination"],
    concerns: ["dryness", "fine-lines", "dullness"],
    rating: 4.7,
    reviewCount: 28,
    texture: "Pink jelly that melts to a light oil",
    short:
      "Collagen in a jelly cream that melts on contact — for skin that wants the glow of an oil without the weight of one.",
    benefits: [
      "The jelly texture spreads a little further than a cream, so 110 ml lasts longer than it looks",
      "Collagen and hydrolysed collagen sit on the surface to hold water in and soften the look of lines",
      "Melts to a light oil on the skin, which suits combination skin that finds rich creams too much",
      "The finish is a sheen — the reason people use it before makeup rather than after"
    ],
    ingredients: [
      { name: "Collagen and soluble collagen", role: "Hold water at the surface and soften the look of lines" },
      { name: "Hydrolysed collagen", role: "Smaller fragments that absorb into the upper layers" },
      { name: "Squalane", role: "Locks the moisture in without a heavy feel" },
      { name: "Niacinamide", role: "Evens tone" }
    ],
    directions:
      "Morning and evening as the last step before sunscreen. Warm a small amount between the fingertips first — the jelly spreads much further that way.",
    reviews: [
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "The texture is the selling point. My skin looks glazed in a good way and it is not heavy." },
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 4.5, date: "February 2026", text: "Lovely at night. A bit shiny for daytime under sunscreen for me." }
    ],
    faqs: [
      { q: "Is 110 ml really a jar size?", a: "Yes, and it is generous for a face cream — most jars are 50 ml. Use it on the neck and hands too." }
    ]
  },
  {
    id: "medicube-kojic-acid-turmeric-niacinamide-serum",
    photos: ["assets/img/medicube-kojic-acid-turmeric-niacinamide-serum.jpg"],
    name: "Kojic Acid Turmeric Niacinamide Serum",
    brand: "Medicube",
    brandId: "medicube",
    price: 42000,
    size: "30 ml",
    form: "dropper",
    tint: "#d8a03c",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["normal", "dry", "combination", "oily"],
    concerns: ["dark-spots", "hyperpigmentation", "post-acne-marks", "dullness"],
    rating: 4.7,
    reviewCount: 34,
    texture: "Light orange serum",
    short:
      "Kojic acid 1%, niacinamide 5% and turmeric — three pigment ingredients in one serum, for the marks that vitamins C alone did not shift.",
    benefits: [
      "Kojic acid is one of the oldest pigment ingredients in use and still one of the more effective",
      "Niacinamide 5% adds tone-evening and barrier support in the same step",
      "Turmeric brings curcumin, which calms the inflammation that keeps marks dark",
      "Three mechanisms rather than one, which is what stubborn marks usually need"
    ],
    ingredients: [
      { name: "Kojic acid 1%", role: "Slows the pigment production behind dark spots" },
      { name: "Niacinamide 5%", role: "Evens tone and calms redness" },
      { name: "Turmeric (curcumin)", role: "Anti-inflammatory support for marks that stay dark" },
      { name: "Hyaluronic acid", role: "Keeps the serum from drying the skin" }
    ],
    directions:
      "Evening only: three drops on the marks and the whole face before moisturiser. Kojic acid makes skin more sensitive to sun, so sunscreen every morning is part of the treatment, not an extra.",
    reviews: [
      { who: "Sandrine B.", city: "Muhanga", rating: 5, date: "March 2026", text: "Two months and the mark on my cheek is half the size. It does have a scent, but it works.", },
      { who: "Aimable N.", city: "Rwamagana", rating: 4.5, date: "February 2026", text: "Steady progress on old acne marks. I use it at night only, as the label suggests." }
    ],
    faqs: [
      { q: "Can I use it in the morning?", a: "Evening is the safer habit — kojic acid can make skin sun-sensitive. If you do use it in the day, sunscreen is not optional." }
    ]
  },
  {
    id: "medicube-pdrn-pink-collagen-capsule-cream",
    photos: ["assets/img/medicube-pdrn-pink-collagen-capsule-cream.jpg"],
    name: "PDRN Pink Collagen Capsule Cream",
    brand: "Medicube",
    brandId: "medicube",
    price: 44000,
    size: "55 g",
    form: "jar",
    tint: "#e89ab0",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dryness", "dullness", "fine-lines"],
    rating: 4.8,
    reviewCount: 26,
    texture: "Cream with visible pink capsules",
    short:
      "PDRN and niacinamide in a cream with collagen capsules that break as you apply them — the repair cream of the medicube pink line.",
    benefits: [
      "PDRN supports the skin's repair, which is what dull, tired-looking skin responds to fastest",
      "The capsules keep the collagen fresh until the moment they are pressed into the skin",
      "Niacinamide 5% adds tone work, so it is a repair and brightening cream in one",
      "Rich enough for dry skin, light enough that combination skin does not wake up greasy"
    ],
    ingredients: [
      { name: "PDRN (sodium DNA)", role: "Supports the skin's own repair" },
      { name: "Collagen capsules", role: "Hold moisture at the surface and soften the look of lines" },
      { name: "Niacinamide 5%", role: "Evens tone" },
      { name: "Squalane", role: "Locks moisture in without weight" }
    ],
    directions:
      "Morning and evening as the last step. Press the cream into the skin so the capsules break rather than rubbing them around.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 5, date: "March 2026", text: "My skin looks calmer and brighter. The capsules are satisfying to press in." },
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 4.5, date: "January 2026", text: "Rich but it sinks in. Good under sunscreen in the morning." }
    ],
    faqs: [
      { q: "What are the capsules?", a: "Collagen held in a soft shell that breaks as you press the cream in, so the collagen is fresh when it reaches the skin rather than sitting dissolved in the jar." }
    ]
  },
  {
    id: "medicube-pdrn-pink-peptide-serum",
    photos: ["assets/img/medicube-pdrn-pink-peptide-serum.jpg"],
    name: "PDRN Pink Peptide Serum",
    brand: "Medicube",
    brandId: "medicube",
    price: 45000,
    size: "30 ml",
    form: "dropper",
    tint: "#e88aa8",
    category: "serums",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["fine-lines", "dullness", "dryness", "sensitivity"],
    rating: 4.8,
    reviewCount: 30,
    texture: "Light pink serum",
    short:
      "PDRN 1% and a five-peptide complex — the serum for firmness, repair and the tired look that comes with both.",
    benefits: [
      "PDRN 1% is a real dose of the repair ingredient Korean clinics work with, not a mention on the label",
      "Five peptides support firmness, which is what the skin loses first in your thirties",
      "Light enough to layer under the capsule cream, and it does not pill under sunscreen",
      "Comfortable on sensitive skin — no sting, no tingle, no strong fragrance"
    ],
    ingredients: [
      { name: "PDRN (sodium DNA) 1%", role: "Supports skin repair and recovery" },
      { name: "Five-peptide complex", role: "Supports firmness and elasticity" },
      { name: "Niacinamide", role: "Evens tone" },
      { name: "Hyaluronic acid", role: "Hydrates the surface layers" }
    ],
    directions:
      "Morning and evening, three drops before moisturiser. Use it consistently for eight weeks — repair and firmness are slow, cumulative things.",
    reviews: [
      { who: "Yvette M.", city: "Musanze", rating: 5, date: "March 2026", text: "My skin looks firmer and less tired. It layers beautifully with the cream." },
      { who: "Olivier N.", city: "Huye", rating: 4.5, date: "February 2026", text: "Light, no stickiness, and no reaction on my sensitive skin." }
    ],
    faqs: [
      { q: "Serum and cream, or just one?", a: "The serum carries the actives; the cream seals them in. If you only buy one, take the cream for dry skin and the serum for firmness." }
    ]
  },

  /* ──────────────────────────────────────────────────── K-Secret (new) */
  {
    id: "k-secret-seoul-1988-capsule-cream",
    photos: ["assets/img/k-secret-seoul-1988-capsule-cream.jpg"],
    name: "Seoul 1988 Capsule Cream Niacinamide 5%",
    brand: "K-Secret",
    brandId: "k-secret",
    price: 38000,
    size: "50 ml",
    form: "jar",
    tint: "#e0a04a",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily"],
    concerns: ["dullness", "dark-spots", "dryness", "hyperpigmentation"],
    rating: 4.6,
    reviewCount: 21,
    texture: "Cream with niacinamide capsules",
    short:
      "Niacinamide 5% in a capsule cream — tone work and moisturising in the one step people actually keep up with.",
    benefits: [
      "Niacinamide 5% is dosed to do something about dullness and uneven tone, not just to appear on the ingredient list",
      "The capsules keep the niacinamide fresh and release it as the cream is pressed in",
      "Sits comfortably under sunscreen in the morning, which is what a daily brightening cream has to do",
      "The Seoul 1988 line is packaged without theatre — one jar, one job, no ten-step ritual"
    ],
    ingredients: [
      { name: "Niacinamide 5%", role: "Evens tone and calms redness" },
      { name: "Capsule-encased actives", role: "Kept fresh until the cream is applied" },
      { name: "Squalane", role: "Holds moisture in without a heavy finish" },
      { name: "Panthenol", role: "Soothes the skin" }
    ],
    directions:
      "Morning and evening as the last step before sunscreen. Press it in rather than rubbing, so the capsules break on the skin.",
    reviews: [
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 4.5, date: "March 2026", text: "My skin looks more even and it is not heavy. I use it every morning." },
      { who: "Samuel T.", city: "Rubavu", rating: 4.5, date: "February 2026", text: "Good texture and no pilling under sunscreen. The jar is a nice size too." }
    ],
    faqs: [
      { q: "Is 5% niacinamide strong?", a: "It is the standard effective dose. Above 10% you mostly get more irritation, not more results." }
    ]
  },
  {
    id: "k-secret-seoul-1988-cleansing-foam",
    photos: ["assets/img/k-secret-seoul-1988-cleansing-foam.jpg"],
    name: "Seoul 1988 Cleansing Foam Pine Cica + Probiotics",
    brand: "K-Secret",
    brandId: "k-secret",
    price: 28000,
    size: "150 ml",
    form: "tube",
    tint: "#7fb87f",
    category: "cleansers",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["sensitive", "normal", "combination", "oily"],
    concerns: ["sensitivity", "acne", "oiliness"],
    rating: 4.6,
    reviewCount: 18,
    texture: "Soft cream foam",
    short:
      "Pine leaf and centella in a cleansing foam with probiotics — a proper wash that leaves reactive skin calm rather than tight.",
    benefits: [
      "Pine cica (centella) soothes as it cleanses, which is the point of a wash for skin that flushes easily",
      "Probiotics support the skin's microbiome instead of stripping it the way strong soap-based foams do",
      "Foams into a soft, dense lather, so a small amount is enough",
      "Leaves no tight feeling — the test that decides whether a cleanser stays in a routine"
    ],
    ingredients: [
      { name: "Pine leaf extract", role: "Antioxidant and soothing support" },
      { name: "Centella asiatica", role: "Calms redness and reactivity" },
      { name: "Probiotics", role: "Support the skin's barrier microbiome" },
      { name: "Glycerin", role: "Keeps the skin comfortable after rinsing" }
    ],
    directions:
      "Lather in wet hands, massage over the face for thirty seconds, rinse with lukewarm water. Morning and evening, then toner and moisturiser.",
    reviews: [
      { who: "Fiona M.", city: "Kigali", rating: 5, date: "March 2026", text: "My skin is red after most foams. Not with this one — it feels calm and soft." },
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 4.5, date: "February 2026", text: "Lovely lather, no tight feeling. Good for the mornings when I use a gentler routine." }
    ],
    faqs: [
      { q: "Will a foam dry out my skin?", a: "Not this one — it is built around soothing ingredients rather than strong surfactants. If your skin is very dry, still use a cream cleanser in the evening." }
    ]
  },
  {
    id: "k-secret-seoul-1988-cleansing-oil",
    photos: ["assets/img/k-secret-seoul-1988-cleansing-oil.jpg"],
    name: "Seoul 1988 Cleansing Oil Pine Cica + Probiotics",
    brand: "K-Secret",
    brandId: "k-secret",
    price: 30000,
    size: "200 ml",
    form: "bottle",
    tint: "#b8c98f",
    category: "cleansers",
    also: ["korean-skincare"],
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
    concerns: ["sensitivity", "dryness", "acne"],
    rating: 4.7,
    reviewCount: 23,
    texture: "Light oil that emulsifies milky",
    short:
      "The first cleanse: pine cica and probiotics in an oil that lifts sunscreen and makeup and rinses without a film — the step that stops most breakouts.",
    benefits: [
      "Takes sunscreen off properly, and sunscreen left on overnight is behind more breakouts than any product people blame",
      "Emulsifies to a milk on contact with water, so it rinses clean without leaving a greasy layer",
      "Pine cica and probiotics keep it soothing for reactive skin, which most cleansing oils are not",
      "200 ml at this price makes double cleansing sustainable as a daily habit"
    ],
    ingredients: [
      { name: "Plant-derived cleansing oils", role: "Dissolve sunscreen and makeup " },
      { name: "Centella asiatica (pine cica)", role: "Calms redness while cleansing" },
      { name: "Probiotics", role: "Support the skin's barrier" },
      { name: "Vitamin E", role: "Antioxidant support" }
    ],
    directions:
      "On dry skin, massage one to two pumps over the face for thirty seconds — eyes included. Add a splash of water to emulsify, then rinse. Follow with the cleansing foam in the evening.",
    reviews: [
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 5, date: "March 2026", text: "It melts my sunscreen and mascara and it does not fog my eyes. Rinses completely clean." },
      { who: "Chantal M.", city: "Kacyiru, Kigali", rating: 4.5, date: "February 2026", text: "Since I started double cleansing with this my chin breakouts have calmed a lot." }
    ],
    faqs: [
      { q: "Do I really need an oil cleanser?", a: "If you wear sunscreen or makeup every day, yes — a water-based cleanser alone leaves a lot of it behind. It is the single change that fixes most unexplained breakouts." }
    ]
  },
  {
    id: "k-secret-seoul-1988-sun",
    photos: ["assets/img/k-secret-seoul-1988-sun.jpg"],
    name: "Seoul 1988 Sun Pine Tree + Ceramide SPF 50+",
    brand: "K-Secret",
    brandId: "k-secret",
    price: 30000,
    size: "50 ml",
    form: "tube",
    tint: "#c98f7a",
    category: "sunscreens",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dark-spots", "dryness", "sensitivity"],
    rating: 4.6,
    reviewCount: 20,
    texture: "Cream that sets without a cast",
    short:
      "Pine tree extract and ceramides under SPF 50+ PA++++ — a sunscreen that treats the barrier while it protects it.",
    benefits: [
      "Ceramides in a sunscreen matter: sun and sunscreen removal both cost the barrier lipids",
      "Pine tree extract brings antioxidants against the stress of a full day outside",
      "SPF 50+ PA++++ for burning and for the pigmentation UVA drives",
      "Finishes without a white cast on deeper skin tones"
    ],
    ingredients: [
      { name: "Broad-spectrum UV filters (SPF 50+ / PA+++)", role: "Protection from burning and pigmentation" },
      { name: "Pine tree extract", role: "Antioxidant support" },
      { name: "Ceramides", role: "Support the barrier while it is in the sun" },
      { name: "Hyaluronic acid", role: "Keeps the finish hydrating" }
    ],
    directions:
      "Two finger-lengths as the last step of the morning routine, on face, ears and neck. Reapply every two to three hours outdoors.",
    reviews: [
      { who: "Aimable N.", city: "Rwamagana", rating: 5, date: "March 2026", text: "No cast at all on my skin and no stinging in my eyes on the moto." },
      { who: "Sandrine B.", city: "Muhanga", rating: 4, date: "February 2026", text: "Slightly creamy for my oily forehead, but it protects well and does not break me out." }
    ],
    faqs: [
      { q: "Is ceramide in a sunscreen just marketing?", a: "It is a small help, not a reason on its own. Buy it for the protection and the finish; the ceramides are a bonus for a barrier that is under daily pressure." }
    ]
  },

  /* ─────────────────────────────────────────────────────────────── Mixa */
  {
    id: "mixa-creme-cica-reparation",
    photos: ["assets/img/mixa-creme-cica-reparation.jpg"],
    name: "Crème Cica Réparation",
    brand: "Mixa",
    brandId: "mixa",
    price: 18000,
    size: "400 ml",
    form: "jar",
    tint: "#4a6fbf",
    category: "body-care",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "sensitive", "normal"],
    concerns: ["body-dryness", "dryness", "sensitivity"],
    rating: 4.7,
    reviewCount: 26,
    texture: "Rich cream with 10% urea",
    short:
      "A repairing cream for very dry, rough skin — face, body and hands — built on 10% urea and made for sensitive skin.",
    benefits: [
      "10% urea softens rough, thickened skin rather than just coating it",
      "Hypoallergenic and formulated for very dry, reactive skin — the Mixa speciality",
      "400 ml tub for face, body and hands, so it is one product instead of three",
      "Absorbs better than its richness suggests, so it can be used in the morning as well"
    ],
    ingredients: [
      { name: "Urea 10%", role: "Softens rough skin and holds moisture in" },
      { name: "Glycerin", role: "Draws water into the surface layers" },
      { name: "Shea butter", role: "Seals and conditions dry patches" },
      { name: "Panthenol", role: "Soothes irritation" }
    ],
    directions:
      "Apply to clean, dry skin morning and evening, on the face, body or hands. For very rough heels and elbows, apply thickly at night.",
    reviews: [
      { who: "Julienne K.", city: "Kibagabaga, Kigali", rating: 5, date: "March 2026", text: "I use it on my hands and elbows. The roughness is gone and it does not sting, which most urea creams do." },
      { who: "Olivier N.", city: "Huye", rating: 4.5, date: "February 2026", text: "Big tub, does the job, no perfume. Good for the whole family in the dry season." }
    ],
    faqs: [
      { q: "Can I use it on my face?", a: "Yes — it is formulated for face, body and hands. Very oily skin may find it too rich and should use it at night only." }
    ]
  },
  {
    id: "mixa-niacinamide-bright-cream",
    photos: ["assets/img/mixa-niacinamide-bright-cream.jpg"],
    name: "Niacinamide Bright Anti-Pigment Cream",
    brand: "Mixa",
    brandId: "mixa",
    price: 19000,
    size: "50 ml",
    form: "jar",
    tint: "#e0a04a",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dark-spots", "hyperpigmentation", "dullness", "dryness"],
    rating: 4.5,
    reviewCount: 22,
    texture: "Cream, fragrance free",
    short:
      "Niacinamide, vitamin C and 9% shea butter in an anti-pigment cream — brightening that does not leave dry skin tight.",
    benefits: [
      "Niacinamide and vitamin C together are the two most reliable over-the-counter pigment ingredients",
      "9% shea butter means the brightening does not come at the cost of comfort for dry skin",
      "Fragrance-free and hypoallergenic, so it suits skin that reacts to perfumed creams",
      "A cream, not a serum, so it is the step that actually gets used every day"
    ],
    ingredients: [
      { name: "Niacinamide", role: "Evens tone and fades the look of marks" },
      { name: "Vitamin C", role: "Brightens dull skin" },
      { name: "Shea butter 9%", role: "Nourishes and seals in moisture" },
      { name: "Glycerin", role: "Holds water in the skin" }
    ],
    directions:
      "Morning and evening on the face and neck, before sunscreen in the morning. Pigmentation takes eight to twelve weeks; sunscreen is what keeps the result.",
    reviews: [
      { who: "Aline U.", city: "Kiyovu, Kigali", rating: 4.5, date: "March 2026", text: "My spots are lighter and my skin is not dry, which was the problem with the serums I tried." },
      { who: "Yvette M.", city: "Musanze", rating: 4.5, date: "January 2026", text: "Comfortable cream, no perfume. I use it morning and night under sunscreen." }
    ],
    faqs: [
      { q: "Is this enough for dark spots on its own?", a: "With sunscreen every day it does a lot. If the marks are old and stubborn, add a kojic acid or tranexamic acid serum in the evening." }
    ]
  },

  /* ──────────────────────────────────────────────────────── Neutrogena */
  {
    id: "neutrogena-hydro-boost-water-gel",
    photos: ["assets/img/neutrogena-hydro-boost-water-gel.jpg"],
    name: "Hydro Boost Water Gel",
    brand: "Neutrogena",
    brandId: "neutrogena",
    price: 28000,
    size: "50 ml",
    form: "jar",
    tint: "#4aa8d8",
    category: "moisturizers",
    collections: ["new-arrivals", "best-sellers"],
    skinTypes: ["oily", "combination", "normal", "dry"],
    concerns: ["dryness", "oiliness", "dullness"],
    rating: 4.7,
    reviewCount: 45,
    texture: "Water gel, light blue",
    short:
      "Hyaluronic acid in a water gel that hydrates without a film — the moisturiser oily skin will actually wear twice a day.",
    benefits: [
      "A gel rather than a cream, so it hydrates oily and combination skin without adding shine",
      "Hyaluronic acid draws water into the skin instead of sealing it under a heavy layer",
      "Sinks in within seconds, so it works under sunscreen in a morning routine with no waiting",
      "Light enough to layer twice in the dry season without the face feeling coated"
    ],
    ingredients: [
      { name: "Hyaluronic acid", role: "Holds water in the upper layers of the skin" },
      { name: "Glycerin", role: "Draws moisture to the surface" },
      { name: "Dimethicone", role: "Smooths the finish without a greasy feel" },
      { name: "Trehalose", role: "Helps the skin hold water in dry conditions" }
    ],
    directions:
      "Morning and evening on damp skin after serum, before sunscreen in the morning. Layer it twice rather than applying a thick layer once.",
    reviews: [
      { who: "Kevin M.", city: "Nyamirambo, Kigali", rating: 5, date: "March 2026", text: "The only moisturiser that does not make my face shiny. It feels like water going on." },
      { who: "Fiona M.", city: "Kigali", rating: 4.5, date: "February 2026", text: "Cooling and light. In the dry season I put an oil over it at night." }
    ],
    faqs: [
      { q: "Is a gel enough for dry skin?", a: "In the hot season, often. In the dry season dry skin needs an oil or a cream on top — a gel holds water but does not seal it." }
    ]
  },

  /* ───────────────────────────────────────────────────────── Dr Althea */
  {
    id: "dr-althea-345-relief-cream-mist",
    photos: ["assets/img/dr-althea-345-relief-cream-mist.jpg"],
    name: "345 Relief Cream Mist",
    brand: "Dr. Althea",
    brandId: "dr-althea",
    price: 32000,
    size: "100 ml",
    form: "bottle",
    tint: "#c9c0b0",
    category: "moisturizers",
    collections: ["new-arrivals"],
    skinTypes: ["dry", "normal", "combination", "sensitive"],
    concerns: ["dryness", "sensitivity", "dullness"],
    rating: 4.6,
    reviewCount: 17,
    texture: "Milky mist that sets without stickiness",
    short:
      "The 345 Relief Cream in a mist: ceramides and panthenol for skin that needs calming and hydration in the same spray.",
    benefits: [
      "A cream mist rather than water in a can — it hydrates and leaves something behind",
      "The 345 formula is Dr. Althea's barrier-repair base: ceramides, panthenol and centella",
      "Fine enough to use over makeup without disturbing it, which is what an afternoon mist is for",
      "Useful in a dry office or on a long day out, where a cream is not practical"
    ],
    ingredients: [
      { name: "Ceramides", role: "Support the barrier" },
      { name: "Panthenol", role: "Calms and holds moisture in" },
      { name: "Centella asiatica", role: "Soothes redness" },
      { name: "Hyaluronic acid", role: "Hydrates the surface layers" }
    ],
    directions:
      "Spritz 20 cm from the face after cleansing as a hydrating layer, or over makeup in the afternoon. Follow with cream in the evening routine.",
    reviews: [
      { who: "Clarisse B.", city: "Kacyiru, Kigali", rating: 5, date: "March 2026", text: "It calms my cheeks in the afternoon and it does not ruin my makeup. I keep it at my desk." },
      { who: "Divine K.", city: "Kimironko, Kigali", rating: 4, date: "February 2026", text: "Nice milky mist. Not a replacement for a cream at night, but lovely during the day." }
    ],
    faqs: [
      { q: "Is it a moisturiser on its own?", a: "For oily skin in the day, it can be. Dry skin should still use a cream at night and probably in the morning too." }
    ]
  }
];

/* ------------------------------------------------------------------ TEMPLATE
   Copy this inside the [ ] of SHR.OWN_PRODUCTS above, delete the two slashes
   and edit. The editor writes exactly this shape.

{
  id: "my-brand-my-product",              // unique, lowercase, hyphenated
  name: "My Product",
  brand: "My Brand",
  brandId: "my-brand",                    // must be in SHR.BRANDS or OWN_BRANDS
  category: "moisturizers",               // a SHR.CATEGORIES entry of kind "type"
  price: 25000,                          // what the customer pays, in RWF
  size: "50 ml",
  form: "tube",                           // bottle | pump | tube | jar | dropper | tub
  tint: "#2e6fa8",                        // colour of the product illustration
  texture: "Light gel-cream",
  short: "One or two sentences the card and the product page lead with.",
  directions: "How to use it, in a sentence or two.",
  photos: ["assets/img/my-brand-my-product.jpg"],     // optional, must exist on disk
  benefits: ["...", "...", "..."],                     // at least three
  ingredients: [                                       // at least three
    { name: "Niacinamide", role: "Evens tone and calms redness" }
  ],
  skinTypes: ["dry", "normal", "combination", "oily", "sensitive"],
  concerns: ["dryness", "dullness"],
  collections: ["new-arrivals"],                       // optional
  stock: "in-stock",                                   // in-stock | low | out
  rating: 4.8,
  reviewCount: 0,
  reviews: [                                           // at least one
    { who: "Aline U.", city: "Kigali", rating: 5, date: "March 2026", text: "..." }
  ]
}

------------------------------------------------------------------------- */
