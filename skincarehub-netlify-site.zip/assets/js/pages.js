/* ==========================================================================
   Skincare Hub Rwanda — Catalog-facing page controllers
   home · shop (filter, sort, search, pagination) · product · reviews · faq
   Each controller runs only when <body data-page="…"> matches.
   ========================================================================== */
window.SHR = window.SHR || {};
(function () {
  "use strict";

  var api = SHR.api;
  var $ = api.$, $$ = api.$$, esc = api.esc, icon = api.icon, money = api.money;
  var params = api.params;
  var BRANDS = SHR.BRANDS;

  function grid(list, opts) {
    opts = opts || {};
    if (!list.length) {
      return (
        '<div class="empty-state">' + icon("search") +
        "<p>No products match those filters yet.</p>" +
        '<button class="btn btn--outline btn--sm" type="button" data-filter-reset>Clear all filters</button></div>'
      );
    }
    return list.map(function (p) { return api.productCard(p, opts); }).join("");
  }

  /* ─────────────────────────────────────────────────────────── HOME */
  /* The home page is the ten sections of the brief, in order:
     1 hero · 2 shop by concern · 3 best sellers · 4 shop by brand ·
     5 build your routine · 6 skin quiz · 7 why Skincare Hub ·
     8 customer reviews · 9 Instagram · 10 final call to action.
     Everything below fills the parts of those sections that come out of the
     catalogue, so no price, product or count is ever typed into the HTML. */
  function home() {
    /* 1. Hero — real photographs of products we actually stock */
    var heroPhotos = $("[data-hero-photos]");
    if (heroPhotos) {
      /* One photograph per brand. Taking the first four products with a photo
         gave four CeraVe bottles, because the catalogue opens with that brand -
         the hero read as a CeraVe shop rather than the shop it is. */
      var seenHeroBrand = {};
      var shot = SHR.PRODUCTS.filter(function (p) {
        if (!(p.photos || []).length || seenHeroBrand[p.brandId]) return false;
        seenHeroBrand[p.brandId] = true;
        return true;
      }).slice(0, 4);
      /* The four photographs go inside a .hero__photos wrapper, because that
         class is what the grid in pages.css is written against. Without it
         each one rendered full width and stacked: a 2,766px column that left
         the copy floating in ~1,200px of empty space beside it. */
      heroPhotos.innerHTML =
        '<div class="hero__photos">' +
        shot.map(function (p, i) {
          return (
            '<a class="hero__photo" href="product.html?id=' + encodeURIComponent(p.id) + '">' +
            '<img src="' + esc(p.photos[0]) + '" alt="' + esc(p.brand + " " + p.name) + '" ' +
            (i === 0 ? 'fetchpriority="high"' : 'loading="lazy"') + ' decoding="async">' +
            '<span class="hero__photo-label">' + esc(p.brand) + "<em>" + esc(p.name) + "</em></span></a>"
          );
        }).join("") +
        "</div>";
    }

    /* 2. What are you looking to improve? — one card per concern */
    var concernGrid = $("[data-concern-grid]");
    if (concernGrid) {
      concernGrid.innerHTML = (SHR.CONCERN_FACETS || []).map(function (c, idx) {
        var count = api.facetProducts(c).length;
        /* The generated art stays in place underneath the photograph: one that
           fails to load uncovers it rather than leaving an empty plate. */
        var art = c.photo
          ? '<img class="concern-card__photo" src="' + esc(c.photo) + '" alt="" loading="lazy" decoding="async" data-concern-photo>'
          : "";
        return (
          '<a class="concern-card reveal" href="' + esc(api.concernHref(c)) + '" style="transition-delay:' + (idx % 4) * 55 + 'ms">' +
          '<span class="concern-card__art" aria-hidden="true">' +
          api.coverArt({ tint: c.tint, pattern: c.pattern, label: c.label }) + art + "</span>" +
          '<span class="concern-card__label">' + esc(c.label) + "</span>" +
          '<span class="concern-card__note">' + esc(c.note) + "</span>" +
          '<span class="concern-card__count">' + count + " product" + (count === 1 ? "" : "s") + "</span></a>"
        );
      }).join("");
    }

    /* 3. Best sellers — eight, with the size, the price and availability */
    var best = $("[data-home-bestsellers]");
    if (best) {
      /* One product per brand. Sorted by rating alone this strip filled up
         with CeraVe: the catalogue opens with that brand and its ratings lead,
         so the ties kept the catalogue's order and the first eight were all one
         shelf. Every pick is still a best seller - the collection is the pool -
         there is simply one of each brand in it now. */
      var rated = api.filterProducts({ categories: "best-sellers", sort: "rating" });
      var seenBrand = {};
      var picks = [];
      rated.forEach(function (p) {
        if (picks.length >= 8 || seenBrand[p.brandId]) return;
        seenBrand[p.brandId] = true;
        picks.push(p);
      });
      /* Fewer than eight brands on the shelf: fill the row with the next best
         rather than leaving it short. */
      rated.forEach(function (p) {
        if (picks.length >= 8 || picks.indexOf(p) >= 0) return;
        picks.push(p);
      });
      best.innerHTML = picks.map(function (p) { return api.productCard(p); }).join("");
    }

    /* 4. Shop by brand — every brand we actually stock, with its shelf count */
    var brandGrid = $("[data-brand-grid]");
    if (brandGrid) brandGrid.innerHTML = brandCards();

    /* 8. Customer reviews — only ever real ones */
    /* 6. Skincare tips — the advice we give on WhatsApp, each one with the
       shelf or the guide that goes with it. */
    var tipsHost = $("[data-home-tips]");
    if (tipsHost) {
      tipsHost.innerHTML = (SHR.TIPS || []).map(function (t, i) {
        return (
          '<article class="tip-card reveal" style="transition-delay:' + (i % 3) * 60 + 'ms">' +
          '<span class="tip-card__num" aria-hidden="true">' + esc(t.n) + "</span>" +
          "<h3>" + esc(t.title) + "</h3>" +
          "<p>" + esc(t.text) + "</p>" +
          '<a class="tip-card__link" href="' + esc(t.href) + '">' + esc(t.link) + "</a>" +
          "</article>"
        );
      }).join("");
    }

    /* 10. Skincare guides - the three articles the blog page leads with,
       rendered with that page's own card so the two listings can never drift
       apart. */
    var guidesHost = $("[data-home-guides]");
    if (guidesHost) {
      var postCard = SHR.contentPages && SHR.contentPages.postCard;
      if (postCard) {
        guidesHost.innerHTML = (SHR.ARTICLES || []).slice(0, 3)
          .map(function (a) { return postCard(a); })
          .join("");
      }
    }

    var reviewsHost = $("[data-home-reviews]");
    if (reviewsHost) {
      if (api.reviewsVerified() && SHR.TESTIMONIALS.length) {
        reviewsHost.innerHTML =
          '<div class="carousel" data-carousel>' +
          '<div class="carousel__viewport" data-home-review-track>' +
          SHR.TESTIMONIALS.map(function (t) {
            return (
              '<div class="carousel__slide"><blockquote class="review-card">' + api.starsHTML(t.rating) +
              '<p class="review-card__quote">“' + esc(t.text) + '”</p>' +
              '<div class="review-card__foot"><span class="avatar">' + esc(initials(t.name)) + "</span>" +
              '<span class="review__who"><strong>' + esc(t.name) + "</strong><span>" + esc(t.city) + "</span></span></div>" +
              "</blockquote></div>"
            );
          }).join("") +
          '</div><div class="carousel__nav">' +
          '<button class="carousel__btn" type="button" data-carousel-prev aria-label="Previous reviews">' + icon("arrowLeft") + "</button>" +
          '<button class="carousel__btn" type="button" data-carousel-next aria-label="Next reviews">' + icon("arrowRight") + "</button>" +
          '<div class="carousel__dots" data-carousel-dots></div></div></div>';
      } else {
        reviewsHost.innerHTML = api.reviewsGate(
          "We publish reviews from customers who bought from us and agreed to be quoted, with their name and where they are. As soon as the first ones are in they appear here — and on the product they bought."
        );
      }
    }

    SHR.ui.refresh();
  }

  /* Brand cards, shared by the home page and the About page, so both list the
     same brands with the same live product counts. A brand with a logo in
     SHR.BRANDS shows it - the initials stay in the markup either way, so a logo
     that fails to load degrades to the monogram instead of an empty plate. */
  function brandCards() {
    return BRANDS.map(function (b) {
      var count = api.filterProducts({ brands: b.id }).length;
      var mark = b.logo
        ? '<span class="brand-card__mark brand-card__mark--logo" aria-hidden="true">' +
            '<span class="brand-card__initials">' + esc(initials(b.name)) + "</span>" +
            '<img class="brand-card__logo" src="' + esc(b.logo) + '" alt="" loading="lazy" decoding="async" data-brand-logo>' +
          "</span>"
        : '<span class="brand-card__mark" aria-hidden="true">' + esc(initials(b.name)) + "</span>";
      return (
        '<a class="brand-card reveal" href="shop.html?brand=' + b.id + '">' +
        mark +
        '<span class="brand-card__name">' + esc(b.name) + "</span>" +
        '<span class="brand-card__meta">' + esc(b.country) + " &middot; " + count + " product" + (count === 1 ? "" : "s") + "</span>" +
        '<span class="brand-card__note">' + esc(b.note) + "</span></a>"
      );
    }).join("");
  }
  SHR.brandCards = brandCards;

  /* A broken logo or a broken cover photo does not bubble, so this is
     registered once in the capture phase: the card keeps its shape and shows
     what is underneath - the monogram for a brand, the generated art for a
     concern card or a guide card. */
  document.addEventListener("error", function (e) {
    var img = e.target;
    if (!img || !img.getAttribute) return;
    if (img.getAttribute("data-concern-photo") || img.getAttribute("data-guide-photo")) {
      var art = img.parentNode;
      if (art && art.classList) art.classList.add("is-no-photo");
      return;
    }
    if (!img.getAttribute("data-brand-logo")) return;
    var mark = img.parentNode;
    if (mark && mark.classList) mark.classList.add("is-no-logo");
  }, true);

  function initials(name) {
    return String(name || "")
      .split(/\s+/)
      .slice(0, 2)
      .map(function (w) { return w.charAt(0).toUpperCase(); })
      .join("");
  }
  SHR.initials = initials;

  /* ─────────────────────────────────────────────────────────── SHOP */
  function shop() {
    var gridHost = $("[data-shop-grid]");
    if (!gridHost) return;
    var p = params();
    var state = {
      q: p.q || "",
      categories: api.arr(p.category),
      brands: api.arr(p.brand),
      skinTypes: api.arr(p.skin),
      concerns: api.arr(p.concern),
      min: p.min || "",
      max: p.max || "",
      only: p.only || "",
      stock: p.stock || "",
      sort: p.sort || "featured",
      page: 1
    };
    var PER_PAGE = 12;

    /* ── sidebar ─────────────────────────────────────────────────────────
       The facets the brief asks for, in the order a customer shops: category,
       brand, skin type, concern, price, stock status. Every count is live, so
       a checkbox never promises products the filter will not then show. */
    function brandCount(brandId) {
      return api.filterProducts({ brands: brandId }).length;
    }
    function skinCount(sId) {
      return api.filterProducts({ skinTypes: sId }).length;
    }
    function concernCount(facet) {
      return api.facetProducts(facet).length;
    }
    function categoryCount(facet) {
      return api.countCategories(facet.categories);
    }
    function buildSidebar() {
      var host = $("[data-filter-sidebar]");
      if (!host) return;
      host.innerHTML =
        '<div class="filter-group" data-collapsed="false">' +
        '<div class="filter-group__head" data-filter-collapse><h3>Category</h3>' + icon("chevronDown") + "</div>" +
        '<div class="filter-group__body"><div class="filter-list">' +
        (SHR.CATEGORY_FACETS || []).map(function (c) {
          return (
            '<label class="filter-check"><input type="checkbox" value="' + c.id + '" data-facet="categories"' +
            (state.categories.indexOf(c.id) >= 0 ? " checked" : "") + "><span>" + esc(c.label) + '</span><span class="count">' + categoryCount(c) + "</span></label>"
          );
        }).join("") +
        "</div></div></div>" +
        '<div class="filter-group" data-collapsed="true">' +
        '<div class="filter-group__head" data-filter-collapse><h3>Skin type</h3>' + icon("chevronDown") + "</div>" +
        '<div class="filter-group__body"><div class="filter-list">' +
        SHR.SKIN_TYPES.map(function (s) {
          return (
            '<label class="filter-check"><input type="checkbox" value="' + s.id + '" data-facet="skinTypes"' +
            (state.skinTypes.indexOf(s.id) >= 0 ? " checked" : "") + "><span>" + esc(s.label) + '</span><span class="count">' + skinCount(s.id) + "</span></label>"
          );
        }).join("") +
        "</div></div></div>" +
        '<div class="filter-group" data-collapsed="false">' +
        '<div class="filter-group__head" data-filter-collapse><h3>Concern</h3>' + icon("chevronDown") + "</div>" +
        '<div class="filter-group__body"><div class="filter-list filter-list--scroll">' +
        (SHR.CONCERN_FACETS || []).map(function (c) {
          return (
            '<label class="filter-check"><input type="checkbox" value="' + c.id + '" data-facet="concerns"' +
            (state.concerns.indexOf(c.id) >= 0 ? " checked" : "") + "><span>" + esc(c.label) + '</span><span class="count">' + concernCount(c) + "</span></label>"
          );
        }).join("") +
        "</div></div></div>" +
        '<div class="filter-group" data-collapsed="true">' +
        '<div class="filter-group__head" data-filter-collapse><h3>Brand</h3>' + icon("chevronDown") + "</div>" +
        '<div class="filter-group__body"><div class="filter-list filter-list--scroll">' +
        BRANDS.map(function (b) {
          return (
            '<label class="filter-check"><input type="checkbox" value="' + b.id + '" data-facet="brands"' +
            (state.brands.indexOf(b.id) >= 0 ? " checked" : "") + "><span>" + esc(b.name) + '</span><span class="count">' + brandCount(b.id) + "</span></label>"
          );
        }).join("") +
        "</div></div></div>" +
        '<div class="filter-group" data-collapsed="true">' +
        '<div class="filter-group__head" data-filter-collapse><h3>Price (RWF)</h3>' + icon("chevronDown") + "</div>" +
        '<div class="filter-group__body"><div class="price-inputs">' +
        '<label class="sr-only" for="priceMin">Minimum price</label>' +
        '<input class="input" id="priceMin" type="number" inputmode="numeric" min="0" step="1000" placeholder="From" value="' + esc(state.min) + '" data-price="min">' +
        '<span class="text-muted">&ndash;</span>' +
        '<label class="sr-only" for="priceMax">Maximum price</label>' +
        '<input class="input" id="priceMax" type="number" inputmode="numeric" min="0" step="1000" placeholder="To" value="' + esc(state.max) + '" data-price="max">' +
        '</div><input class="range" type="range" min="18000" max="60000" step="1000" value="' + (state.max || 60000) + '" data-price-range aria-label="Maximum price slider">' +
        '<p class="form-note">Most products are between 18,000 and 58,000 RWF.</p></div></div>' +
        '<div class="filter-group" data-collapsed="false">' +
        '<div class="filter-group__head" data-filter-collapse><h3>Stock status</h3>' + icon("chevronDown") + "</div>" +
        '<div class="filter-group__body"><div class="filter-list">' +
        [["", "All products"], ["instock", "In stock"], ["low", "Low stock"], ["out", "Out of stock"]].map(function (o) {
          return (
            '<label class="filter-check"><input type="radio" name="stock" value="' + o[0] + '" data-facet-radio="stock"' +
            (state.stock === o[0] ? " checked" : "") + "><span>" + o[1] + "</span></label>"
          );
        }).join("") +
        "</div></div></div>" +
        '<div class="filter-group" data-collapsed="true">' +
        '<div class="filter-group__head" data-filter-collapse><h3>Also show</h3>' + icon("chevronDown") + "</div>" +
        '<div class="filter-group__body"><div class="filter-list">' +
        [["", "Everything"], ["sale", "On offer"], ["new", "New arrivals"]].map(function (o) {
          return (
            '<label class="filter-check"><input type="radio" name="only" value="' + o[0] + '" data-facet-radio="only"' +
            (state.only === o[0] ? " checked" : "") + "><span>" + o[1] + "</span></label>"
          );
        }).join("") +
        "</div></div></div>" +
        '<div class="filter-group"><button class="btn btn--outline btn--block btn--sm" type="button" data-filter-reset>Clear all filters</button></div>';
    }
    /* The label a filter tag shows, whether the value is a facet or a raw id */
    function facetLabel(kind, value) {
      if (kind === "categories") {
        var cf = api.categoryFacet(value);
        return cf ? cf.label : api.categoryById(value).name;
      }
      if (kind === "concerns") {
        var nf = api.concernFacet(value);
        return nf ? nf.label : api.concernLabel(value);
      }
      if (kind === "brands") return api.brandById(value).name;
      if (kind === "skinTypes") return api.skinTypeLabel(value);
      return value;
    }

    function activeTags() {
      var tags = [];
      state.categories.forEach(function (c) { tags.push({ k: "categories", v: c, l: facetLabel("categories", c) }); });
      state.brands.forEach(function (b) { tags.push({ k: "brands", v: b, l: api.brandById(b).name }); });
      state.skinTypes.forEach(function (s) { tags.push({ k: "skinTypes", v: s, l: api.skinTypeLabel(s) }); });
      state.concerns.forEach(function (c) { tags.push({ k: "concerns", v: c, l: facetLabel("concerns", c) }); });
      if (state.only) tags.push({ k: "only", v: state.only, l: { sale: "On offer", new: "New arrivals" }[state.only] || state.only });
      if (state.stock) tags.push({ k: "stock", v: state.stock, l: { instock: "In stock", low: "Low stock", out: "Out of stock" }[state.stock] || state.stock });
      if (state.max) tags.push({ k: "max", v: state.max, l: "Under " + money(Number(state.max)) });
      if (state.min) tags.push({ k: "min", v: state.min, l: "Over " + money(Number(state.min)) });
      if (state.q) tags.push({ k: "q", v: state.q, l: "“" + state.q + "”" });
      var host = $("[data-active-filters]");
      if (!host) return;
      if (!tags.length) {
        host.innerHTML = "";
        return;
      }
      host.innerHTML = tags.map(function (t) {
        return '<span class="filter-tag">' + esc(t.l) +
          '<button type="button" data-remove-tag="' + esc(t.k) + '" data-remove-value="' + esc(t.v) + '" aria-label="Remove filter ' + esc(t.l) + '">' + icon("close") + "</button></span>";
      }).join("") + '<button class="remove-link" type="button" data-filter-reset>Clear all</button>';
    }

    function syncUrl() {
      var next = api.query({
        q: state.q || undefined,
        category: state.categories.length ? state.categories : undefined,
        brand: state.brands.length ? state.brands : undefined,
        skin: state.skinTypes.length ? state.skinTypes : undefined,
        concern: state.concerns.length ? state.concerns : undefined,
        min: state.min || undefined,
        max: state.max || undefined,
        only: state.only || undefined,
        stock: state.stock || undefined,
        sort: state.sort !== "featured" ? state.sort : undefined
      });
      try {
        window.history.replaceState({}, "", window.location.pathname + next);
      } catch (e) { /* file:// may refuse — the filters still work */ }
    }

    function render(resetPage) {
      if (resetPage) state.page = 1;
      /* Facet ids become the categories and concerns the catalogue is tagged
         with, so "Treatments" and "Skin barrier" filter for real. */
      var list = api.filterProducts({
        categories: api.expandCategories(state.categories),
        brands: state.brands,
        skinTypes: state.skinTypes,
        concerns: api.expandConcerns(state.concerns),
        min: state.min,
        max: state.max,
        only: state.only,
        stock: state.stock,
        sort: state.sort,
        q: state.q
      });
      var total = list.length;
      var pages = Math.max(1, Math.ceil(total / PER_PAGE));
      if (state.page > pages) state.page = pages;
      var slice = list.slice((state.page - 1) * PER_PAGE, state.page * PER_PAGE);
      gridHost.innerHTML = grid(slice);
      var count = $("[data-results-count]");
      if (count) {
        count.innerHTML = total === 0
          ? "No products found"
          : "<strong>" + total + "</strong> product" + (total === 1 ? "" : "s") +
            (state.q ? " matching “" + esc(state.q) + "”" : "") +
            (total > PER_PAGE ? " · showing " + ((state.page - 1) * PER_PAGE + 1) + "–" + ((state.page - 1) * PER_PAGE + slice.length) : "");
      }
      var pag = $("[data-pagination]");
      if (pag) {
        if (pages <= 1) pag.innerHTML = "";
        else {
          var out = '<button type="button" data-page-go="' + (state.page - 1) + '"' + (state.page === 1 ? " disabled" : "") + ">Prev</button>";
          for (var i = 1; i <= pages; i++) {
            out += '<button type="button" data-page-go="' + i + '"' + (i === state.page ? ' aria-current="true"' : "") + ">" + i + "</button>";
          }
          out += '<button type="button" data-page-go="' + (state.page + 1) + '"' + (state.page === pages ? " disabled" : "") + ">Next</button>";
          pag.innerHTML = out;
        }
      }
      activeTags();
      syncUrl();
      /* the sort control follows the URL, so a shared ?sort=newest link shows
         the right option in the dropdown */
      var sortSelect = $("[data-sort]");
      if (sortSelect && sortSelect.querySelector('option[value="' + state.sort + '"]')) sortSelect.value = state.sort;
      SHR.ui.refresh();
    }

    function heading() {
      var title = $("[data-shop-title]"), lead = $("[data-shop-lead]"), crumb = $("[data-shop-crumb]");
      var text = "Shop Skincare";
      var blurb = "Explore authentic skincare products for different skin types and concerns.";
      if (state.q) {
        text = "Search: " + state.q;
        blurb = "Results for “" + state.q + "” across our whole catalogue.";
      } else if (state.categories.length === 1) {
        var cf = api.categoryFacet(state.categories[0]);
        var c = api.categoryById(state.categories[0]);
        text = cf ? cf.label : c.name;
        blurb = cf ? "Everything we stock in " + cf.label.toLowerCase() + "." : c.blurb;
      } else if (state.brands.length === 1) {
        var b = api.brandById(state.brands[0]);
        text = b.name + " in Rwanda";
        blurb = b.note;
      } else if (state.concerns.length === 1) {
        text = "Products for " + facetLabel("concerns", state.concerns[0]).toLowerCase();
        blurb = "Chosen because they list this concern as something they address.";
      }
      if (title) title.textContent = text;
      if (lead) lead.textContent = blurb;
      if (crumb) crumb.textContent = text;
      var docTitle = text + " | Skincare Hub Rwanda";
      document.title = state.q ? "Search results for " + state.q + " | Skincare Hub Rwanda" : docTitle;
      var meta = document.querySelector('meta[name="description"]');
      if (meta && !state.q) {
        meta.setAttribute("content", blurb + " Genuine products, sealed and batch-coded, delivered across Rwanda.");
      }
    }

    buildSidebar();
    heading();
    render(false);

    /* ── the search field at the top of the shop ──────────────────────────
       It filters as you type, keeps the URL in step so the result can be
       shared or bookmarked, and leaves the header's overlay search alone. */
    var quickSearch = $("[data-shop-search]");
    if (quickSearch) {
      if (state.q) quickSearch.value = state.q;
      quickSearch.addEventListener("input", api.debounce(function () {
        state.q = quickSearch.value.trim();
        render(true);
      }, 260));
      var searchForm = $("[data-shop-search-form]");
      if (searchForm) {
        searchForm.addEventListener("submit", function (e) {
          e.preventDefault();
          state.q = quickSearch.value.trim();
          render(true);
        });
      }
    }

    /* ── events */
    var sidebar = $(".shop-sidebar");
    if (sidebar) {
      sidebar.addEventListener("change", function (e) {
        var facet = e.target.getAttribute("data-facet");
        if (facet) {
          var value = e.target.value;
          var listArr = state[facet];
          if (e.target.checked) {
            if (listArr.indexOf(value) < 0) listArr.push(value);
          } else {
            state[facet] = listArr.filter(function (v) { return v !== value; });
          }
          buildSidebar();
          render(true);
          return;
        }
        var radio = e.target.getAttribute("data-facet-radio");
        if (radio) {
          state[radio] = e.target.value;
          render(true);
        }
      });
      sidebar.addEventListener("input", api.debounce(function (e) {
        var price = e.target.getAttribute("data-price");
        if (price) {
          state[price] = e.target.value;
          if (price === "max") {
            var range = $("[data-price-range]");
            if (range) range.value = e.target.value || range.max;
          }
          render(true);
          return;
        }
        if (e.target.matches("[data-price-range]")) {
          state.max = e.target.value;
          var maxInput = $('[data-price="max"]');
          if (maxInput) maxInput.value = e.target.value;
          render(true);
        }
      }, 260));
      sidebar.addEventListener("click", function (e) {
        if (e.target.closest("[data-filter-collapse]")) {
          var group = e.target.closest(".filter-group");
          if (group) group.setAttribute("data-collapsed", group.getAttribute("data-collapsed") === "true" ? "false" : "true");
        }
      });
    }

    $("[data-shop-toolbar]") && $("[data-shop-toolbar]").addEventListener("change", function (e) {
      if (e.target.matches("[data-sort]")) {
        state.sort = e.target.value;
        render(true);
      }
    });

    document.addEventListener("click", function (e) {
      var pageBtn = e.target.closest("[data-page-go]");
      if (pageBtn && !pageBtn.disabled) {
        e.preventDefault();
        state.page = Math.max(1, Number(pageBtn.getAttribute("data-page-go")));
        render(false);
        var top = $("[data-shop-grid]");
        if (top) window.scrollTo({ top: top.getBoundingClientRect().top + window.scrollY - 120, behavior: "smooth" });
        return;
      }
      var tag = e.target.closest("[data-remove-tag]");
      if (tag) {
        e.preventDefault();
        var key = tag.getAttribute("data-remove-tag");
        var value = tag.getAttribute("data-remove-value");
        if (Array.isArray(state[key])) state[key] = state[key].filter(function (v) { return v !== value; });
        else state[key] = "";
        buildSidebar();
        render(true);
        return;
      }
      if (e.target.closest("[data-filter-reset]")) {
        e.preventDefault();
        state.categories = [];
        state.brands = [];
        state.skinTypes = [];
        state.concerns = [];
        state.min = "";
        state.max = "";
        state.only = "";
        state.stock = "";
        state.q = "";
        state.page = 1;
        var search = $("[data-shop-search]");
        if (search) search.value = "";
        var range = $("[data-price-range]");
        if (range) range.value = range.max;
        buildSidebar();
        render(true);
      }
    });
  }

  /* ──────────────────────────────────────────────────────── PRODUCT */
  function product() {
    var host = $("[data-product]");
    if (!host) return;
    var p = params();
    var item = api.getProduct(p.id) || null;
    if (!item) {
      host.innerHTML =
        '<div class="empty-state">' + icon("search") +
        "<h2>We could not find that product</h2><p>It may have been renamed or sold out.</p>" +
        '<a class="btn btn--gold" href="shop.html?category=best-sellers">Browse best sellers</a></div>';
      return;
    }
    document.title = item.brand + " " + item.name + " | Skincare Hub Rwanda";
    var desc = document.querySelector('meta[name="description"]');
    if (desc) desc.setAttribute("content", item.short + " " + money(item.price) + " — authentic, delivered across Rwanda.");
    api.trackViewed(item.id);
    api.analytics.event("view_item", { item_id: item.id, item_name: item.name, value: item.price, currency: SHR.CONFIG.currency });

    var caption = "Photograph of the product we stock - message us on WhatsApp for another angle, or the batch code.";
    var photos = (item.photos || []);
    var variants = photos.length
      ? photos.map(function (src, i) {
          return { id: "photo-" + i, label: photos.length === 1 ? "Product" : "Photo " + (i + 1) };
        })
      : [{ id: "front", label: "Product" }];
    variants = variants.concat([
      { id: "texture", label: "Texture" },
      { id: "box", label: "Packaging" }
    ]);
    var gallery =
      '<div class="gallery">' +
      '<div class="gallery__thumbs" role="tablist" aria-label="Product images">' +
      variants.map(function (v, i) {
        return (
          '<button class="gallery__thumb" type="button" role="tab" data-visual-variant="' + v.id + '" aria-selected="' + (i === 0 ? "true" : "false") +
          '" aria-label="' + esc(v.label) + ' view">' + api.productVisual(item, v.id) + "</button>"
        );
      }).join("") +
      "</div>" +
      '<div><div class="gallery__main" data-gallery-main>' + api.productVisual(item, "front") + "</div>" +
      (photos.length ? '<p class="gallery__caption">' + esc(caption) + '</p></div>' : '') +
      (photos.length ? '' : '<p class="gallery__caption">Illustrated product view — ask us on WhatsApp for a photograph of the exact unit you will receive.</p></div>') +
      "</div>";

    var facts = [
      { icon: "shield", text: "<strong>100% authentic</strong> — sealed, batch-coded" },
      { icon: "droplet", text: "<strong>" + esc(item.texture || "Skincare") + "</strong> texture" },
      item.spf ? { icon: "sun", text: "<strong>" + esc(item.spf) + "</strong> protection" } : { icon: "leaf", text: "Suitable for <strong>" + esc(api.skinTypeLabel((item.skinTypes || [])[0] || "")) + "</strong> skin" },
      { icon: "truck", text: "Delivery <strong>24h Kigali</strong> · 2–4 days upcountry" }
    ].map(function (f) {
      return '<span class="fact">' + icon(f.icon) + "<span>" + f.text + "</span></span>";
    }).join("");

    var stock = api.stockLabel(item);
    var info =
      '<div class="pdp__head">' +
      '<a class="pdp__brand" href="shop.html?brand=' + item.brandId + '">' + esc(item.brand) + "</a>" +
      '<h1 class="pdp__title">' + esc(item.name) + "</h1>" +
      '<div class="pdp__rating">' +
      '<span class="pcard__stock ' + stock.cls + '">' + esc(stock.text) + "</span>" +
      (api.reviewsVerified()
        ? api.starsHTML(item.rating, true) + "<span>" + item.rating.toFixed(1) + " out of 5</span>" +
          '<a href="#reviews">' + item.reviewCount + " reviews</a>"
        : '<a href="#reviews">No reviews published yet</a>') +
      "</div>" +
      '<div class="pdp__price price price--lg"><span class="price__now">' + money(item.price) + "</span>" +
      (item.was > item.price ? '<del class="price__was">' + money(item.was) + '</del><span class="save-pill">Save ' + money(item.was - item.price) + "</span>" : "") +
      '<span class="text-muted">' + esc(item.size) + "</span></div>" +
      '<p class="pdp__brief">' + esc(item.short) + "</p>" +
      "</div>" +
      '<div class="pdp__facts">' + facts + "</div>" +
      '<div class="swatch-row mb-2"><span class="label">Skin types</span><span class="pill-list">' +
      (item.skinTypes || []).map(function (s) { return '<a href="shop.html?skin=' + s + '">' + esc(api.skinTypeLabel(s)) + "</a>"; }).join("") +
      "</span></div>" +
      '<div class="swatch-row mb-3"><span class="label">Addresses</span><span class="pill-list">' +
      (item.concerns || []).map(function (c) { return '<a href="shop.html?concern=' + c + '">' + esc(api.concernLabel(c)) + "</a>"; }).join("") +
      "</span></div>" +
      '<div class="pdp__buy">' +
      '<div class="buy-row">' +
      '<div class="qty" data-qty-static>' +
      '<button type="button" data-qty-minus aria-label="Decrease quantity">&minus;</button>' +
      '<span data-qty-value>1</span>' +
      '<button type="button" data-qty-plus aria-label="Increase quantity">+</button></div>' +
      '<button class="btn btn--gold" type="button" data-add-pdp="' + esc(item.id) + '">' + icon("cart") + "Add to cart</button>" +
      '<button class="btn btn--outline" type="button" data-buy-now="' + esc(item.id) + '">' + icon("lock") + "Buy now</button>" +
      "</div>" +
      '<div class="cluster">' +
      '<button class="btn btn--sm btn--outline" type="button" data-wish-toggle="' + esc(item.id) + '">' + icon("heart") + "Save to wishlist</button>" +
      '<a class="btn btn--sm btn--whatsapp" href="' + esc(api.waProduct(item)) + '" target="_blank" rel="noopener">' + icon("whatsapp") + "Ask about this product</a>" +
      "</div></div>" +
      '<div class="pdp__meta">' +
      '<span class="pdp__meta-row">' + icon("truck") + "<span><strong>Delivery across Rwanda.</strong> " + esc(SHR.CONFIG.delivery.note) + "</span></span>" +
      '<span class="pdp__meta-row">' + icon("shield") + "<span><strong>Authenticity promise.</strong> Sealed, batch-coded, checked on arrival — ask us for a photo of the batch code on your exact unit before you pay.</span></span>" +
      '<span class="pdp__meta-row">' + icon("chat") + "<span><strong>Free routine advice.</strong> Message us with what you already use and we will tell you whether this fits before you buy.</span></span>" +
      "</div>" +
      '<div class="pdp__whatsapp"><a class="btn btn--whatsapp btn--block" href="' + esc(api.waProduct(item)) + '" target="_blank" rel="noopener">' + icon("whatsapp") + "Ask about this product on WhatsApp</a></div>";

    /* Everything a buyer needs to understand the product, in the order the
       brief asks for it. Nothing here is invented: the benefits, ingredients
       and directions come from the catalogue, and the full INCI list is on the
       carton rather than typed out from memory. */
    var details =
      '<dl class="detail-list">' +
      detail("Brand", item.brand) +
      detail("Product", item.name) +
      detail("Size", item.size) +
      detail("Format", api.titleCase(item.form || "")) +
      detail("Texture", item.texture) +
      (item.spf ? detail("Protection", item.spf) : "") +
      detail("Category", api.categoryById(item.category).name) +
      detail("Skin types", (item.skinTypes || []).map(api.skinTypeLabel).join(", ")) +
      detail("Addresses", (item.concerns || []).map(api.concernLabel).join(", ")) +
      detail("Reference", item.id) +
      "</dl>";

    var accordion =
      '<div class="accordion mt-3">' +
      acc("What it does", "<p class=\"form-note\">In plain terms, and without promising a cure for anything:</p><ul class='check-list'>" +
        (item.benefits || []).map(function (b) { return "<li>" + icon("check") + "<span>" + esc(b) + "</span></li>"; }).join("") + "</ul>", true) +
      acc("Who it is for / best for", "<ul class='check-list'>" +
        (item.skinTypes || []).map(function (s) { return "<li>" + icon("check") + "<span>" + esc(api.skinTypeLabel(s)) + " skin</span></li>"; }).join("") +
        (item.concerns || []).map(function (c) { return "<li>" + icon("check") + "<span>" + esc(api.concernLabel(c)) + "</span></li>"; }).join("") +
        "</ul><p class='form-note mb-0'>Still not sure it fits your skin? Ask us — the advice is free.</p>") +
      acc("Key ingredients", "<div class='ingredient-grid'>" + (item.ingredients || []).map(function (ing) {
        return "<div class='ingredient'><strong>" + esc(ing.name) + "</strong><span>" + esc(ing.role) + "</span></div>";
      }).join("") + "</div>") +
      acc("How to use", "<p>" + esc(item.directions) + "</p>" +
        "<div class='routine-order'>" +
        "<div><span class='label'>Morning</span><ol><li>Cleanse</li><li>Treat</li><li>Moisturize</li><li>Protect with SPF 50</li></ol></div>" +
        "<div><span class='label'>Evening</span><ol><li>Cleanse</li><li>Treat</li><li>Moisturize</li></ol></div>" +
        "</div><p class='form-note mb-0'>General routine guidance only — not medical advice. Introduce one new active at a time, give it a few weeks, and keep sun protection daily.</p>") +
      acc("Full ingredient list", "<p>The complete ingredient list — every ingredient, including the preservatives and fragrance — is printed on the carton and the bottle of the unit we send you. We do not reprint it here from memory: a transcription error would be worse than no list at all.</p>" +
        "<p class='mb-0'><a class='btn btn--whatsapp btn--sm' href='" + esc(api.waLink("Hello Skincare Hub Rwanda, please send me a photo of the full ingredient list on " + item.brand + " " + item.name + ".")) + "' target='_blank' rel='noopener'>" + icon("camera") + "Send me the label</a></p>") +
      acc("Product details", details) +
      acc("Delivery information", "<p>" + esc(SHR.CONFIG.delivery.kigaliEta) + " inside Kigali and " + esc(SHR.CONFIG.delivery.upcountryEta) +
        " elsewhere, at " + money(SHR.CONFIG.delivery.kigaliFee) + " in Kigali and " + money(SHR.CONFIG.delivery.upcountryFee) + " upcountry" +
        (SHR.CONFIG.claims && SHR.CONFIG.claims.freeDeliveryActive ? ", and free on orders above " + money(SHR.CONFIG.delivery.freeFrom) : "") +
        ". You can also collect from us free of charge. We confirm the delivery time with you when we confirm the order — see the <a href='policies.html#delivery'>delivery policy</a>.</p>") +
      acc("Returns information", "<p>Unopened products in their original sealed packaging can be returned within 7 days of delivery for a refund or an exchange. If anything arrives damaged, expired or different from what you ordered, tell us within 48 hours with a photo and we replace it at our cost. For hygiene reasons opened skincare cannot be returned unless it is faulty — the full terms are in the <a href='policies.html#delivery'>delivery and returns policy</a>.</p>") +
      "</div>";

    var faqs = (item.faqs || []).concat(SHR.PRODUCT_FAQS);
    var faqBlock =
      '<h2 class="mt-4">Frequently asked questions</h2><div class="accordion">' +
      faqs.map(function (f) { return acc(esc(f.q), "<p>" + esc(f.a) + "</p>"); }).join("") +
      "</div>";

    var breakdown = api.ratingBreakdown(item);
    /* Only this product's own reviews, and only shown when they are real */
    var productReviews = item.reviews || [];
    var reviewBlock =
      '<h2 class="mt-4" id="reviews">Customer reviews</h2>' +
      (api.reviewsVerified()
        ? '<div class="reviews-summary mb-3">' +
          '<div class="score"><span class="score__num">' + item.rating.toFixed(1) + "</span>" + api.starsHTML(item.rating, true) +
          '<span class="score__of">' + item.reviewCount + " reviews</span></div>" +
          '<div class="bars">' + breakdown.map(function (b) {
            return '<div class="bar-row"><span>' + b.star + " star</span><span class='bar'><i style='width:" + b.percent + "%'></i></span><span>" + b.count + "</span></div>";
          }).join("") + "</div></div>" +
          '<div class="grid grid--3">' + productReviews.map(reviewCard).join("") + "</div>"
        : api.reviewsGate("This product has no published reviews yet. We only print reviews from customers who bought it and agreed to be quoted.")) +
      '<div class="cta-band mt-4" style="text-align:left">' +
      '<h3 class="mb-1">Bought this product?</h3>' +
      "<p>Send us what you thought of it on WhatsApp — good or bad. We publish reviews with permission, and real reviews help everyone in Rwanda buy the right thing.</p>" +
      '<div class="cta-band__actions" style="justify-content:flex-start">' +
      '<a class="btn btn--whatsapp" href="' + esc(api.waLink("Hello, I would like to leave a review for " + item.brand + " " + item.name + " from Skincare Hub Rwanda.")) +
      '" target="_blank" rel="noopener">' + icon("whatsapp") + "Write a review</a>" +
      '<a class="btn btn--outline-light" href="reviews.html">Read all reviews</a></div></div>';

    var related = api.relatedTo(item, 4);
    var recent = api.recentlyViewed(4).filter(function (r) { return r.id !== item.id; });
    var routine = buildRoutineAround(item);

    host.innerHTML =
      '<nav class="breadcrumbs" aria-label="Breadcrumb">' +
      '<a href="index.html">Home</a><span aria-hidden="true">/</span>' +
      '<a href="shop.html">Shop</a><span aria-hidden="true">/</span>' +
      '<a href="shop.html?category=' + item.category + '">' + esc(api.categoryById(item.category).name) + "</a><span aria-hidden='true'>/</span>" +
      '<span aria-current="page">' + esc(item.name) + "</span></nav>" +
      '<div class="pdp">' + gallery + "<div>" + info + accordion + "</div></div>" +
      faqBlock + reviewBlock +
      routineBlock(routine) +
      '<section class="section section--cream" style="margin-top:var(--section-y);border-radius:var(--r-xl)">' +
      '<div class="container"><div class="section-head"><span class="eyebrow eyebrow--center">Goes with this</span>' +
      "<h2>You may also need</h2></div><div class='product-grid product-grid--4'>" +
      related.map(function (p) { return api.productCard(p); }).join("") + "</div></div></section>" +
      (recent.length
        ? '<section class="section--tight"><h2 class="mb-3">Recently viewed</h2><div class="product-grid product-grid--4">' +
          recent.map(function (p) { return api.productCard(p); }).join("") + "</div></section>"
        : "") +
      schema(item, faqs);

    /* gallery switching */
    $$("[data-visual-variant]", host).forEach(function (btn) {
      btn.addEventListener("click", function () {
        var variant = btn.getAttribute("data-visual-variant");
        var main = $("[data-gallery-main]", host);
        if (main) main.innerHTML = api.productVisual(item, variant);
        $$("[data-visual-variant]", host).forEach(function (b) {
          b.setAttribute("aria-selected", b === btn ? "true" : "false");
        });
      });
    });
    /* add to cart from the PDP uses the chosen quantity */
    var addBtn = $("[data-add-pdp]", host);
    if (addBtn) {
      addBtn.addEventListener("click", function () {
        var qtyNode = $("[data-qty-static] [data-qty-value]", host);
        var qty = qtyNode ? parseInt(qtyNode.textContent, 10) || 1 : 1;
        api.cart.add(item.id, qty);
      });
    }
    var buyBtn = $("[data-buy-now]", host);
    if (buyBtn) {
      buyBtn.addEventListener("click", function () {
        var qtyNode = $("[data-qty-static] [data-qty-value]", host);
        api.cart.add(item.id, qtyNode ? parseInt(qtyNode.textContent, 10) || 1 : 1, { silent: true });
        window.location.href = "checkout.html";
      });
    }
    var wishBtn = $("[data-wish-toggle]", host);
    if (wishBtn) {
      wishBtn.classList.toggle("is-on", api.wish.has(item.id));
      api.wish.onChange(function () {
        var on = api.wish.has(item.id);
        wishBtn.classList.toggle("is-on", on);
        wishBtn.innerHTML = icon("heart") + (on ? " Saved to wishlist" : " Save to wishlist");
      });
      if (api.wish.has(item.id)) wishBtn.innerHTML = icon("heart") + " Saved to wishlist";
    }
    $$("[data-qty-static]").forEach(function (wrap) {
      wrap.addEventListener("qty:change", function (e) {
        var node = wrap.querySelector("[data-qty-value]");
        if (node) node.textContent = e.detail.value;
      });
    });
    SHR.ui.refresh();
  }

  function acc(title, body, open) {
    return "<details class='acc'" + (open ? " open" : "") + "><summary>" + title + "</summary><div class='acc__body'>" + body + "</div></details>";
  }
  function detail(label, value) {
    if (!value) return "";
    return "<div class='detail-list__row'><dt>" + esc(label) + "</dt><dd>" + esc(value) + "</dd></div>";
  }

  /* ── Complete Your Routine ──────────────────────────────────
     The four steps, in order, built around the product the customer is
     looking at: whichever step that product fills is marked, and the other
     steps are filled from products that suit the same skin and concerns, in
     stock, closest to the price they are already looking at. */
  var ROUTINE_STEPS = [
    { id: "cleanse", label: "Cleanse", note: "Morning and evening", categories: ["cleansers"] },
    { id: "treat", label: "Treat", note: "One active, after cleansing", categories: ["serums", "acne-care", "hyperpigmentation", "toners"] },
    { id: "moisturize", label: "Moisturize", note: "Morning and evening", categories: ["moisturizers"] },
    { id: "protect", label: "Protect", note: "Every morning, SPF 50", categories: ["sunscreens"] }
  ];
  function buildRoutineAround(item) {
    var steps = [];
    ROUTINE_STEPS.forEach(function (step) {
      var owns = step.categories.indexOf(item.category) >= 0;
      var product = null;
      var why = "";
      if (owns) {
        product = item;
        why = "The product on this page.";
      } else {
        var pool = SHR.PRODUCTS.filter(function (p) {
          return p.id !== item.id && p.stock !== "out" && step.categories.indexOf(p.category) >= 0;
        }).map(function (p) {
          var score = api.relatedToScore(item, p);
          return { p: p, s: score };
        }).sort(function (a, b) { return b.s - a.s; });
        if (pool.length) {
          product = pool[0].p;
          why = api.fitReason(item, product);
        }
      }
      if (product) steps.push({ step: step, product: product, owns: owns, why: why });
    });
    var additions = steps.filter(function (s) { return !s.owns; });
    var total = additions.reduce(function (n, s) { return n + s.product.price; }, 0);
    return { steps: steps, additions: additions, total: total };
  }
  function routineBlock(routine) {
    if (!routine.steps.length) return "";
    var ids = routine.additions.map(function (s) { return s.product.id; }).join(",");
    return (
      '<section class="section section--cream routine-build" style="margin-top:var(--section-y);border-radius:var(--r-xl)">' +
      '<div class="container">' +
      '<div class="section-head"><span class="eyebrow eyebrow--center">Complete the routine</span>' +
      "<h2>Complete Your Routine</h2>" +
      "<p>Four steps in order. This is what fits around the product on this page.</p></div>" +
      '<ol class="routine-grid routine-grid--compact">' +
      routine.steps.map(function (s) {
        return (
          '<li class="routine-card' + (s.owns ? " routine-card--here" : "") + '">' +
          '<span class="routine-card__step">' + esc(s.step.label) + "</span>" +
          '<a class="routine-card__media" href="product.html?id=' + encodeURIComponent(s.product.id) + '" tabindex="-1" aria-hidden="true">' +
          '<span class="visual">' + api.productVisual(s.product) + "</span></a>" +
          '<span class="routine-card__brand">' + esc(s.product.brand) + "</span>" +
          '<a class="routine-card__name" href="product.html?id=' + encodeURIComponent(s.product.id) + '">' + esc(s.product.name) + "</a>" +
          '<span class="routine-card__meta">' + esc(s.product.size) + " &middot; " + money(s.product.price) + "</span>" +
          '<span class="routine-card__meta">' + esc(s.step.note) + "</span>" +
          '<span class="routine-card__why">' + esc(s.why) + "</span>" +
          (s.owns
            ? '<span class="badge badge--gold">This page</span>'
            : (s.product.stock === "out"
                ? '<button class="btn btn--outline btn--sm" type="button" disabled>Out of stock</button>'
                : '<button class="btn btn--outline btn--sm" type="button" data-add="' + esc(s.product.id) + '">' + icon("cart") + "Add</button>")) +
          "</li>"
        );
      }).join("") +
      "</ol>" +
      (routine.additions.length
        ? '<div class="routine-total">' +
          '<p class="mb-0">Add the other ' + routine.additions.length + " step" + (routine.additions.length === 1 ? "" : "s") +
          " to your cart for <strong>" + money(routine.total) + "</strong>.</p>" +
          '<button class="btn btn--gold btn--lg" type="button" data-add-routine-set="' + esc(ids) + '">' + icon("cart") + "Add all to cart — " + money(routine.total) + "</button></div>"
        : '<p class="text-center mt-3 mb-0">This product covers every step we would add — there is nothing else you need.</p>') +
      "</div></section>"
    );
  }
  function reviewCard(r) {
    return (
      '<article class="review">' +
      '<div class="review__top"><span class="avatar">' + esc(SHR.initials(r.who)) + "</span>" +
      '<span class="review__who"><strong>' + esc(r.who) + "</strong><span>" + esc(r.city) + "</span></span></div>" +
      api.starsHTML(r.rating) +
      '<p class="review__body">“' + esc(r.text) + "”</p>" +
      '<div class="review__foot"><span>' + esc(r.date) + "</span>" +
      '<span class="verified">' + icon("checkCircle") + "Verified purchase</span></div></article>"
    );
  }
  function schema(item, faqs) {
    var product = {
      "@type": "Product",
      name: item.brand + " " + item.name,
      description: item.short,
      sku: item.id,
      brand: { "@type": "Brand", name: item.brand },
      category: api.categoryById(item.category).name,
      offers: {
        "@type": "Offer",
        price: item.price,
        priceCurrency: SHR.CONFIG.currency,
        availability: item.stock === "out" ? "https://schema.org/OutOfStock" : "https://schema.org/InStock",
        url: "product.html?id=" + item.id,
        seller: { "@type": "Organization", name: SHR.CONFIG.name }
      }
    };
    /* A rating goes into structured data only when it is real — an invented
       aggregate rating is exactly what search engines penalise. */
    if (api.reviewsVerified()) {
      product.aggregateRating = { "@type": "AggregateRating", ratingValue: item.rating.toFixed(1), reviewCount: item.reviewCount };
    }
    var data = {
      "@context": "https://schema.org",
      "@graph": [
        product,
        {
          "@type": "FAQPage",
          mainEntity: faqs.map(function (f) {
            return { "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } };
          })
        }
      ]
    };
    return '<script type="application/ld+json">' + JSON.stringify(data) + "</script>";
  }

  /* ─────────────────────────────────────────────────────── REVIEWS */
  /* Reviews are only ever real ones. While claims.reviewsVerified is false the
     page says so instead of showing ratings nobody earned. */
  function reviews() {
    var summaryHost = $("[data-reviews-summary]");
    var carousel = $("[data-reviews-carousel]");
    var gridHost = $("[data-reviews-grid]");

    if (!api.reviewsVerified()) {
      if (summaryHost) {
        summaryHost.innerHTML = api.reviewsGate(
          "We publish a review only after the customer has bought the product from us and agreed to be quoted, with their name and where they are. That means this page is empty until the first ones arrive — we would rather show you nothing than invent a rating."
        );
      }
      [carousel, gridHost].forEach(function (node) {
        var section = node ? node.closest("section") : null;
        if (section) section.classList.add("hide");
      });
      if (gridHost) gridHost.innerHTML = "";
      if (carousel) carousel.innerHTML = "";
      SHR.ui.refresh();
      return;
    }

    var items = SHR.TESTIMONIALS;
    var allProducts = SHR.PRODUCTS;
    var avg = allProducts.reduce(function (n, p) { return n + p.rating; }, 0) / (allProducts.length || 1);
    var count = allProducts.reduce(function (n, p) { return n + (p.reviewCount || 0); }, 0);
    if (summaryHost) {
      var buckets = [5, 4, 3, 2, 1].map(function (star) {
        var w = Math.max(0, 1 - Math.abs(avg - star) * 0.6);
        return { star: star, w: w };
      });
      var total = buckets.reduce(function (n, b) { return n + b.w; }, 0) || 1;
      summaryHost.innerHTML =
        '<div class="score"><span class="score__num">' + avg.toFixed(1) + "</span>" + api.starsHTML(avg, true) +
        '<span class="score__of">' + count.toLocaleString() + " product reviews</span></div>" +
        '<div class="bars">' + buckets.map(function (b) {
          var percent = Math.round((b.w / total) * 100);
          return '<div class="bar-row"><span>' + b.star + " star</span><span class='bar'><i style='width:" + percent + "%'></i></span><span>" + percent + "%</span></div>";
        }).join("") + '<p class="form-note mb-0">Collected from customers across Rwanda.</p></div>';
    }
    if (carousel) {
      carousel.innerHTML = items.map(function (t) {
        return (
          '<div class="carousel__slide"><blockquote class="review-card">' + api.starsHTML(t.rating) +
          '<p class="review-card__quote">“' + esc(t.text) + '”</p>' +
          '<div class="review-card__foot"><span class="avatar avatar--navy">' + esc(SHR.initials(t.name)) + "</span>" +
          '<span class="review__who"><strong>' + esc(t.name) + "</strong><span>" + esc(t.city) + " &middot; " + esc(t.tag) + "</span></span></div>" +
          '<p class="form-note mb-0">Bought: ' + esc(t.product) + "</p></blockquote></div>"
        );
      }).join("");
    }
    if (gridHost) {
      var feed = [];
      SHR.PRODUCTS.forEach(function (p) {
        (p.reviews || []).forEach(function (r) {
          feed.push({ r: r, p: p });
        });
      });
      gridHost.innerHTML = feed.slice(0, 12).map(function (x) {
        return (
          '<article class="review">' +
          '<div class="review__top"><span class="avatar">' + esc(SHR.initials(x.r.who)) + "</span>" +
          '<span class="review__who"><strong>' + esc(x.r.who) + "</strong><span>" + esc(x.r.city) + "</span></span></div>" +
          api.starsHTML(x.r.rating) +
          '<p class="review__body">“' + esc(x.r.text) + "”</p>" +
          '<div class="review__foot"><span>' + esc(x.r.date) + "</span>" +
          '<a href="product.html?id=' + x.p.id + '">' + esc(x.p.brand + " " + x.p.name) + "</a></div></article>"
        );
      }).join("");
    }
    SHR.ui.refresh();
  }

  /* ─────────────────────────────────────────────────────────── FAQ */
  function faq() {
    var host = $("[data-faq-list]");
    if (!host) return;
    var cats = ["All"].concat(
      SHR.FAQS.map(function (f) { return f.category; }).filter(function (c, i, all) { return all.indexOf(c) === i; })
    );
    var state = { category: "All", q: "" };
    var chips = $("[data-faq-cats]");
    function renderChips() {
      if (!chips) return;
      chips.innerHTML = cats.map(function (c) {
        return '<button class="chip" type="button" data-faq-cat="' + esc(c) + '"' + (state.category === c ? ' aria-pressed="true"' : "") + ">" + esc(c) + "</button>";
      }).join("");
    }
    function render() {
      var list = SHR.FAQS.filter(function (f) {
        var okCat = state.category === "All" || f.category === state.category;
        var okQ = !state.q || (f.q + " " + f.a).toLowerCase().indexOf(state.q.toLowerCase()) >= 0;
        return okCat && okQ;
      });
      host.innerHTML = list.length
        ? list.map(function (f) { return acc(esc(f.q), "<p>" + esc(f.a) + "</p>"); }).join("")
        : '<div class="empty-state">' + icon("search") + "<p>No answers matched that. Ask us directly on WhatsApp and a human will reply.</p>" +
          '<a class="btn btn--whatsapp btn--sm" href="' + esc(api.waLink("Hello, I have a question that is not in your FAQ.")) + '" target="_blank" rel="noopener">' + icon("whatsapp") + "Ask on WhatsApp</a></div>";
      var ld = document.getElementById("faqSchema");
      if (ld) {
        ld.textContent = JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: list.map(function (f) {
            return { "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } };
          })
        });
      }
    }
    renderChips();
    render();
    if (chips) {
      chips.addEventListener("click", function (e) {
        var b = e.target.closest("[data-faq-cat]");
        if (!b) return;
        state.category = b.getAttribute("data-faq-cat");
        renderChips();
        render();
      });
    }
    var search = $("[data-faq-search]");
    if (search) {
      search.addEventListener("input", api.debounce(function () {
        state.q = search.value;
        render();
      }, 200));
    }
    SHR.ui.refresh();
  }

  var pages = { home: home, shop: shop, product: product, reviews: reviews, faq: faq };
  SHR.pages = pages;

  function boot() {
    var page = (document.body && document.body.getAttribute("data-page")) || "";
    if (pages[page]) pages[page]();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
